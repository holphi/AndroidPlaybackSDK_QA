"""     
    This module contains xshow, the sub command to show details about xunit reports.
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""

import sys
import platform
import os
import argparse
import subprocess
import re
import types
import shutil
import signal
import time
import datetime
import time
from textwrap import dedent
from logging import getLogger, basicConfig
from pprint import pprint
import getpass
import py


from gti_scutils.model import ServerConfig, XunitReport, XU_VALID_OUTOME, OUTCOME_TRANS
from gti_scutils.utils import ProgressBar, GTISCUtilsBase, scutils_debug_enable, scutils_verbose_enable


class XShow(GTISCUtilsBase):
    '''\
       This sub-command shows the details of an xunit report.
       
       It is possible to filter the output according to:
       
           - the outcome (option --outcome)
           - the test case name(s) (option --test-case-name)
           - the test procedure name(s) (option --test-procedure-name)
    
        To see the backtrace in case of failure, use the --back-trace option
        To see the standard error captured use the --stderr option
        To see the standard output captured use the --stderr option
    '''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(XShow, self).__init__(name = "xshow", debug = debug, verbose = verbose)
        
        self.parser = subparsers.add_parser('xshow', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            help='xshow shows the raw information from the xunit report', 
                                            description = dedent(XShow.__doc__),
                                            parents = [common_parser])

        self.parser.add_argument('-x', '--xunit-path', 
                                action='store',
                                metavar = "string",
                                required = True,
                                help = "path or url to a junit xml (can be zipped) file containing the results of a test run.")

        self.parser.add_argument('-n', '--test-case-name', 
                                action='append',
                                metavar = "<test name>",
                                help = "test case name to be matched - can be repeated")

        self.parser.add_argument('-p', '--test-procedure-name', 
                                action='append',
                                metavar = "<test procedure name>",
                                help = "test procedure name to be matched - can be repeated")


        self.parser.add_argument('--outcome', 
                                action='append',
                                choices= XU_VALID_OUTOME,
                                help = "outcome to process")
        
        self.parser.add_argument('-b', '--back-trace', 
                                action = 'store_true',
                                help = "shows the backtrace information")
        
        self.parser.add_argument('-e', '--stderr', 
                                action = 'store_true',
                                help = "shows standard error")

        self.parser.add_argument('-o', '--stdout', 
                                action = 'store_true',
                                help = "shows standard output")
        
        self.parser.add_argument('--ignore-base', 
                                action = 'store',
                                help = "If set, will strip the xunit report classname prefix from the matching string provided. See doc for more details")        



        self.parser.set_defaults(func=self.process_xshow)
        
    def process_xshow(self, args):
        
        
        try:
            xunit_report = XunitReport(file_path = args.xunit_path, ignore_base = args.ignore_base)
        except Exception as pe:
            self.error("Failed to parse %s\n" % (args.xunit_path))
            raise
        
        for xunit_tc_obj in xunit_report.get_test_cases(args.outcome or XU_VALID_OUTOME):
            
            if args.test_case_name != None:
                n = xunit_tc_obj.name.lower()
                found = False
                for m in args.test_case_name:
                    if n == m.lower():
                        found = True
                        break
                if found == False:
                    continue

            if args.test_procedure_name != None:
                n = xunit_tc_obj.test_proc_name.lower()
                found = False
                for m in args.test_procedure_name:
                    if n == m.lower():
                        found = True
                        break
                if found == False:
                    continue

            
            self._tw.write("\n" + "-"*80 + "\n", cyan = True, bold = True)
            
            self._tw.write("TEST CASE     : ", white = True, bold = True)
            self._tw.write("{0} ".format(xunit_tc_obj.name), yellow = True)

            self._tw.write("ID     : ", white = True, bold = True)
            self._tw.write("{0} ".format(xunit_tc_obj.external_id or "?"), yellow = True)

            self._tw.write("UID     : ", white = True, bold = True)
            self._tw.write("{0} ".format(xunit_tc_obj.uid or "?"), yellow = True)

            output_code = {}
            if xunit_tc_obj.outcome == "pass":
                output_code['green'] = True
                output_code['bold'] = False
            elif xunit_tc_obj.outcome == "fail":
                output_code['red'] = True
                output_code['bold'] = True
            elif xunit_tc_obj.outcome == "error":
                output_code['yellow'] = True
                output_code['bold'] = True
            elif xunit_tc_obj.outcome == "skip":
                output_code['cyan'] = True
                output_code['bold'] = False


            self._tw.write("  OUTCOME: ", white = True, bold = True)
            self._tw.write("{0}".format(xunit_tc_obj.outcome), **output_code)

            self._tw.write("  TIME: ", white = True, bold = True)
            self._tw.write("{0}\n".format(xunit_tc_obj.time), green = True)
            
            self._tw.write("CLASS NAME    : ", white = True, bold = True)
            self._tw.write("{0}\n".format(xunit_tc_obj.classname), yellow = True)
            
            self._tw.write("TEST PROCEDURE: ", white = True, bold = True)
            self._tw.write("{0}\n".format(xunit_tc_obj.test_proc_name), yellow = True)
            

            self._tw.write("\nSUMMARY\n", white = True, bold = True)
            self._tw.write("-------\n\n", white = True, bold = True)
            self._tw.write("{0}\n".format(xunit_tc_obj.summary), cyan = True)


            if xunit_tc_obj.message != None:
                self._tw.write("\nMESSAGE:    ", white = True, bold = True)
                self._tw.write("{0}\n".format(xunit_tc_obj.message), red = True)
                
            if xunit_tc_obj.backtrace != None and args.back_trace == True:
                self._tw.write("\nBACK TRACE\n", red = True, bold = True)
                self._tw.write("----------\n\n", red = True, bold = True)
                self._tw.write("{0}\n".format(xunit_tc_obj.backtrace), white = True, bold = True)
            
            if xunit_tc_obj.stdout != None and args.stdout == True:
                self._tw.write("\nSTANDARD OUT\n", white = True, bold = True)
                self._tw.write("------------\n\n", white = True, bold = True)
                self._tw.write("{0}\n".format(xunit_tc_obj.stdout), green = True, bold = True)
                
            if xunit_tc_obj.stderr != None and args.stderr == True:
                self._tw.write("\nSTANDARD ERROR\n", white = True, bold = True)
                self._tw.write("--------------\n\n", white = True, bold = True)
                self._tw.write("{0}\n".format(xunit_tc_obj.stderr), yellow = True, bold = True)
