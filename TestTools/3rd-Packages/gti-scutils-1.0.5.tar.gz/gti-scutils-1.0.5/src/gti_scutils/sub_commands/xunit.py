"""     
    This module contains xunit, the sub command to summarize or upload xunit reports.
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""

import sys
import platform
import os
import argparse
import subprocess
import re
import types
import shutil
import signal
import time
import datetime
import time
from textwrap import dedent
from logging import getLogger, basicConfig
from pprint import pprint
import getpass
import py

import dolby.gti.testlink as testlink
import dolby.gti.testlink.const as SCConst
from dolby.gti.testlink.commands import *
from dolby.gti.testlink.structures import Suite as TLSuite

from gti_scutils.sub_commands.xshow import XShow
from gti_scutils.sub_commands.testlink import SCLogin, SCUse, SCLogout
from gti_scutils.sub_commands.xcomp import XunitComp


from gti_scutils import __version__, __p4datetime__, __p4change__, __p4file__


from gti_scutils.model import ServerConfig, XunitReport, CombinedXunitReport, XU_VALID_OUTOME, OUTCOME_TRANS
from gti_scutils.utils import ProgressBar, GTISCUtilsBase, scutils_debug_enable, scutils_verbose_enable


class XunitUtil(GTISCUtilsBase):
    '''\
        Processes a xunit report and performs some actions on the content. The xunit
        report (-x --xunit-path) can be in compressed format (zip). (GZIP not supported)
        The report can be accessed via a URL.
        
        Py.Test Specific
        - - - - - - - - 
        
        Compound test cases are defined as test cases which follow the same procedure
        but are executed via different data set.
        
        Compound results are generated using the -c (--compound) option and follow a simple 
        rule. Any test "step" of a compound test case that fails, fails the compound case.
        
        If the -w (--weight) option is specified, weight information, which consist 
        of the pass rate (pass over total), and weight details, is provided.
    
        The xunit command provides the following features:
    
            * Upload of test results from an xunit report:
            
                -a upload
                
                This action should be used to upload an xunit report to the testlink
                project against the specified project (-p), test set (-s), build (-b)
                and an optional platform(-t).
                
                if the dry run (-s) option is specified, data is only processed but not 
                uploaded. 
            
                --keep-structure is specified, the code hierarchy will be maintained, 
                otherwise all test cases will be loaded as a flat structure under the 
                base path (--base-path)
            
            * Summary display "a la Pytest":
            
                -a sum
            
                This action takes the xunit report and dispay a summary on the console
                the way pytest does during execution. 
                
            * Error grouping:
            
                -a group
            
                This action attempt to find common failure from the backtraces and group 
                test cases that are failing under the same conditions together. 
    '''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(XunitUtil, self).__init__(name = "xunit", debug = debug, verbose = verbose)
        
        self.parser = subparsers.add_parser('xunit', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            help='xunit report utilities', 
                                            description = dedent(XunitUtil.__doc__),
                                            parents = [common_parser])
        
        self.parser.add_argument('-p', '--sc-project-name', 
                                action='store',
                                metavar = "string",
                                help = "soundcheck project name")

        self.parser.add_argument('-s', '--sc-test-set-name', 
                                action='store',
                                metavar = "string",
                                help = "sound check test set name where results are to be reported.")

        self.parser.add_argument('--sc-platform-name', 
                                action='store',
                                metavar = "string",
                                help = "platform (target) name used for reporting")

        self.parser.add_argument('-b', '--sc-build-name', 
                                action='store',
                                metavar = "string",
                                help = "build name name used for reporting")
        
        self.parser.add_argument('-r', '--sc-build-release-date', 
                                action='store',
                                metavar = "string",
                                help = "release date to be set of the build is created on the server")

        self.parser.add_argument('-i', '--sc-build-info', 
                                action='store',
                                metavar = "string",
                                help = "build information which can be added to build on the server when created.")
    
        self.parser.add_argument('--base-path', 
                                action='store',
                                metavar = "string",
                                default = "/default",
                                help = "Base test suite in soundcheck to be used to create/report test case results into.")

        self.parser.add_argument('-x', '--xunit-path', 
                                action='append',
                                metavar = "string",
                                required = True,
                                help = "path or url to a junit xml (can be zipped) file containing the results of a test run.")

        self.parser.add_argument('-d', '--dry-run', 
                                action = 'store_true',
                                help = "Dry run mode")

        self.parser.add_argument('--keep-structure', 
                                action = 'store_true',
                                help = "If set, keeps the test case hierarchy")
        
        self.parser.add_argument('-a', '--action', 
                                action='store',
                                default = 'sum',
                                choices= ["sum", "upload", "group"],
                                help = "action to perform")

        self.parser.add_argument('-o', '--outcome', 
                                action='append',
                                choices= XU_VALID_OUTOME,
                                help = "outcome to process")

        self.parser.add_argument('-c', '--compound', 
                                action = 'store_true',
                                help = "Set the outcome to a series of test cases with the same name")

        self.parser.add_argument('-w', '--weighted', 
                                action = 'store_true',
                                help = "If used with the -c option, provide a weighted outcome.")

        self.parser.add_argument('--concise', 
                                action = 'store_true',
                                help = "If set, the diagnostic associated to the test is not display (action: sum)")

        self.parser.add_argument('--no-fast-upload', 
                                action = 'store_true',
                                help = "If set, switches back to pytl implementation.  See https://jira.dolby.net/jira/browse/GTITA-221 for details")

        self.parser.add_argument('--ignore-base', 
                                action = 'store',
                                help = "If set, will strip the xunit report classname prefix from the matching string provided. See doc for more details")
        
        self.parser.set_defaults(func=self.process_xunit)
        
        self._warnings = []
        
    def process_xunit(self, args):
        
        if args.sc_build_release_date != None:
            try:
                import dateutil.parser 
                args.sc_build_release_date = dateutil.parser.parse(args.sc_build_release_date).isoformat(">").split(">")[0]
            except Exception as de:
                self.fatal("Failed to convert date {0} to ISO 8601 format. Please provide date in ISO 8601 format (YYYY-MM-DD) - error {1}".format(args.sc_build_release_date, de))
            self.info("build release date is (ISO 8601) {0}".format(args.sc_build_release_date))


        xunit_report = CombinedXunitReport(file_list = args.xunit_path, ignore_base = args.ignore_base) 
        if args.action == 'sum':
            self._action_summary(args, xunit_report)
        elif args.action == 'upload':
            self._action_upload(args, xunit_report)
        elif args.action == 'group':
            self._action_fault_grouping(args, xunit_report)
        else:
            self.error("unknown action %s", str(args.action))
            self.parser.exit(1)
            
        if len(self._warnings) > 0:
            self.bold("The command completed with warnings")
            for w in self._warnings:
                self.warning(w)
            self.bold("End of warnings - total warnings {0}".format(len(self._warnings)))
            #raise Exception("The process completed with warnings")
           
    def _action_upload(self, args, xunit_obj):
        sc_project = None
        sc_testset = None
        sc_build   = None
        sc_platform   = None
        
        if args.base_path == None and args.keep_structure == False:
            self.warning("Base path not defined - setting to default")            
            args.base_path = "default"
        
        self.action("processing {0} tests - passed {1} - failed {2} - error {3} - skipped {4}".format(
                                                                xunit_obj.all_tests,
                                                                xunit_obj.ok,
                                                                xunit_obj.failures,
                                                                xunit_obj.errors,
                                                                xunit_obj.skips                           
                                                                                                    ))

        cfg = ServerConfig(fast_upload = not args.no_fast_upload)
        
        if cfg.current_config == None:            
            self.error("No configuration set - use 'login' or 'use' sub-command")       
            self.parser.exit(1)
        try:
            cfg.sc_server
        except Exception as ce:
            self.error("Failed to connect to server %s - %s", str(ce), cfg.server_url)
            self.parser.exit(1)
                
        if args.sc_project_name == None:
            self.error("--sc-project-name option required")
            self.parser.exit(1)

        if args.sc_test_set_name == None:
            self.error("--sc-test-set-name option required")
            self.parser.exit(1)

        if args.sc_build_name == None:
            self.error("--sc-build-name option required")
            self.parser.exit(1)
            
        xunit_obj.set_testlink_info(server_config = cfg, 
                                    project_name = args.sc_project_name,
                                    set_name = args.sc_test_set_name, 
                                    build_name = args.sc_build_name,
                                    build_info = args.sc_build_info,
                                    build_release_date = args.sc_build_release_date,
                                    platform_name = args.sc_platform_name,
                                    base_path = args.base_path,
                                    dry_run = args.dry_run,
                                    keep_structure = args.keep_structure,
                                    compound = args.compound)

        self.action("Checking testlink server settings")
        
        try:
            sc_project = xunit_obj.sc_project
        except ValueError as pnotfound:    
            self.error(str(pnotfound))
            self.parser.exit(1)
        self.success("%-20s %-30s OK!", 'project', args.sc_project_name)

        try:
            sc_testset = xunit_obj.sc_test_set
        except ValueError as snotfound:    
            self.error(str(snotfound))
            self.parser.exit(1)
        self.success("%-20s %-30s OK!", 'test set',  args.sc_test_set_name)

        try:
            sc_build = xunit_obj.sc_build
        except ValueError as bnotfound:    
            self.error(str(bnotfound))
            self.parser.exit(1)
        self.success("%-20s %-30s OK!", 'build',  args.sc_build_name)

        try:
            base_suite_obj = xunit_obj.sc_base_suite
        except ValueError as suitenotfound:    
            self.error(str(suitenotfound))
            self.parser.exit(1)
        self.success("%-20s %-30s OK!", 'base suite',  args.base_path)
        
        if args.sc_platform_name != None:
            try:
                xunit_obj.sc_platform
            except ValueError as platnotfound:    
                self.error(str(platnotfound))
                self.parser.exit(1)
            self.success("%-20s %-30s OK!", 'platform',  args.sc_platform_name)
            
        
        progress = None
        if args.dry_run == False and args.verbose == False:
            progress = ProgressBar(xunit_obj.all_tests)

        self.action("Processing Specification")
        
        # Iterate through the test case list. If not present, create it.
        count = 0
        tc_list = xunit_obj.get_test_cases(args.outcome or XU_VALID_OUTOME, compound = args.compound)
        
        self.bold("%d test case found matching criteria", len(tc_list))
        
        def _show_testcase_outcome(name, outcome, id = None, dryrun = False):
            import dolby.gti.testlink.const as SCConst
            
            if args.dry_run == True:
                self._tw.write("[dry run] ", yellow = True, bold = True)

            if outcome == SCConst.OUTCOME_PASS:
                self._tw.write("%-10s" % (outcome), green = True)
            elif outcome == SCConst.OUTCOME_FAIL:
                self._tw.write("%-10s" % (outcome), red = True)
            elif outcome == SCConst.OUTCOME_NOT_EXECUTED:
                self._tw.write("%-10s" % (outcome), cyan = True)
            elif outcome == SCConst.OUTCOME_BLOCKED:
                self._tw.write("%-10s" % (outcome), yellow = True)
            else:
                self._tw.write("??%-8s" % (outcome), red = True, bold = True)

            if id != None:
                self._tw.write("%-10s " % str(id), cyan = True, bold = True)
                
            self._tw.write("%s\n" % (name), bold = True)
        
        for tc_obj in tc_list:
            sc_set_obj = None
            if progress:
                count += 1
                progress.current = count
                
            if len(tc_obj.name) > 100:
                self._warnings.append("test case {0} is more than 100 characters - skipping".format(tc_obj.fqname))
                continue
                  
            try:  
                self.debug_info("getting test set test case {0} from server (base path {1}) - keep structure {2}".format(tc_obj.name, base_suite_obj.title, args.keep_structure))
                tc_obj.sc_spec_case # This will trigger the creation of a test case if it doesn't exist.
            except Exception as tce:                
                if args.dry_run == True:
                    _show_testcase_outcome(name = tc_obj.name, outcome = tc_obj.sc_outcome, dryrun = args.dry_run)
                else:
                    self.debug_dump_backtrace()
                    self._warnings.append(str(tce))
            else:
                try:
                    note_info = "Generated from xunit report %s\n" % xunit_obj.report_path
                    if args.compound == True:
                        if args.weighted == True:
                            note_info += "weight info %7.2f%% %s\n" % (tc_obj.weight, tc_obj.weight_details)
                         
                        note_info += "Details (classname = %s\n" % tc_obj.classname 
                        for x_unit_tc in tc_obj.xunit_tests:
                            note_info += "%-5s %s\n" % ( x_unit_tc.outcome, x_unit_tc.name)
                    elif tc_obj.backtrace != None:
                        note_info += str(tc_obj.backtrace)
                         
                    if progress == None:
                        _show_testcase_outcome(id = tc_obj.sc_spec_case.fid, 
                                               name = tc_obj.sc_spec_case.title, 
                                               outcome = tc_obj.sc_outcome, dryrun = args.dry_run)
                    try:
                        tc_obj.upload_outome(note_info)
                    except ValueError as ue:
                        self.debug_dump_backtrace()
                        self._warnings.append(str(ue))
                        
                except Exception as reporte:
                    self.debug_dump_backtrace()
                    self._warnings.append(str(reporte))
                    
        if progress:
            progress.completed()
        
        self.success("processing {0} tests - passed {1} - failed {2} - error {3} - skipped {4}".format(
                                                                xunit_obj.all_tests,
                                                                xunit_obj.ok,
                                                                xunit_obj.failures,
                                                                xunit_obj.errors,
                                                                xunit_obj.skips                           
                                                                                                    ))
        
            
    
    def _action_summary(self, args, xunit_obj):
        buff = "SUMMARY REPORT : %s" % xunit_obj.report_path

        self.action("Processing Specification")
        tc_list = xunit_obj.get_test_cases(args.outcome or XU_VALID_OUTOME, compound = args.compound)
        self.bold("%d test case found matching criteria", len(tc_list))
                
        self.bold("="*len(buff), bold = True) 
        self.line(buff, green = True, bold = True)
        self.bold("="*len(buff), bold = True)
        
        
        # Just compute the longest test case name
        max_len = 0
        for tc_obj in tc_list:
            tc_descr = tc_obj.name
            if args.keep_structure == True:
                tc_descr = tc_obj.name + "::" + tc_obj.suite_path
            
            if len(tc_descr) > max_len:
                max_len = len(tc_descr)
        tc_desc_fmt = "%%-%ds " % max_len
        
        for tc_obj in tc_list:
            tc_descr = tc_obj.name
            add_info = ""
            if args.keep_structure == True:
                tc_descr = tc_obj.name + "::" + tc_obj.suite_path
                
            if len(tc_obj.name) > 100:
                self._warnings.append("test case {0} is more than 100 characters - this test case will not be uploaded".format(tc_obj.fqname))
            
            if args.compound == True and args.weighted == True:
                add_info = "%7.2f%% %s" % (tc_obj.weight, tc_obj.weight_details)
            else:
                add_info = tc_obj.message or ""
                if args.concise == True and len(add_info) > 10:
                    add_info = add_info[0:9] + " <...>"
                     
            
            output_code = {}
            if tc_obj.outcome == "pass":
                output_code['green'] = True
                output_code['bold'] = False
            elif tc_obj.outcome == "fail":
                output_code['red'] = True
                output_code['bold'] = True
            elif tc_obj.outcome == "error":
                output_code['yellow'] = True
                output_code['bold'] = True
            elif tc_obj.outcome == "skip":
                output_code['cyan'] = True
                output_code['bold'] = False
            
            self._tw.write("%-5s "  % tc_obj.outcome, **output_code)
            self._tw.write("%7.2f " % tc_obj.time)
            
            output_code = {'bold' : True}
            if tc_obj.outcome == "fail":
                output_code['red'] = True
                
            self._tw.write(tc_desc_fmt % tc_descr, **output_code)
            self._tw.write("%s\n"   % str(add_info), cyan = True, bold = True)
            #print "%7.2f %-75s %s" % (tc_obj.outcome, tc_obj.time,  tc_descr, str(add_info))
            
        self.line("\n" + str(xunit_obj), bold = True)

    def _action_fault_grouping(self, args, xunit_obj):
        print "processing fault grouping"
