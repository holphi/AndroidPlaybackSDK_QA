"""     
    This module contains xcomp, the sub command to compare xunit reports.
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""


import sys
import platform
import os
import argparse
import re
import types
import time
from textwrap import dedent
from pprint import pprint
import getpass
import py

from gti_scutils.sub_commands.testlink import KNOWN_SERVERS

from gti_scutils.utils import GTISCUtilsBase

from gti_scutils.model import ServerConfig, XunitReport, XU_VALID_OUTOME, OUTCOME_TRANS
from gti_scutils.utils import ProgressBar, GTISCUtilsBase, scutils_debug_enable, scutils_verbose_enable

class XunitComp(GTISCUtilsBase):
    '''\
    
        Show a comparative reports between multiple xunit reports. This sub-command can be used 
        to diff the xunit reports between different runs (execution) or platforms.
        
        By default the report, show the test cases which have a different outcome (unless
        the -l option is used). 
        
        If the timing option is used (-t), only test cases which have an outcome of pass in every
        report will be displayed with their respective timing information (in seconds). The shortest 
        run will be between square brackets []
        
    '''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(XunitComp, self).__init__(name = "xcomp", debug = debug, verbose = verbose)
        
        self._tw = py.io.TerminalWriter(file=None)
        
        self.parser = subparsers.add_parser('xcomp', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            help='xunit report compare  utilities', 
                                            description = dedent(XunitComp.__doc__),
                                            parents = [common_parser])


        self.parser.add_argument('-x', '--xunit-report', 
                                action='append',
                                metavar = "<path>",
                                help = "xunit report files to compare")

        self.parser.add_argument('-l', '--long', 
                                action = 'store_true',
                                help = "long output - show test case with identical results")

        self.parser.add_argument('-t', '--timing', 
                                action = 'store_true',
                                help = "show timing for each pass test case (ignore other outcome)")

        self.parser.add_argument('-i', '--ignore-parameter', 
                                action='append',
                                metavar = "quoted regex",
                                help = "if specified, parameters matching the regular expression will be ignored")

        self.parser.add_argument('-s', '--short-name', 
                                action = 'store_true',
                                help = "do not show the test case full qualified path")
        
        self.parser.set_defaults(func=self.process_xunit)
        
    def process_xunit(self, args):
        
        if len(args.xunit_report) < 2:
            self.parser.error("please specify at least 2 reports")
            
        report_n2idx = {} # has of name to index
        
        fmt = [None]*(len(args.xunit_report) + 1) # format string for each column
        
        if args.ignore_parameter == None:
            args.ignore_parameter = []
        
        for i in range(len(args.xunit_report)):
            try:
                xunit_report_obj = XunitReport(args.xunit_report[i])
            except Exception as pe:
                raise
                self.parser.exit(status = 3, message = "Failed to parse %s - %s\n" % (args.xunit_path, str(pe)))
            xunit_base_name = os.path.basename(args.xunit_report[i])
            xunit_base_name = xunit_base_name.replace("xunit_", '')
            xunit_base_name = xunit_base_name.replace("xunit", '')
            xunit_base_name = xunit_base_name.replace(".xml", '')
            xunit_base_name = xunit_base_name.replace(".zip", '')

            # GTITA-158
            # The following  code ensures that the report name is unique.            
            level = 0
            while xunit_base_name in args.xunit_report:
                level += 1
                # We have duplicate basename so we need to go back up                
                dirs = os.path.dirname(args.xunit_report[i]).split(os.path.sep)
                dirs = dirs[len(dirs)-level:]
                dirs.append(xunit_base_name)
                xunit_base_name = os.path.join(*dirs)
            # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
            
            args.xunit_report[i] = xunit_base_name
            fmt[i+1] = " %-8s"
            report_n2idx[args.xunit_report[i]] = {'idx' : i, 'xunit_obj' : xunit_report_obj}
           
        xcomp_obj_by_tc = {}
        xcomp_outcome_by_tc = {}
        xcomp_timing_by_tc = {}
        
        stats = { 'total_collected' : 0,
                  'total_displayed' : 0,
                  'filtered_out'    : [],
                  'total_processed' : 0
                }  
        longest_name = 0
        
        dbg_test_list = {}
        # Build the matrix
        
        for report in args.xunit_report:
            xunit_obj = report_n2idx[report]['xunit_obj']
            xunit_idx = report_n2idx[report]['idx']
            self.info("Processing %s", xunit_obj.report_path)
            
            dbg_count = 0  
            
            for tc_obj in xunit_obj.get_test_cases():
                
                dbg_count += 1
                stats['total_processed'] += 1
                    
                # GTITA-15
                # If the -i option is specified, we recompose the name by extracting 
                # any ignore elements.
                
                comp_name = tc_obj.fqname
                
                if len(args.ignore_parameter) > 0:
                    # We break the test case into its part, group2 shall 
                   r = re.match("(.*)(\[.*\])(.*)", comp_name)
                   if r != None: # we have a match
                       tc_prefix = r.group(1)
                       tc_signature = r.group(2).lstrip("[").rstrip("]")
                       # This is to work around where a negative value is specified which would result
                       # in say --64. We change the -- to something unique and then split.
                       tc_signature = tc_signature.replace("--", ",~").replace("-", ",").replace("~", "-").split(',')
                       tc_suffix = r.group(3)   
                                           
                       regex = "|".join(args.ignore_parameter)
                       comp_signature = []
                       #print tc_signature
                       for p in tc_signature:
                           if re.match(regex, p) == None:
                               comp_signature.append(p)
                       comp_signature = "-".join(comp_signature)                       
                       comp_name = tc_prefix + "[" + comp_signature.lstrip(",") + "]" + tc_suffix

                display_name = comp_name
                if args.short_name == True:
                    r = re.match("(.*)(\[.*\])(.*)", comp_name)
                    if r != None: # we have a match
                        display_name = r.group(1).split(".")[-1] + r.group(2) + r.group(3)
                    else:
                        display_name = comp_name.split(".")[-1]

                
                if longest_name < len(display_name):
                    longest_name = len(display_name)
                
                #print "%80s %s" % (".".join(comp_name.split('.')[-3:]), ".".join(tc_obj.fqname.split('.')[-3:]))
                if xcomp_obj_by_tc.get(comp_name) == None:
                    stats['total_collected'] += 1
                    
                    if dbg_test_list.get(comp_name) == None:
                        dbg_test_list[comp_name] = []
                                            
                    if len(dbg_test_list[comp_name]) > 0:
                        self.error("compname: %s", str(comp_name))
                        self.error("full qualified name %s", str(tc_obj.fqname))
                        self.error("duplicate %s", str(dbg_test_list[comp_name]))
                        raise ValueError("duplicated test case")
                    
                    dbg_test_list[comp_name].append(tc_obj.fqname)
                                       
                    xcomp_obj_by_tc[comp_name] = [None]*len(args.xunit_report)
                    xcomp_outcome_by_tc[comp_name] = [None]*len(args.xunit_report)
                    xcomp_timing_by_tc[comp_name] = [None]*len(args.xunit_report)
                else:
                    dbg_test_list[comp_name].append(tc_obj.fqname)
                    
                xcomp_obj_by_tc[comp_name][xunit_idx] = tc_obj
                xcomp_outcome_by_tc[comp_name][xunit_idx] = tc_obj.outcome
                if tc_obj.outcome in ['fail', 'pass']:
                    xcomp_timing_by_tc[comp_name][xunit_idx] = tc_obj.time
                elif tc_obj.outcome == "error":
                    xcomp_timing_by_tc[comp_name][xunit_idx] = -1
            
        if args.timing == True:            
            # Remove all non PASS test case
            tc_list = xcomp_obj_by_tc.keys()
#             for tc in tc_list:                            
#                 if len(set(xcomp_outcome_by_tc[tc])) > 1 or 'pass' in xcomp_outcome_by_tc[tc]:
#                     xcomp_outcome_by_tc.pop(tc)
#                     xcomp_timing_by_tc.pop(tc)
#                     stats['filtered_out'].append(xcomp_obj_by_tc.pop(tc))
        elif args.long == False:
            # reduce the set
            tc_list = xcomp_obj_by_tc.keys()
            for tc in tc_list:
                if len(set(xcomp_outcome_by_tc[tc])) == 1:
                    xcomp_outcome_by_tc.pop(tc)
                    stats['filtered_out'].append(xcomp_obj_by_tc.pop(tc))

        buff = "SUMMARY REPORT"
        self.bold("="*len(buff)) 
        self.bold(buff, green = True)
        self.bold("="*len(buff))
        
        
        fmt[0] = "%%-%ds" % (longest_name+2)
        legend = ""
        for i in range(len(args.xunit_report)):
            legend += "[%d] - %s\n" % (i, args.xunit_report[i])
                
        header = fmt[0] % "TEST CASE"
        header_highlight = "-"*(len(fmt[0] % "TEST CASE")) + "+"
        
        for i in range(len(args.xunit_report)):            
            tmp = fmt[i+1] % ("[%d]" % i) #str(args.xunit_report[i])
            header += "|" + tmp
            header_highlight += "-"*len(tmp) + "+"
        header += "|"
        
        max_row = 50
        
        def _print_header():
            if stats['total_displayed'] % max_row == 0:
                self.bold(header_highlight)
                self.line(legend, cyan = True)
                self.bold(header_highlight)
                self.bold(header)
                self.bold(header_highlight)
            
        if args.timing == True:
            for tc_name, times in xcomp_timing_by_tc.iteritems():
                _print_header()                
                stats['total_displayed'] += 1
                
                if args.short_name == True:
                    r = re.match("(.*)(\[.*\])(.*)", tc_name)
                    if r != None: # we have a match
                        tc_name = r.group(1).split(".")[-1] + r.group(2) + r.group(3)
                    else:
                        tc_name = tc_name.split(".")[-1]
                
                tc_descr = fmt[0] % tc_name

                shortest = 0
                longest = 0
                for i in range(1, len(times)):
                    if times[i] == None:
                        continue

                    times[i] = round(times[i], 4)
                    if times[i] < times[shortest]:
                        shortest = i
                    if times[i] > times[longest]:
                        longest = i
                    
                
                sys.stdout.write(tc_descr + "|")
                # xcomp_timing_by_tc
                for i in range(len(times)):
                    if times[i] == None:
                        self._tw.write(fmt[i+1] % "N/A", cyan = True)
                    elif times[i] == -1:
                        self._tw.write(fmt[i+1] % "error", cyan = True)
                    elif times[i] == times[shortest]:
                        self._tw.write(fmt[i+1] % ("%6.4f" % times[i]), green = True, bold = True)
                    elif i == longest:
                        self._tw.write(fmt[i+1] % ("%6.4f" % times[i]), red = True, bold = True)
                    else:
                        self._tw.write(fmt[i+1] % ("%6.4f" % times[i]))
                    self._tw.write("|", bold= True) 
                sys.stdout.write("\n")
            print header_highlight
        else:
            for tc_name, results in xcomp_outcome_by_tc.iteritems():
                _print_header()
                stats['total_displayed'] += 1
                
                if args.short_name == True:
                    r = re.match("(.*)(\[.*\])(.*)", tc_name)                    
                    if r != None: # we have a match
                        tc_name = r.group(1).split(".")[-1] + r.group(2) + r.group(3)
                    else:
                        tc_name = tc_name.split(".")[-1]

                sys.stdout.write(fmt[0] % tc_name + "|")
                for i in range(len(results)):
                    result = str(results[i]) 
                    if result == "pass":
                        self._tw.write(fmt[i+1] % result, green = True, bold = True)
                    elif result == "fail":
                        self._tw.write(fmt[i+1] % result, red = True, bold = True)
                    elif result == "error":
                        self._tw.write(fmt[i+1] % result, yellow = True, bold = True)
                    elif result == "skip":
                        self._tw.write(fmt[i+1] % result, cyan = True)
                    else:
                        self._tw.write(fmt[i+1] % result)
                    self._tw.write("|", bold= True)
                sys.stdout.write("\n")
            print header_highlight
        # print the timing information
        timeing_info = fmt[0] % "EXECUTION TIME" + " "
        for i in range(len(args.xunit_report)):
            tmp = fmt[i+1] % "%-5.2f" % report_n2idx[args.xunit_report[i]]['xunit_obj'].time
            timeing_info += tmp
        
        self.line('\n')
        self.bold(header_highlight.replace('+', '-'), yellow = True)
        self.bold("Test cases displayed                : %s" % str(stats['total_displayed']))
        self.bold("Test cases collected (unique names) : %s" % str(stats['total_collected']))
        self.bold("Test cases filtered out             : %s" % str(len(stats['filtered_out'])))
        self.bold("Total cases processed               : %s" % str(stats['total_processed']))
        self.bold(timeing_info)
        
        
