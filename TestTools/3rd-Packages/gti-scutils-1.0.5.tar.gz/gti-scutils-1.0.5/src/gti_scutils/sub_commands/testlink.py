"""     
    This module contains sub commands to interact with the test link servers.
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""


import sys
import platform
import os
import argparse
import re
import types
import time
from textwrap import dedent
from pprint import pprint
import getpass
import py

import dolby.gti.testlink as testlink

from gti_scutils.model import ServerConfig
from gti_scutils.utils import GTISCUtilsBase


KNOWN_SERVERS = {
                  'us_prod' : ["http://testlink.dolby.net", "US  Production"],
                  'us_sand' : ["http://testlink-prod.eng.dolby.net", "US  Replicated production environment"],
                  'us_stage' : ["http://testlink-stage.eng.dolby.net/", "US  Next release staging environment"],
                  'nur_sand' : ["http://nur-testlink-sandbox.dolby.net/", "DE  Sanbox"],
                  'aus_prod' : ["http://aus-testlink.dolby.net/", "AUS Production"],
                }


class SCLogin(GTISCUtilsBase):
    '''\
        Logs in to the server. 
    
        When login to the server, it becomes the active session which 
        means that all other sub-commands are using this session. 
        
        If the user is not specified, the login user is used by default.
        
        see `use` command to learn how to switch sessions
        see `logout` to logout from the server. 
        
    '''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(SCLogin, self).__init__(name = "login", debug = debug, verbose = verbose)
        
        tmp =  "\tList of Servers\n"
        tmp += "\t===============\n"
        
        for k, s in KNOWN_SERVERS.iteritems():
            tmp += "\t%-20s %-40s %s\n" % (k, s[1], s[0])
        
        self.parser = subparsers.add_parser('login', 
                                            help='login to the soundcheck server', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            description = dedent(SCLogin.__doc__ + "\n" + tmp),
                                            parents = [common_parser])
        
        self.parser.add_argument('-u', '--user', 
                                action='store',
                                metavar = "user-id",
                                help = "user name")
    
        self.parser.add_argument('-d', '--dev-key', 
                                action='store',
                                metavar = "testlink devkey",
                                help = "development key")
    
        self.parser.add_argument('-s', '--server-url', 
                                action='store',
                                metavar = "string",
                                help = "sound check server url")

        self.parser.add_argument('-k',  
                                action='store',
                                metavar = "string",
                                choices= KNOWN_SERVERS.keys(),
                                help = "known servers - do --help for details")
        
        self.parser.set_defaults(func=self.login)
        
    def login(self, args):
        if args.server_url == None and args.k == None:
            self.parser.error(message = "You must specify a server url or a know server\n")
        if args.k != None:
            args.server_url = KNOWN_SERVERS[args.k][0]
        else:
            args.k = "custom"
        
        if args.user == None:
            args.user = getpass.getuser()
            
        if args.dev_key == None:
            cfg = ServerConfig()
            try:
                cfg.load_config(args.k, args.user)
            except:
                pass
            else:
                args.dev_key = cfg.dev_key
        
        oTLServer = None
        self.info("logging in to %s", args.server_url)
        try: 
            oTLServer = testlink.TLServer(  
                                         server_url   = args.server_url, 
                                         dev_key      = args.dev_key, 
                                         user_id      = args.user
                                      )
        except Exception as TLException:
            self.debug_dump_backtrace()
            self.parser.error("Failed to login to the server %s" % str(TLException))
        else:
            cfg = ServerConfig()
            cfg.save_config(config_name = args.k, 
                            server_url = oTLServer._server_url, 
                            user       = oTLServer._user_id, 
                            dev_key    = oTLServer._dev_key)
            self.success("Logged in")
        
            


class SCUse(GTISCUtilsBase):
    '''\
       Use a server previously logged in
    
    '''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(SCUse, self).__init__(name = "use", debug = debug, verbose = verbose)

        tmp =  "\tList of Servers\n"
        tmp += "\t===============\n"
        
        for k, s in KNOWN_SERVERS.iteritems():
            tmp += "\t%-20s %s\n" % (k, s[1])

        tmp += "\t%-20s %s\n" % ('custom', 'if user has defined any custom server')
        
        self.parser = subparsers.add_parser('use', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            help='use a soundcheck server', 
                                            description = dedent(SCUse.__doc__ + "\n" + tmp),
                                            parents = [common_parser])

        self.parser.add_argument('-k',  
                                action='store',
                                metavar = "string",
                                choices= KNOWN_SERVERS.keys().append('custom'),
                                help = "known servers - do --help for details")

        self.parser.add_argument('-u', '--user',
                                 metavar = "string", 
                                action='store',
                                help = "user name")
        
        self.parser.set_defaults(func=self.use)
        
    def use(self, args):
        cfg = ServerConfig()
        if args.k != None:            
            if args.user == None:
                args.user = getpass.getuser()
            try:
                cfg.load_config(args.k, args.user)
            except IOError as le:
                self.parser.error("Failed to set config '%s'user '%s' - %s" % (args.k, args.user, str(le)))
            except AttributeError as le:
                self.parser.error("'%s' - %s" % (args.user, str(le)))
            except Exception as le:
                self.parser.error("Unknown error loading config '%s'user '%s' - %s" % (args.k, args.user, str(le)))
            cfg.current_config = args.k

        self.bold("Current Configuration: %s", cfg.current_config)
        if cfg.current_config != None:
            self.bold("\tuser: %s", cfg.user)
            self.bold("\turl: %s", cfg.server_url)
            
                
        

class SCLogout(GTISCUtilsBase):
    '''Logout from the server'''
    
    def __init__(self, subparsers, common_parser, debug = False, verbose = False):
        
        super(SCLogout, self).__init__(name = "logout", debug = debug, verbose = verbose)
        
        self.parser = subparsers.add_parser('logout', 
                                            formatter_class=argparse.RawDescriptionHelpFormatter,
                                            help='logout from the soundcheck server', 
                                            description = SCLogout.__doc__,
                                            parents = [common_parser])

        self.parser.set_defaults(func=self.logout)
        
    def logout(self, args):
        cfg = ServerConfig()
        if cfg.current_config == None:
            self.warning("No current configuration set")
        else:
            self.action('logging out from %s', cfg.current_config)
            cfg.delete_config(cfg.current_config)
            self.success("Logged out")
            cfg.current_config = None 
           
