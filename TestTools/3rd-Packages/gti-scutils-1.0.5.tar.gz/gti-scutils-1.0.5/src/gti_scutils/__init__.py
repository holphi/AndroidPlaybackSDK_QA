import sys
import platform
import os
import re
import types
import shutil
import signal
import time
import datetime
from logging import getLogger, basicConfig
from pprint import pprint

__version__ = '1.0.5'

__p4datetime__ = '$DateTime: 2015/04/01 10:03:01 $'
__p4change__ = "$Change: 2169993 $"
__p4file__ = '$File: //depot/eng/gti/projects/gti_scutils/rel/1.0/src/gti_scutils/__init__.py $'

loglevel = "INFO" 

basicConfig(level=loglevel,
            format='[%(levelname)-4.4s] %(name)-15s: %(message)s')

def get_package_version(return_it = False):
    """ Returns the package version or print it on standard out. 
    
        Entry point for command ``version_gti_testbed``
        
        :param return_it: If set to True, the version string will be returned 
                          as opposed to be printed out (for programatic use).
    """
    if return_it:
        return __version__    
    print(__version__)

