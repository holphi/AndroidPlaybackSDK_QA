import os
import sys
import re
import xml.etree.ElementTree as ET
import types

CDATA = "![CDATA["

#
# The code below is a work around to serialize CDATA element. 
# source: http://stackoverflow.com/questions/174890/how-to-output-cdata-using-elementtree
# Basically you monkey patch the internal serialize_xml method 
#  
if sys.version_info < (2,7):
    etree_write = ET.ElementTree._write
    def _specmap_write(self, file, node, encoding, namespaces):
        #print type(node.tag), node.tag 
        if node.tag == CDATA:
            file.write("\n<%s%s]]>\n" % (node.tag, node.text))
        else:
            etree_write(self, file, node, encoding, namespaces)
    ET.ElementTree._write = _specmap_write
else:          
    etree_serialize_xml = ET._serialize_xml
    def _serialize_xml(write, elem, qnames, namespaces, foo = None):    
        if elem.tag == CDATA:
            write("\n<%s%s]]>\n" % (elem.tag, elem.text))
            return
        return etree_serialize_xml(
            write, elem, qnames, namespaces, foo)
        
    ET._serialize_xml = ET._serialize['xml'] = _serialize_xml  
    
def indent(elem, level=0):
    """ Indent a tree
    """ 
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i
            
def cdata_frame(text):
    text = str(text).strip()
    text = text.replace("\n", "<br>")
    element = ET.Element('![CDATA[')
    element.text = text
    return element