""" Contains classes to serialize and de-serialize specmap reports.

    specmap are in fact a sub-set of the structure of a test suite export 
    in testlink.
"""

import os
import sys
import re
import xml.etree.ElementTree as ET
import types

from dolby.gti.testlink.structures import Suite as PYTLSuite
from dolby.gti.testlink.structures import TestCase as PYTLTestCase
from gti_scutils.utils import GTISCUtilsBase
from gti_scutils.reports import CDATA, indent, cdata_frame
 



class SpecmapReportFile(GTISCUtilsBase):


    def __init__(self, specmap_file):
        
        self._specmap_file = os.path.abspath(specmap_file)
        
        super(SpecmapReportFile, self).__init__(name = os.path.basename(specmap_file))
        self._clear_struct()

    def _clear_struct(self):        
        self.specmap_tree_root = None
        self._suites = {}
        
        
        self._top_level_suite = PYTLSuite()
        self._top_level_suite.title = ""
        self._top_level_suite.parent_path = "/"
        
        self._num_suites = 0
        self._num_cases = 0
        self._load_errors = []
    
    @property
    def file_path(self):
        """ Returns the specmap file full qualified path"""
        return self._specmap_file
        
    @property
    def num_cases(self):
        """ Returns the number of test cases in the specmap file"""
        return self._num_cases

    @property
    def num_suites(self):
        """ Returns the number of suite found in the specmap file"""
        return self._num_suites        

    @property
    def load_errors(self):
        """ Returns the number of errors that occured while loading the specmap"""
        return self._load_errors  
        
    def get_all_test_cases(self):
        """ Returns a list of all test cases in the specmap"""
        all_test_cases = []
        
        def get_sub_test_cases(parent_suite_obj):
            for suite_obj in parent_suite_obj._suites:
                all_test_cases.extend(suite_obj._cases)
                get_sub_test_cases(suite_obj)
                
        get_sub_test_cases(self._top_level_suite)
        
        return all_test_cases
    
    def add_test_case(self, base, title):
        """ Creates and adds a test case to the specified base path
        
            :param base: can be a base path or a suite object. Base can not be at the root (i.e. /)
            :param title: the test case title.
            
            This create a test case in the specified suite path (base) which may or may not
            exist. Internally it invokes create_suite() to get the leaf suite of the path.
            
            :rtype: a TestCase object from dolby.gti.testlink.structures
            
            :raises: TypeError if base isn't a supported type
            :raises: ValueError if base is at the root
        """
        suite_obj = None
        
        if type(title) != types.StringType:
            raise TypeError("'title' must be a string")

        if isinstance(base, PYTLSuite) == True:
            suite_obj = base
            base = suite_obj.parent_path
        
        if type(base) == types.StringType:
            base = base.strip("/") # remove leading a trailing /
            if len(base.strip()) == 0:
                raise ValueError("'base' can not be empty") 
        else:
            raise TypeError("base '{0}' must be a string or a Pytl Suite")
        
        case_obj = self.find(base + "/" + title)
        
        if case_obj == None:
            suite_obj = self.add_test_suite(base = base)
            assert suite_obj != None
            case_obj = PYTLTestCase()
            case_obj.parent_path = suite_obj.path
            case_obj.title = title
            suite_obj.add_case(case_obj)
            self._num_cases += 1
        assert case_obj != None
        return case_obj
        
    def add_test_suite(self, base, suite_name = None):
        """ Creates and adds a test suite to the specified base path
        
            :param base: can be a base path or a suite object. Base can not be at the root (i.e. /)
            :param title: the test suite title which is optional.
            
            If the suites specified in 'base' do not exist, they will be created along the way.
            The title is only required when the base is a suite object. It may or may no be specfied
            when base is a path like string. If not specified, the last element in the string is the 
            target suite
            
            **Example**::
                s = new_report.add_test_suite(base='/foo/boo/zoo')
                # equivalent
                s = new_report.add_test_suite(base='/foo/boo', suite_name= 'zoo')
            
            :rtype: a Suite object from dolby.gti.testlink.structures
            
            :raises: TypeError if base isn't a supported type
            :raises: ValueError if base is at the root
        """        
        current_suite_obj = self._top_level_suite
        
        if suite_name != None and type(suite_name) != types.StringType:
            raise TypeError("'suite_name' must be a string")        

        if isinstance(base, PYTLSuite) == True:
            if suite_name == None:
                raise ValueError("'suite_name' must be specified with a suite object")
            current_suite_obj = base
            if type(current_suite_obj.parent_path) != types.StringType:
                raise TypeError("suite {0} must have the parent path set to string".format(current_suite_obj))
            base = current_suite_obj.path
                    
        if type(base) == types.StringType:
            if suite_name != None:
                base = base + "/" + suite_name
            base = base.strip("/") # remove leading a trailing /
            if len(base.strip()) == 0:
                raise ValueError("'base' can not be empty") 
        else:
            raise TypeError("base '{0}' must be a string or a Pytl Suite") 

        current = []

        for s in base.split("/"):
            current.append(s)
            spath = "/".join(current)
            self.debug_info("seraching {0}".format(spath))
            new_suite_obj = self.find(spath)
            if new_suite_obj == None:
                new_suite_obj = PYTLSuite()
                new_suite_obj.parent_path = current_suite_obj.path
                new_suite_obj.title = s
                current_suite_obj.add_suite(new_suite_obj)
                self._num_suites += 1
            current_suite_obj = new_suite_obj
        
        assert current_suite_obj != None
        return current_suite_obj
                
        
    def save(self, new_file_path = None):
        """ Save the specmap tree to a file.
        
            :param new_file_path: If specified, will be stored in that file, othewise uses the file specified 
                                  in the constructor.
        """
        self._specmap_file = new_file_path if new_file_path != None else self._specmap_file 
        
        self.info("saving report to {0}".format(self._specmap_file))
        
        def serialize_suite(current_elem, suite, level = 0):
            if current_elem == None:
                self.debug_info("creating root element")
                current_elem = ET.Element('testsuite', {'name' : suite.title})
            else:
                new_elem = ET.Element('testsuite', {'name' : suite.title})
                if suite.summary != None:
                    ET.SubElement(new_elem, 'details').append(cdata_frame(suite.summary))
                current_elem.append(new_elem)
                current_elem = new_elem
            #print "  "*level + "suite = ", suite.title
            
            for sub_suite in suite._suites:
                serialize_suite(current_elem = current_elem, suite = sub_suite, level = level + 1)
            
            level += 1
            for test_case in suite._cases:
                #print "  "*level + "case = ", test_case.title
                attrib = {'name' : test_case.title}
                if test_case.uid != None:
                    attrib['internalid'] = str(test_case.uid)
                case_elem = ET.Element('testcase', attrib)
                
                if test_case.id != None:
                    ET.SubElement(case_elem, 'externalid').append(cdata_frame(test_case.id))
                
                if test_case.summary != None:
                    ET.SubElement(case_elem, 'summary').append(cdata_frame(test_case.summary)) 
                current_elem.append(case_elem)
            return current_elem
                
        etree = ET.ElementTree(serialize_suite(current_elem = None, suite = self._top_level_suite))
        indent(etree.getroot())
        etree.write(self._specmap_file)
    
    def load(self):
        """ Load the specmap file in memory
        """
        self._clear_struct()
        if os.path.isfile(self._specmap_file) == False:
            raise(IOError("Specmap file {0} not found".format(self._specmap_file)))        
        self.info("Loading specmap file {0}".format(self._specmap_file))
        try:
            self.specmap_tree_root = ET.ElementTree(file = self._specmap_file).getroot()
        except Exception as pe:
            self.debug_dump_backtrace()
            raise TypeError("specification map '{0}' doesn't appear to be a valid xml document '{1}'".format(self._specmap_file. pe))

        self._load_suite(elem = self.specmap_tree_root, parent_suite = self._top_level_suite)
        
        
    def __str__(self):
        return "specmap = {0}\nsuites {1} cases {2} load_errors {3}".format(self._specmap_file, self._num_suites, self._num_cases, len(self._load_errors))
    
    def find(self, path):
        """ Finds an element (suite or test case) according to its full qualified path
        
            :param path: the full qualified path of the object.
            
            :rtype: An instance of a ``dolby.gti.testlink.structures.Suite`` or ``dolby.gti.testlink.structures.TestCase`` on success
            :rtype: None if the object could not be located.
        """
        path = path.strip("/")
        current_suite = self._top_level_suite
        paths = path.split("/")

        for i in range(len(paths)):
            p = paths[i]
            parent = current_suite
            self.debug_info("searching for suite [{0}] '{1}'".format(i,p))
            for sub_suite in current_suite._suites:
                if p.lower() == sub_suite.title.lower():
                    current_suite = sub_suite
                    break

            if parent != current_suite:
                if i == len(paths) -1: # The last element has been found and it is a suite
                    return current_suite
            else:
                if i == len(paths) -1:
                    pass # This may be a test case
                else:
                    self.debug_info("Not found")
                    return None
            

        
        self.debug_info("searching for test case '{0}'".format(paths[-1]))
        for case in current_suite._cases:
            if case.title.lower() == paths[-1].lower():
                return case
        self.debug_info("Not found")
        return None                
        
    def _load_suite(self, elem, parent_suite):
        
        self.debug_info("processing suite '{0}' childs".format(parent_suite.path))
        
        suite_elems = elem.findall("./testsuite")
        if len(suite_elems) > 0:
            self.info("processing '{0}' child suites from '{1}'".format(len(suite_elems), parent_suite.path))        
            for suite_elem in suite_elems:
                try:
                    suite_obj = PYTLSuite()
                    suite_obj.parent_path = parent_suite.path
                    suite_obj.title = suite_elem.attrib['name'] 
                    
                    details_elem = suite_elem.find("details")
                    if details_elem != None:
                        if details_elem.text == None:
                            if tmp[0].tag == CDATA:
                                suite_obj.summary = details_elem[0].text                    
                        else:
                            suite_obj.summary = details_elem.text
                            
                    parent_suite.add_suite(suite_obj)
                    self.debug_info("loaded suite '{0}' - parent '{1}'".format(suite_obj.path, parent_suite.path))
                    
                    self._num_suites += 1
                    self._load_suite(elem = suite_elem, parent_suite = suite_obj)
                except Exception as le:
                    self.debug_dump_backtrace()
                    self._load_errors.append("failed to load suite '{0}' - error '{1}'".format(suite_elem.attrib.get('name', "no name"), le))

                
        case_elems = elem.findall("./testcase")
        
        if len(case_elems) > 0:
            self.info("processing '{0}' child cases from '{1}'".format(len(case_elems), parent_suite.path))        
            for case_elem in case_elems:
                try:
                    case_obj = PYTLTestCase()
                    case_obj.parent_path = parent_suite.path
                    case_obj.title = case_elem.attrib['name']
                    case_obj.uid = case_elem.attrib.get('internalid')
                    
                    externalid_elem = case_elem.find("externalid")
                    if externalid_elem != None:
                        if externalid_elem.text == None:
                            if externalid_elem[0].tag == CDATA:
                                case_obj.id = externalid_elem[0].text                    
                        else:
                            case_obj.id = externalid_elem.text                

                    summary_elem = case_elem.find("summary")
                    if summary_elem != None:
                        if summary_elem.text == None:
                            if summary_elem[0].tag == CDATA:
                                case_obj.summary = summary_elem[0].text.replace("<br>", "\n")                   
                        else:
                            case_obj.summary = summary_elem.text.replace("<br>", "\n")  
                                           
                    
                    parent_suite.add_case(case_obj)
                    self.debug_info("loaded case '{0}' - parent '{1}'".format(case_obj.path, parent_suite.path))
                    self._num_cases += 1
                except Exception as le:
                    self._load_errors.append("failed to load case '{0}' - error '{1}'".format(case_elem.attrib.get('name', "no name"), le))
                
            
        




