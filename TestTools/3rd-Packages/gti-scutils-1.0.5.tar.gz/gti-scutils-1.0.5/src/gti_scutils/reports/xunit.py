""" Contains classes to serialize and de-serialize xunit reports.
"""

import os
import sys
import re

import xml.etree.ElementTree as ET
import types
import weakref
from gti_scutils.utils import GTISCUtilsBase
from gti_scutils.reports import CDATA, indent, cdata_frame


class XUNITTestCase(GTISCUtilsBase):
    """ An XUnit Test Case
    """
    
    def __init__(self, name, parent_suite):
        super(XUNITTestCase, self).__init__(name = name)
        self._time = 0.0
        self._classname = None
        self._parent_suite = weakref.proxy(parent_suite)
        self._parent_suite._tests += 1
        self._parent_suite._test_collected += 1
        self._parent_suite._passed += 1
        
        self._message = ""
        self._additional_info = ""
        self._stdout = ""
        self._stderr = ""
        self._outcome = "pass"
        
    @property
    def name(self):
        """ test case name (read only)"""
        return self._object_name
    
    @property
    def message(self):
        return self._message or ''

    @property
    def additional_info(self):
        return self._additional_info or ''
    
    @property
    def time(self):
        """ test time in seconds"""
        return self._time
    @time.setter
    def time(self, value):
        old_time = self._time
        try:
            self._time = float(value)
            if old_time != -1:
                self._parent_suite._test_time = self._parent_suite._test_time - old_time + self._time
            else:
                self._parent_suite._test_time = self._parent_suite._test_time + self._time
        except Exception as e:
            self.warning("time is not found or invalid %s", str(e))
            self._time = -1
                        
    @property
    def stdout(self):
        """ standard out"""
        return self._stdout or ''

    @property
    def stderr(self):
        """ standard error"""
        return self._stderr or ''

    @stdout.setter
    def stdout(self, value):
        self._stdout = value

    @stderr.setter
    def stderr(self, value):
        self._stderr = value
    
    @property
    def classname(self):
        return self._classname
        
    @classname.setter
    def classname(self, value):
        if type(value) != types.StringType:
            raise TypeError("test case '{0}' value can not be {1} type {2}".format(self.name, value, type(value)))
        self._classname = value
    
    @property
    def outcome(self):
        """ Test Case outcome.
        
            Possible values are:
            
                - pass
                - failure
                - skipped
                - error
        """
        return self._outcome
        
    def error(self, message, text = None, stdout = None, stderr = None):
        self._message = message
        self._additional_info = text
        self._stdout = stdout
        self._stderr = stderr 
        self._parent_suite._errors += 1   
        self._parent_suite._tests -= 1 
        self._parent_suite._passed -= 1 
        self._outcome = "error"     
    
    def failure(self, message, text = None, stdout = None, stderr = None):
        self._message = message
        self._additional_info = text
        self._stdout = stdout
        self._stderr = stderr
        self._parent_suite._failures += 1
        self._parent_suite._passed -= 1  
        self._outcome = "failure"  
    
    def skip(self, message, text = None):
        self._message = message
        self._additional_info = text
        self._parent_suite._skips += 1
        self._parent_suite._tests -= 1
        self._parent_suite._passed -= 1 
        self._outcome = "skipped"     
        
class XUNITTestSuite(GTISCUtilsBase): 
    """
    
            The properties names match the attribute o fthe testsuite element.
    
            **Raw XML**::
            
                <testsuite errors="184" failures="38" name="" skips="5" tests="566" time="6433.453">            
    """ 
    def __init__(self, name):
        super(XUNITTestSuite, self).__init__(name = name)
        self._time = 0.0
        self._test_time = 0.0
        self._failures = 0
        self._errors = 0   
        self._skips = 0
        self._tests = 0  
        self._test_collected = 0
        self._passed = 0
        self._test_cases = []     

    @property
    def test_time(self):
        """ Returns the time spent in tests -> setup time = time - test_time"""
        return self._test_time

    @property
    def name(self):
        """ test suite name (from xunit report)"""
        return self._object_name

    @property
    def time(self):
        """ session time (from xunit report)"""
        return self._time  
        
    @time.setter
    def time(self, value):
        self._time = float(value)  
    
    @property
    def failures(self):
        """ number of failures (from xunit report)"""
        return self._failures   
    
    @property
    def errors(self):
        """ number of errors (from xunit report)"""
        return self._errors 
    
    @property
    def skips(self):
        """ number of skipped tests (from xunit report)"""
        return self._skips

    @property
    def tests(self):
        """ number of test executed (pass+fail) (from xunit report)"""
        return self._tests  

    @property
    def collected(self):
        """ total number of tests cases (computed)"""
        return self._test_collected  

    @property
    def passed(self):
        """ test cases passing (computed)"""
        return self._passed  
    
    def add_test_case(self, name):
        self._test_cases.append(XUNITTestCase(name, self) ) 
        return self._test_cases[-1]
    
    @property
    def test_cases(self):
        return self._test_cases
    
class XUNITReportFile(GTISCUtilsBase):


    def __init__(self, xunit_file, suite_name = None):
        
        self._xunit_file = os.path.abspath(xunit_file)
        
        super(XUNITReportFile, self).__init__(name = os.path.basename(xunit_file))  
        
        self._suite = XUNITTestSuite(name = suite_name or os.path.basename(xunit_file))
        
    @property
    def file_path(self):
        return self._xunit_file

    @property
    def suite(self):
        """ Returns the xunit :py:class:`XUNITTestSuite <gti_scutils.reports.xunit.XUNITTestSuite>`
        """
        return self._suite
    
    def load(self):
        """ Loads the xunit report. 
        
            :raises: TypeError if the xml file doesn't appear to be a proper xunit report.
            :raises: ValueError if the calculated stats don't match the test suite stats found in the report.
            
            :note: If ValueError is raised, the content of the report may be valid. 
        """
        if os.path.isfile(self._xunit_file) == False:
            raise(IOError("xunit file {0} not found".format(self._xunit_file)))        
        self.info("Loading xunit file {0}".format(self._xunit_file))
        
        try:
            self.xunit_tree_root = ET.ElementTree(file = self._xunit_file).getroot()
        except Exception as pe:
            self.debug_dump_backtrace()
            raise TypeError("xunit map '{0}' doesn't appear to be a valid xml document '{1}'".format(self._xunit_file,pe))
        
        if self.xunit_tree_root.tag != "testsuite":
            raise TypeError("Top level element is not a 'testsuite' but '{0}'".format(self.xunit_tree_root.tag))
        
        self._suite = XUNITTestSuite(name = self.xunit_tree_root.attrib.get('name', '?'))
        self._suite.time = self.xunit_tree_root.attrib.get('time', 0)
        
        def get_output(elem):
            out = {'stdout' : None, 'stderr' :None}
            for child in elem:
                if child.tag == 'system-out':
                    out['stdout'] = child.text
                if child.tag == 'system-err':
                    out['stderr'] = child.text
            return out   
        
        
        
        for case_elem in self.xunit_tree_root.findall(".//testcase"):
            self.info("loading test case {0}".format(case_elem.attrib['name']))
            xunit_case = self._suite.add_test_case(name = case_elem.attrib['name'])
            xunit_case.time = case_elem.attrib.get('time', 0)
            xunit_case.classname = case_elem.attrib.get('classname', None)
            for child_elem in case_elem:
                if child_elem.tag == 'skipped':
                    xunit_case.skip(message = child_elem.attrib.get('message', "None"), text = child_elem.text)
                elif child_elem.tag == 'failure':
                    xunit_case.failure(message = child_elem.attrib.get('message', "None"), text = child_elem.text, **get_output(child_elem))
                elif child_elem.tag == 'error':
                    xunit_case.error(message = child_elem.attrib.get('message', "None"), text = child_elem.text, **get_output(child_elem))
                elif child_elem.tag == 'system-err' or child_elem.tag == 'system-out':
                    pass
                else:
                    self.warning("unknown test case element {0}".format(child_elem.tag))
        self.info("loaded report name={0} collected={1} time={2} executed={3} pass={4} skips={5} errors={6} failures={7}".format(
                    self._suite.name, 
                    self._suite.collected, 
                    self._suite.time, 
                    self._suite.tests,
                    self._suite.passed, 
                    self._suite.skips, 
                    self._suite.errors, 
                    self._suite.failures))
        self.info("verifying stats")
        stats = {'errors' : 0, 'failures' : 0, 'skips' : 0, 'tests' : 0}
        mismatch = ""
        for k in stats.keys():
            stats[k] = int(self.xunit_tree_root.attrib.get(k, 0))       
            if stats[k] != getattr(self._suite, k):
                mismatch += "('{0}' calculated={1} actual={2}) ".format(k, stats[k], getattr(self._suite, k))
        if mismatch != "":
            raise ValueError("test suite stats are corrupted " + mismatch)
        
    
    def save(self, new_xunit_file_path = None):
        """ Save the xunit tree to a file.
        
            :param new_xunit_file_path: If specified, will be stored in that file, othewise uses 
                                  the file specified in the constructor.
        """
        self._xunit_file = new_xunit_file_path if new_xunit_file_path != None else self._xunit_file 
        
        self.info("saving report to {0}".format(self._xunit_file))
        
        root_elem = ET.Element('testsuite', {'name' : str(self._suite.name),
                                             'errors' : str(self._suite.errors),
                                             'failures' : str(self._suite.failures),
                                             'skips' : str(self._suite.skips),
                                             'tests' : str(self._suite.tests),
                                             'time' : str(self._suite.time)
                                            })
        
        for tc in self.suite.test_cases:
            tc_elem = ET.Element('testcase', {'name' : str(tc.name), 'classname' :str(tc.classname),'time' : str(tc.time)})            
            if tc.outcome != 'pass':
                diag_elem = ET.Element(tc.outcome, {'message' : str(tc.message)})
                diag_elem.text = tc.additional_info
                tc_elem.append(diag_elem)
            if tc.stdout != '':
                diag_elem = ET.Element('system-out')
                diag_elem.text = tc.stdout
                tc_elem.append(diag_elem)
            if tc.stderr != '':
                diag_elem = ET.Element('system-err')
                diag_elem.text = tc.stderr
                tc_elem.append(diag_elem)
            root_elem.append(tc_elem)
            
        
        etree = ET.ElementTree(root_elem)
        indent(etree.getroot())
        etree.write(self._xunit_file, xml_declaration = True, encoding = "utf-8")
        
        
        
        