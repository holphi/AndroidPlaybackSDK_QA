"""     
    gti-scutils model implementation
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""

import os
import sys
import re
import zipfile
import tempfile
import types
import traceback
from ConfigParser import ConfigParser
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
from pprint import pprint

from gti_scutils.utils import get_user_home_dir, convert_second_to_hms, wget, GTISCUtilsBase
from gti_scutils.reports.specmap import SpecmapReportFile
from gti_scutils.reports.xunit import XUNITReportFile
# Testlink stuff
import dolby.gti.testlink as testlink
from dolby.gti.testlink.structures import TestCase as SCTestCase
from dolby.gti.testlink.structures import Build as SCBuild

import dolby.gti.testlink.const as SCConst
from dolby.gti.testlink.commands import *
from dolby.gti.testlink.commands import getTestPlanPlatforms
from dolby.gti.testlink.structures import Suite as TLSuite
import dolby.gti.testlink.const as SCConst


try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
    
XU_PASS  = "pass"
XU_FAIL  = "fail"
XU_SKIP  = "skip"
XU_ERROR = "error"
CDATA = "![CDATA["

XU_VALID_OUTOME = [XU_PASS, XU_FAIL, XU_SKIP, XU_ERROR]

OUTCOME_TRANS = { XU_PASS : SCConst.OUTCOME_PASS,
                  XU_FAIL : SCConst.OUTCOME_FAIL,
                  XU_SKIP : SCConst.OUTCOME_NOT_EXECUTED,
                  XU_ERROR : SCConst.OUTCOME_BLOCKED,
                }

XUNIT_TO_SCUTILS = { 'pass'    : XU_PASS,
                     'failure' : XU_FAIL,
                     'skipped' : XU_SKIP,
                     'error'   : XU_ERROR                    
                   }

class TestCaseBase(GTISCUtilsBase):
    
    def __init__(self, parent_report, specmap_report = None):
        """ Base class for all test cases
        
            :param specmap_report: An xml.etree.ElemenTree.Element root object.
        """
        
        super(TestCaseBase, self).__init__(name = 'undefined')
        
        self._outcome = XU_PASS
        self._sc_outcome = None
        self._message = None
        self._backtrace = None
        self._skip_location = None
        self._system_out = None
        self._system_err = None
        self._classname = "undefined"
        self._suite_path = None
        self._name = "undefined"
        self._time = 0
        self._specmap_report = specmap_report
        self._specmap_test_case = None
        
        self._sc_spec_case = None
        self._sc_set_case = None
        
        self._parent_report = parent_report
        
    @property
    def parent_report(self):
        return self._parent_report
        

    @property
    def sc_set_case(self):
        if self._sc_set_case == None:
            self._sc_set_case = self.parent_report._get_test_set_case(self.sc_spec_case)
        return self._sc_set_case
    
    @property
    def stdout(self):
        return self._system_out

    @property
    def stderr(self):
        return self._system_err
        
    @property
    def outcome(self):
        return self._outcome
        
    @property
    def message(self):
        return self._message

    @property
    def backtrace(self):
        return self._backtrace

        
    @property
    def classname(self):
        return self._classname

    @property
    def fqname(self):
        """ Full qualified name consisting of class and test name"""
        return self._classname + ":" + self._name
        
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):        
        self._name = value
        self._object_name = value

    @property
    def suite_path(self):
        """ Returns the suite path in the form suite_1/suite_2/suite_3 ...
        """
        if self._suite_path == None:
            
            if self._parent_report._ignore_base != None:
                
                ignore = self._parent_report._ignore_base
                if ignore.startswith(".") == True:                                       
                    ignore = "^" + ignore[1:]# start from the begining
                    ignore = ignore.replace(".", "\.")
                else:
                    ignore = ignore.replace(".", "\.")
                    ignore = "^.*" + ignore
                                               
                if sys.version_info < (2,7):
                    self.warning("ignore base is case sensistive on 2.6")
                    self._suite_path = re.sub(ignore, "", self.classname)
                else:
                    self._suite_path = re.sub(ignore, "", self.classname,  re.IGNORECASE)
                   
                if self._suite_path.startswith(".") == True:
                    self._suite_path = self._suite_path[1:]
            else:
                if self.classname.startswith("src."):
                    self._suite_path = self.classname.replace("src.", "")
                elif self.classname.startswith("test."):
                    self._suite_path = self.classname.replace("test.", "")
                else:
                    self._suite_path = self.classname
            self._suite_path = self._suite_path.replace(".", "/")        
        return self._suite_path
           
    @property
    def time(self):
        return self._time
    
    @property
    def test_proc_name(self):
        "Returns the test procedure portion of a test"
        try:
            return re.match("(.+)\[(.+)\]", self.name).group(1)
        except:
            return self.name
        
    def upload_outome(self, note_info = None):
        """ This method uploads the outcome as well as the note info to the 
            testlink server.
            
            :param: note_info a string containing text to be uploaded with the 
                    results. If not specified, the path to the xunit report, the 
                    error details if any will be uploaded.
        """
        
        if self.parent_report.dry_run == True:
            self.warning("not updating results in dry mode")
            return
        
        if self.sc_outcome == SCConst.OUTCOME_NOT_EXECUTED:
            self.debug_info("Test is not executed, not updating results")
            return
        
        if self.sc_outcome == self.sc_set_case.outcome:
            self.debug_info("{0} {1} outcome on server already set to {2} - not updating".format(
                                                        self.sc_set_case.fid, 
                                                        self.sc_set_case.title, 
                                                        self.sc_set_case.outcome))
            return 
        
        
        if self.parent_report.server_config.fast_upload == True:
            platform_id = None
            if self.parent_report.sc_platform != None:
                platform_id = self.parent_report.sc_platform.id
                
            cmd = reportTCResult(case_id = self.sc_set_case.fid,
                                 plan_id = self.parent_report.sc_test_set.id,
                                 build_id = self.parent_report.sc_build.id,
                                 platform_id = platform_id,
                                 outcome = SCConst._OUTCOME_TO_TL[self.sc_outcome],
                                 notes = note_info
                                 )
            if self.parent_report.server_config.sc_server.send_command(cmd) == False or cmd.response != True:
                raise ValueError ("Failed to set test case {0} {1} outcome on server `{2}` - {3} {4}".format(
                                                        self.sc_set_case.fid, 
                                                        self.sc_set_case.title, 
                                                        self.sc_set_case.outcome, 
                                                        cmd.error_code, 
                                                        cmd.error_msg))            
        else:
            if self.sc_outcome != self.sc_set_case.outcome:
                self.sc_set_case.set_result(self.sc_outcome, notes = note_info)
        
    @property 
    def sc_outcome(self):
        if self._sc_outcome == None:
        
            self._sc_outcome = OUTCOME_TRANS[self.outcome]
        
            if self.outcome == XU_SKIP: # feature request GTITA-17
               _message = self.message.lower()
               if re.match("xfail\-marked\s*test\s*passes\s*unexpectedly", _message) != None:
                   self._sc_outcome = SCConst.OUTCOME_PASS
                   self._message = "XUNIT SKIPPED test case marked as PASS : " + str(_message)
               elif  re.match(".*skipped\s*instance.*", _message) != None:
                   self._sc_outcome = SCConst.OUTCOME_NOT_EXECUTED
                   self._message = "XUNIT SKIPPED test case marked as NOT EXECUTED : " + str(_message)
               else:
                   self._sc_outcome = SCConst.OUTCOME_BLOCKED
                   self._message = "XUNIT SKIPPED test case marked as BLOCKED : " + str(_message)
               self._skipped_processed = True
    
        return self._sc_outcome
    
    @property
    def sc_execution_type(self):
        return SCConst.EXECUTION_TYPE_AUTOMATIC

    
    @property
    def external_id(self):
        """ Returns the testlink external ID if it is found in the specmap file. 
            returns None otherwise
        """
        if self.specmap_test_case != None :
            return self.specmap_test_case.id

    @property
    def uid(self):
        """ Returns the test case UID if present in the specmap file.
            None otherwise.
        """ 
        if self.specmap_test_case != None :
            return self.specmap_test_case.uid
    
    @property
    def summary(self):  
        if self.specmap_test_case != None:
            return self.specmap_test_case.summary
        return "created by gti_scutils"

         
    
    @property
    def specmap_test_case(self):
        """ Returns the XML element in the specmap file matching the test case
        """

        if self._specmap_report != None and self._specmap_test_case == None:

            self.info("find test case {0} in {1} from specmap file".format(self.name, self.suite_path))
            
            try:
            
                root_suite = None
                suite_path_list = self.suite_path.split("/")
                
                for suite_name in self.suite_path.split("/"):
                    root_suite = self._specmap_report.find("/" + suite_name)
                    if root_suite == None:
                        suite_path_list.pop(0)
                    else:
                        break
                    
                if len(suite_path_list) == 0:
                    self.warning("could not find matching suite '{0}' in specmap report".format(self.suite_path))
                    return
                suite_path_list.append(self.name)
                self._specmap_test_case = self._specmap_report.find("/".join(suite_path_list) )

            except Exception as pe:
                self.warning("Failed to get the suite information '{0}' error `{1}`".format(self.suite_path, pe))
                self.debug_dump_backtrace()
            
        return self._specmap_test_case               
        
    @property
    def sc_spec_case(self):
        """ Returns the testlink (soundcheck) test set test case object associated to that object. 
        
        """
        if self._sc_spec_case == None:
            
            # Check if the test case can be found by ID
            if self.external_id != None and type(self.external_id) == types.IntType:
                tc_id = "{0}-{1}".format(self.parent_report.sc_project.prefix, self.external_id)
                self.info("looking up test case {0} by external id {1}".format(self.fqname, tc_id))
                cmd = getTestCase(case_id        =  tc_id)
                if self.parent_report.server_config.sc_server.send_command(cmd) == False:
                    self.warning("Failed to retrieve test case '{0}' with id '{1}' from server".format(self.name, tc_id))
                else:
                    self.info("test case id '{0}' found".format(tc_id))
                    self._sc_spec_case = cmd.response
                    self._sc_spec_case.prefix = self.parent_report.sc_project.prefix

        if self._sc_spec_case == None: 

            parent_suite = self.parent_report.sc_base_suite
            
            self.debug_info("base suite {0} with id {1} on TL".format(parent_suite.title, parent_suite.id))
                    
            if self.parent_report.keep_structure == True:
                parent_suite = self.parent_report._get_ts_leaf_suite(suite_paths = self.suite_path.split('/'), parent_obj = parent_suite)
                
            if self.parent_report.server_config.fast_upload == True:
                
                    
                if parent_suite == None:
                    assert self.parent_report.dry_run == False, "Running in dry mode. Nothing to be done"
                    raise ValueError("Failed to locate parent test suite")
                
                # Get the test case by name.
                self.info("Getting test case '{0}' suite '{1}' from project '{2}'".format(self.name, parent_suite.title, self.parent_report.sc_project.name))
    
                cmd = getTestCaseIDByName(case_title = self.name, suite_title = parent_suite.title, project_name = self.parent_report.sc_project.name)
                tc_suite_list = []
                if self.parent_report.server_config.sc_server.send_command(cmd) == False:
                    self.warning("Failed to get test case '{0}' - {1} {2}".format(self.name, cmd.error_code, cmd.error_msg))
                    assert self.parent_report.dry_run == False, "Running in dry mode. Nothing to be done"
                else:
                    tc_suite_list = cmd.response
                
                if len(tc_suite_list) > 1:
                    self.warning("More than one instance matching the specified test case, searching")
                    tmp = tc_suite_list
                    tc_suite_list = []
                    for tc in tmp:
                        if tc.parent_id == parent_suite.id:
                           tc_suite_list = [tc]
                           break

                if len(tc_suite_list) == 1 and parent_suite.id != tc_suite_list[0].parent_id:
                    self.warning("Found an instance of test case {0} but in a different suite".format(tc_suite_list[0].title))
                    tc_suite_list = []
                        
                if self._sc_spec_case == None: 
                    # We only want to go further if the test case is still unknow
                    # If in the case of multiple match, we still haven't found the test case, we will create it.
                    if len(tc_suite_list) == 0:
                        
                        assert self.parent_report.dry_run == False, "'%s' No test case creation in dry run mode" % self.name
                        
                        self.info("creating test case {0} in suite {1}".format(self.name,parent_suite.title))
                        
                        cmd = createTestCase(name        = self.name,
                                             project_id  = self.parent_report.sc_project.id,
                                             suite_id    = parent_suite.id,
                                             author_id   = self.parent_report.server_config.user,
                                             summary     = self.summary
                                        ) 
                        if self.parent_report.server_config.sc_server.send_command(cmd) == False:
                            raise ValueError("Failed to create test case '{0} - {1} {2}".format(self.name, cmd.error_code, cmd.error_msg))
                        uid = cmd.response
                        self.info("fetching details for test case uid {0}".format(uid))
                        
                        cmd = getTestCase(case_unique_id = cmd.response)
                        if self.parent_report.server_config.sc_server.send_command(cmd) == False:
                            raise ValueError("Failed to get test case '{0} uid {1}- {2} {3}".format(self.name, uid, cmd.error_code, cmd.error_msg))
                        
                        self._sc_spec_case = cmd.response
                    else:
                        cmd = getTestCase(case_unique_id = tc_suite_list[0].uid)
                        if self.parent_report.server_config.sc_server.send_command(cmd) == False:
                            raise ValueError("Failed to get test case '{0} uid {1}- {2} {3}".format(self.name, uid, cmd.error_code, cmd.error_msg))                        
                        self._sc_spec_case = cmd.response
                        
                if self._sc_spec_case != None:
                    self._sc_spec_case.prefix = self.parent_report.sc_project.prefix
                
            else:
            
                # get the test from the spec.
                self._sc_spec_case = parent_suite.get_test_case(id = self.name)
                
                if self._sc_spec_case != None:
                    if type(self._sc_spec_case) == types.ListType:
                        tmp = self._sc_spec_case
                        self._sc_spec_case = None
                        for tc in tmp:
                            if tc.parent_id == parent_suite.id:
                               self._sc_spec_case = tc
                               break 
                   
                if self._sc_spec_case == None:
                    
                    assert self.parent_report.dry_run == False, "'%s' No test case creation in dry run mode" % self.name
                    
                    self.info("creating test case {0} in suite {1}".format(self.name, parent_suite.title))
                    self._sc_spec_case = parent_suite.create_test_case(title = self.name, 
                                                     summary = self.summary, 
                                                     precondition='',
                                                     execution_type = self.sc_execution_type)
                    
                    assert self._sc_spec_case != None, "Failed to create test case '%s' - aborting" % self.name

        
        return self._sc_spec_case
    
        

class CompoundedTestCase(TestCaseBase):
    
    def __init__(self, parent_report, specmap_report = None):
        super(CompoundedTestCase, self).__init__(parent_report = parent_report, specmap_report = specmap_report)
        self._message = ""
        self._pass_count = 0
        self._skip_count = 0
        self._error_count = 0
        self._fail_count = 0
        self._total_count = 0
        self._tc_list = []
      
    @property  
    def xunit_tests(self):
        return self._tc_list
        
        
    def add_xunit(self, xunit_test_obj):
        """ Add a unit test to the compound results. 
        
            When adding a test case, the rule is the following:
            
            If a test case is already marked as failed, it will remain failed. 
            If a test case is not failed and marked as passed, it will be passed
        """
        
        if len(self._tc_list) == 0:
            self._classname = xunit_test_obj.classname
            self.name = xunit_test_obj.test_proc_name
            self._outcome = xunit_test_obj.outcome
        
        if self.test_proc_name != xunit_test_obj.test_proc_name:
            raise AttributeError("Test name mistmatch - expects %s instead of %s" % (str(self.test_proc_name ), str(xunit_test_obj.test_proc_name)))

        if self.classname != xunit_test_obj.classname:
            raise AttributeError("Test name %s found in different class %s" % (str(self.test_proc_name ), str(xunit_test_obj.classname)))
                
        
        if xunit_test_obj.outcome == XU_PASS:
            self._pass_count += 1
            self._time += xunit_test_obj.time
            if self.outcome != XU_FAIL:
                self._outcome = XU_PASS
        elif xunit_test_obj.outcome == XU_FAIL:
            self._time += xunit_test_obj.time
            self._outcome = XU_FAIL
            self._fail_count += 1
        elif xunit_test_obj.outcome == XU_SKIP:
            self._skip_count += 1
        elif xunit_test_obj.outcome == XU_ERROR:
            self._error_count += 1
        else:
            raise ValueError("Outcome %s not supported", xunit_test_obj.outcome)
        self._total_count += 1
        self._tc_list.append(xunit_test_obj)
        
    @property
    def weight(self):
        """ Returns the weight (float) of passed versus total test cases as a percent.
        """
        return float(self._pass_count) / float(self._total_count) * 100
    
    @property
    def weight_details(self):
        return "%4d(P) %4d(F) %4d(S) %4d(E)" %(self._pass_count, self._fail_count, self._skip_count, self._error_count)
         

        
    
class XunitTestCase(TestCaseBase):
    
    def __init__(self, xunit_tc, parent_report, specmap_report = None):
        
        super(XunitTestCase, self).__init__(parent_report = parent_report, specmap_report = specmap_report)
        
        self._xunit_tc = xunit_tc
        
        test_regex = re.compile("\s*test\s*", re.IGNORECASE)
        
        self._name = xunit_tc.name
        self._time = xunit_tc.time
        self._classname = xunit_tc.classname
        
        self._system_out = xunit_tc.stdout 
        self._system_err = xunit_tc.stderr 
        self._outcome = XUNIT_TO_SCUTILS[xunit_tc.outcome]
        self._message = test_regex.sub('', xunit_tc.message or '') + xunit_tc.additional_info[:80]
        
        if self._outcome == XU_FAIL or self._outcome == XU_ERROR:
            self._backtrace = xunit_tc.additional_info
        elif self._outcome == XU_SKIP:
            self._skip_location =  xunit_tc.additional_info

class TestLinkReport(GTISCUtilsBase):   
    
    def __init__(self, name, parent_report = None): 
        super(TestLinkReport, self).__init__(name = name)
        
        self._parent_report = parent_report
        
        from weakref import proxy
        if self._parent_report != None:
            self._parent_report = proxy(self._parent_report)
        
        # Testlink specific information
        
        self._server_config = None        
        
        self._sc_project_name = None
        self._sc_project = None
        self._sc_base_suite = None 
        self._sc_base_suite_path = None
        self._sc_test_set_name = None  
        self._sc_test_set= None  
        self._sc_build_name = None
        self._sc_build = None 
        self._sc_platform_name = None
        self._sc_platform = None
        
        self._dry_run = False
        self._keep_structure = True
        self._compound = False
        
        self._sc_suites_by_name = {}
        self._sc_suites_by_id = {}
        
        self._test_set_test_cases_by_id = {} # List of test cases by ID  
        
    @property
    def dry_run(self):
        return self._dry_run

    @dry_run.setter
    def dry_run(self, value):
        self._dry_run = value

    @property
    def keep_structure(self):
        return self._keep_structure

    @keep_structure.setter
    def keep_structure(self, value):
        self._keep_structure = value
        
    @property
    def compound(self):
        return self._compound
    
    @compound.setter
    def compound(self, value):
        self._compound = value
        
    def set_testlink_info(self, server_config, project_name, set_name, build_name, base_path, 
                          build_info = None, build_release_date = None, platform_name = None,  dry_run = False, keep_structure = True, compound = False):
        """ Sets the components required to deal with the testlink server.
        
            :param: server_config server configuration object
            :param: project_name testlink project name
            :param: set_name testlink test set name
            :param: build_name testlink build name
            :param: platform_name testlink platform name (optional)
            :param: base_path base path to upload tests
            :param: dry_run if set to True, the upload will run as a dry run which means that no object 
                    will be created on the server.
            :param: keep_structure If set to True, gti-scutils will maintain the module structure in TL
            :param: compound If set to True, class will be considered compunded test cases.
        """
        
        if self._parent_report != None:
           self._parent_report.set_testlink_info(server_config = server_config, 
                                                 project_name = project_name, 
                                                 set_name = set_name, 
                                                 build_name = build_name, 
                                                 base_path = base_path,
                                                 build_info = build_info, 
                                                 build_release_date = build_release_date, 
                                                 platform_name = platform_name,  
                                                 dry_run = dry_run, 
                                                 keep_structure = keep_structure, 
                                                 compound = compound)
        else:
            self._server_config = server_config
            self._sc_project_name = project_name
            self._sc_test_set_name = set_name
            self._sc_base_suite_path = base_path        
            self._sc_build_name = build_name
            self._sc_platform_name = platform_name
            self._sc_build_info = build_info
            self._sc_build_release_date = build_release_date
            
            self.dry_run = dry_run
            self.keep_structure = keep_structure
            self.compound = compound

    @property
    def sc_suites_by_name(self):
        if self._parent_report != None:
            return self._parent_report.sc_suites_by_name
        return self._sc_suites_by_name   

    @property
    def sc_suites_by_id(self):
        if self._parent_report != None:
            return self._parent_report.sc_suites_by_id
        return self._sc_suites_by_id   
      
    @property
    def test_set_test_cases_by_id(self):
        if self._parent_report != None:
            return self._parent_report.test_set_test_cases_by_id
        return self._test_set_test_cases_by_id     
               
    @property
    def server_config(self):
        if self._parent_report != None:
            return self._parent_report.server_config
        return self._server_config        

    @property
    def sc_project_name(self):
        if self._parent_report != None:
            return self._parent_report.sc_project_name
        return self._sc_project_name  



    @property
    def sc_test_set_name(self):
        if self._parent_report != None:
            return self._parent_report.sc_test_set_name
        return self._sc_test_set_name  

    @property
    def sc_build_name(self):
        if self._parent_report != None:
            return self._parent_report.sc_build_name
        return self._sc_build_name  
        
    @property
    def sc_project(self):
        """ Return the TestLink project object.
        
            First, the calling code must set the server information with set_testlink_info.
            
            :rtype: A PYTL project object.
            
            :raises: ValueError if the project is not found
            :raises: AssertionError if the server info was not provided.
        """
        if self._parent_report != None:
            return self._parent_report.sc_project

        assert self.server_config != None, "You must configure the report via set_testlink_info"
        assert self.sc_project_name != None, "You must set the project name via set_testlink_info"
        if self._sc_project == None:
            self._sc_project = self.server_config.sc_server.get_project(self.sc_project_name)
        if self._sc_project == None:
            raise ValueError("project '{0}' not found on '{1}'".format(self.sc_project_name, self.server_config.server_url))
        return self._sc_project
    
    @property
    def sc_test_set(self):
        """ Returns the Testlink test set object.

            First, the calling code must set the server information with set_testlink_info.
            
            :rtype: A PYTL test set object.
            
            :raises: ValueError if the test set is not found
            :raises: AssertionError if the server info was not provided.
        
        
        """
        if self._parent_report != None:
            return self._parent_report.sc_test_set

        assert self.sc_test_set_name != None, "You must set the test set name via set_testlink_info"
        self.sc_project # Trigger an exception if needs be        
        if self._sc_test_set == None:
            
            if self.server_config.fast_upload == True:
                # Retrieve the test plan
                
                testlink.pytl_enable_exceptions(True)
                
                def find_test_set():                
                    cmd = getProjectTestPlans(project_id = self.sc_project.id)
                    self.info("getting test sets from the server")
                    if self.server_config.sc_server.send_command(cmd) == False:
                        raise ValueError("Failed to get any test set from the server {0} {1}".format(cmd.error_code, cmd.error_msg))
                    
                    self.info("checking available test sets")
                    ts_object = None
                    for tmp in cmd.response:
                        self.info("processing {0}".format(tmp.name))
                        if tmp.name.lower() == self.sc_test_set_name.lower():
                            ts_object = tmp
                            break  
                    return ts_object
               
                self._sc_test_set = find_test_set()
                
                if self._sc_test_set == None:
                    self.action("test set {0} not found, creating".format(self.sc_test_set_name))

                    cmd = createTestPlan(name = self.sc_test_set_name,
                                         project_name = self.sc_project.name,
                                         summary = "automatically created by gti-scutils",
                                         active = True,
                                         public = True)
                    if self.server_config.sc_server.send_command(cmd) == False:
                        raise ValueError("failed to create test set  {0} {1} {2}".format(self.sc_test_set_name, cmd.error_code, cmd.error_msg))
                    ts_id = int(cmd.response)
                    self._sc_test_set = find_test_set()
                    assert ts_id == self._sc_test_set.id, "Internal error - test set ID mistmatch expected {0} actual {1}".format(
                                                                                                    ts_id,
                                                                                                    self._sc_test_set
                                                                                                                                  )
                        
            else:
                self._sc_test_set = self.sc_project.get_test_set(self.sc_test_set_name)
                                
                if self._sc_test_set == None:
                     self._sc_test_set = self.sc_project.create_test_set(name = self.sc_test_set_name, summary = "automatically created by gti-scutils", active=True, public=True)
                
            if self._sc_test_set == None:
                raise ValueError("test set '{0}' not found on '{1}'".format(self.sc_test_set_name, self.server_config.server_url))
        
            
            self.action("Fetching the test cases for test set {0}".format(self._sc_test_set.name))

            if self.server_config.fast_upload == True:
                testlink.pytl_enable_exceptions(True)
                platform_id = None
                if self.sc_platform != None:
                    platform_id = self.sc_platform.id
                cmd = getTestCasesForTestPlan(plan_id = self._sc_test_set.id, 
                                               build_id = self.sc_build.id, 
                                               platform_id = platform_id)
                
                if self.server_config.sc_server.send_command(cmd) == False:
                    raise ValueError("Failed to get any test set from the server {0} {1}".format(cmd.error_code, cmd.error_msg))
                for tc in cmd.response:
                    self.test_set_test_cases_by_id[str(tc.uid)] = tc
                
            else:
                self._sc_test_set.build = self.sc_build
                self._sc_test_set.platform = self.sc_platform
        
        
        
        return self._sc_test_set
    
    def _get_test_set_case(self, sc_ts_test_case_object, assign = True):
        """ Return a test case object pertaining to the test set.
        
            If the test case is not in the set, it is being added
            
            :param: sc_ts_test_case_object a test case object
            :param: assign if set to True, the test case will be automatically assigned
            
            :raises: AssertionError if sc_ts_test_case_object is not a valid test case object.
            :raises: ValueError if the test case could not be found in the set.
        """

        if self._parent_report != None:
            return self._parent_report._get_test_set_case(sc_ts_test_case_object = sc_ts_test_case_object, assign = assign)

        assert isinstance(sc_ts_test_case_object, SCTestCase) == True, "A test case object must be provided {0}".format(sc_ts_test_case_object)
        
        set_tc = None
        
        if self.server_config.fast_upload == True:
            set_tc = self.test_set_test_cases_by_id.get(str(sc_ts_test_case_object.uid), None)
            if set_tc == None:
                if assign == False or self.dry_run == True:
                    self.warning("test case {0} `{1}` not found in set `{2}` and will not be assigned".format(
                                                                            sc_ts_test_case_object.fid, 
                                                                            sc_ts_test_case_object.title, 
                                                                            self.sc_test_set.name))
                else:
                    self.debug_info("assigning test case {0} {1} to test set ".format(sc_ts_test_case_object.fid, sc_ts_test_case_object.title))
                    platform_id = None
                    if self.sc_platform != None:
                        platform_id = self.sc_platform.id
                    cmd = addTestCaseToTestPlan(project_id = self.sc_project.id,
                                                plan_id = self.sc_test_set.id, 
                                                case_id = sc_ts_test_case_object.fid, 
                                                platform_id = platform_id,
                                                version = sc_ts_test_case_object.version)
                if self.server_config.sc_server.send_command(cmd) == False or cmd.response != True:
                    raise ValueError("Failed assign test case {0} `{1}` {2} {3}".format(sc_ts_test_case_object.fid, sc_ts_test_case_object.title, cmd.error_code, cmd.error_msg))

                set_tc = SCTestCase()
                set_tc.copy_properties(sc_ts_test_case_object)
                set_tc.outcome = set_tc.OUTCOME_NOT_EXECUTED
                set_tc.prefix = self.sc_project.prefix
            else:
                set_tc.prefix = self.sc_project.prefix
                
        else:
            # get the test from the set
            set_tc = self.sc_test_set.get_test_case(sc_ts_test_case_object.id)
            if set_tc == None:
                if assign == False or self.dry_run == True:
                    self.warning("test case {0} `{1}` not found in set `{2}` and will not be assigned".format(
                                                                            sc_ts_test_case_object.fid, 
                                                                            sc_ts_test_case_object.title, 
                                                                            self.sc_test_set.name))
                    
                else:
                    self.debug_info("assigning test case {0} {1} to test set ".format(sc_ts_test_case_object.fid, self.name))
                    self.sc_test_set.assign(sc_ts_test_case_object.fid)
                    self.sc_test_set._load_test_cases() # This is a hack
                    set_tc = self.sc_test_set.get_test_case(sc_ts_test_case_object.id)
                    if set_tc == None:
                        raise ValueError("Test case '{0} {1}' could not be assigned to set - aborting".format(
                                                            sc_ts_test_case_object.fid,
                                                            self.name,                                                            
                                                            ))
        
        if set_tc == None:
            raise ValueError("could not locate test set test case {0}".format(sc_ts_test_case_object.title))
        
        return set_tc
    
    @property
    def sc_build(self):
        """ Returns the Testlink build object.

            First, the calling code must set the server information with set_testlink_info.
            
            .. note:: The build is automatically assigned to the test set when PyTL is used.
            
            :rtype: A PYTL test set object.
            
            :raises: ValueError if the build is not found
            :raises: AssertionError if the server info was not provided.
        """

        if self._parent_report != None:
            return self._parent_report.sc_build

        sc_testset = self.sc_test_set
        
        assert self.sc_test_set_name != None, "You must set the test set name via set_testlink_info"
        
        if self._sc_build == None:
            if self.server_config.fast_upload == True:
                cmd = getBuildsForTestPlan(plan_id = sc_testset.id)
                if self.server_config.sc_server.send_command(cmd) == False:
                    raise ValueError("Failed to get builds from server {0} {1}".format(cmd.error_code, cmd.error_msg))
                for tmp in cmd.response:
                    self.info("processing {0}".format(tmp.name))
                    if tmp.name.lower() == self.sc_build_name.lower():
                        self._sc_build = tmp
                        break                
            else:
                self._sc_build = sc_testset.get_build(self.sc_build_name) 
        
            if self._sc_build == None:
                if self.dry_run:
                    self.warning("build '{0}' not found in set '{1}' - not created in dry run".format(self.sc_build_name, self.sc_test_set_name))
                else:                
                    self.info("creating build '%s' in test set '%s'" , self.sc_build_name, self.sc_test_set_name)
                    if self.server_config.fast_upload == True:
                        # implementation of GTIRA-16 [gti-scutils] should support storing the build's release date
                        # If we get a TypeError, the underlying pytl doesn't support it
                        try:
                            cmd = createBuild(plan_id = sc_testset.id, 
                                              name = self.sc_build_name, 
                                              summary = self._sc_build_info or "automatically created.",
                                              release_date = self._sc_build_release_date)
                        except TypeError:
                            
                            self.warning("build release date is not supported by this pytl version")
                            cmd = createBuild(plan_id = sc_testset.id, name = self.sc_build_name, summary = self._sc_build_info or "automatically created.")
                            
                        if self.server_config.sc_server.send_command(cmd) == False:
                            raise ValueError("Failed to create build in test plan {0} {1}".format(cmd.error_code, cmd.error_msg))
                        self._sc_build = SCBuild()
                        self._sc_build.id = cmd.response
                        self._sc_build.name = self.sc_build_name
                        self.info("created build {0} with id {1}".format(self._sc_build.name, self._sc_build.id))                   
                    else:
                        self._sc_build = sc_testset.create_build(name = self.sc_build_name, summary = "automatically created.")
        
            if self._sc_build == None and self.dry_run == False:
                raise ValueError("failed to create build '{0}'".format(self.sc_build_name))
        
            if self.server_config.fast_upload == False:
                self.info("Assigning build {0} to test set {1}".format(self._sc_build.name, self.sc_test_set.name))
                self.sc_test_set.build = self._sc_build
        
        return self._sc_build
    
    @property
    def sc_platform(self):
        """ Returns the Testlink platform object.

            First, the calling code must set the server information with set_testlink_info.
            
            .. note:: The platform is automatically assigned to the test set when PyTL is used.
            
            :rtype: A PYTL platform object.
            
            :raises: ValueError if the platform is not found
            :raises: AssertionError if the server info was not provided.
        """
        if self._parent_report != None:
            return self._parent_report.sc_platform
        
        sc_build = self.sc_build
        
        if self._sc_platform_name == None:
            return None
        
        if self._sc_platform == None:
            
            self.debug_info("getting plaform {0} for test set {1}".format(self._sc_platform_name, self.sc_test_set.id))
            if self.server_config.fast_upload == False:
                self._sc_platform = sc_testset.get_platform(self._sc_platform_name)
                if self._sc_platform == None:
                    raise ValueError("platform '{0}' not found in set '{1}'".format(self._sc_platform_name, self.sc_test_set_name))
                self.info("Assigning platform {0} to test set {1}".format(self._sc_platform.name, self.sc_test_set.name))
                self.sc_test_set.platform = self._sc_platform
            else:
                cmd = getTestPlanPlatforms(plan_id = self.sc_test_set.id)                
                if self.server_config.sc_server.send_command(cmd) == False:
                    raise ValueError("Failed to get platform {0} for test set {1} - {2} {3}".format(self._sc_platform_name, self.sc_test_set.id, 
                                                                                       cmd.error_code, cmd.error_msg))
                for p in cmd.response:
                    self.info("processing platfom {0}".format(p.name))
                    if p.name.lower() == self._sc_platform_name.lower():
                        self._sc_platform = p
                        break
            if self._sc_platform == None:
                raise ValueError("plaform '{0}' not found".format(self._sc_platform_name, self.sc_test_set.id))
        return self._sc_platform
    
    @property
    def sc_base_suite(self):
        if self._parent_report != None:
            return self._parent_report.sc_base_suite
        
        sc_project = self.sc_project
        
        assert self._sc_base_suite_path != None, "You must set the base suite path via set_testlink_info"
        
        if self._sc_base_suite == None:
            self.info("getting base path {0}".format(self._sc_base_suite_path))
            
            base_suite_path = []
            for a in self._sc_base_suite_path.split("/"):
                if a.strip() == "":
                    continue
                base_suite_path.append(a)
            
            if self.server_config.fast_upload == True:
                self._sc_base_suite = self._get_ts_leaf_suite(suite_paths = base_suite_path)
            else:
                self._sc_base_suite = sc_project.test_specification.get_test_suite(self._sc_base_suite_path)
                if self._sc_base_suite == None:
                    if self.dry_run == True:
                        self.warning("Skipping base suite create in dry mode")
                    else:
                        self.info("Creating base suite '{0}'".format(self._sc_base_suite_path))                    
                        self._sc_base_suite = sc_project.test_specification.create_test_suite(title = self._sc_base_suite_path.split("/")[-1],
                                                                                         summary = "automatically created",
                                                                                         path = self._sc_base_suite_path)
        
                    
        if self._sc_base_suite == None and self.dry_run == False:
            raise ValueError("Failed to locate base suite '{0}'".format(self._sc_base_suite_path))
        
        if self._sc_base_suite != None:
            assert isinstance(self._sc_base_suite, TLSuite) == True, "Invalid suite object {0}".format(self._sc_base_suite) 
            
        return self._sc_base_suite
    
    def _get_ts_leaf_suite(self, suite_paths, parent_obj = None):
        """ This method will locate the specified test suite.
        
            It returns the suite object or None in dry mode if the test suite doesn't exit on the server.
        """
        
        if len(suite_paths) == 0 or suite_paths == None:
            return parent_obj
        
        search_suite_obj = None
        
        self.debug_info("Searching child suites {0}".format("/".join(suite_paths)))
        
        if self.server_config.fast_upload == True:
        
            current_suite_node = None
            
            # Search the cached information
            if parent_obj == None:
                current_suite_node = self.sc_suites_by_name
            else:
                current_suite_node = self.sc_suites_by_id.get(str(parent_obj.id), None)
                
            if current_suite_node != None: # We may have the object cached
                search_suite_obj = current_suite_node.get(suite_paths[0].lower(), None)
                if search_suite_obj != None:
                    search_suite_obj = search_suite_obj.get('__tl_object', None)
                
            if search_suite_obj == None:
            
                if parent_obj == None: # This is a top level suite                
                    current_suite_node = self.sc_suites_by_name
                                               
                    cmd = getFirstLevelTestSuitesForTestProject(project_id = self.sc_project.id)
                    self.debug_info("getting top level suites from server")
                    if self.server_config.sc_server.send_command(cmd) == False:
                        raise ValueError("Failed to get top level test suites from server {0} {1}".format(cmd.error_code, cmd.error_msg))
                else:                
                    current_suite_node = self.sc_suites_by_id.get(str(parent_obj.id), None)
                    cmd = getTestSuitesForTestSuite(parent_suite_id = parent_obj.id)
                    self.debug_info("getting suites '{0}' - '{1}' from server".format(parent_obj.title, parent_obj.id))
                    if self.server_config.sc_server.send_command(cmd) == False:
                        raise ValueError("Failed to get test suites from suite '{0}' - {1} {2}".format(parent_obj.title, cmd.error_code, cmd.error_msg))
                    
                for suite_obj in cmd.response:
                    self.info("processing suite '{0}'".format(suite_obj.title))
        
                    if current_suite_node != None:
                        current_suite_node.setdefault(suite_obj.title.lower(), {'__tl_object' : suite_obj})                    
                        self.sc_suites_by_id.setdefault(str(suite_obj.id),  current_suite_node[suite_obj.title.lower()])
                        
                    if suite_obj.title.lower() == suite_paths[0].lower():
                        search_suite_obj = suite_obj
                        break
            else:
                self.debug_info("found cached suite info '{0}".format(search_suite_obj.title))
                
            if search_suite_obj == None:
                
                if self.dry_run == True:
                    raise ValueError("suite {0} won't be created in dry run mode".format("/".join(suite_paths)))
                
                # If we couldn't find the suite, we create it and then obviously all sub suites are new.
                parent_id = None  
                parent_title = "top level"  
                if parent_obj != None: # This is a top level suite
                    parent_id = parent_obj.id
                    parent_title = parent_obj.title
        
                cmd = createTestSuite(project_id = self.sc_project.id, 
                                      parent_id = parent_id, 
                                      title = suite_paths[0], 
                                      summary = "automatically created by gti-scutils")
                
                self.info("creating child suite '{0}'".format(suite_paths[0]))
                
                if self.server_config.sc_server.send_command(cmd) == False:
                    raise ValueError("Failed create suite '{0}' - {1} {2}".format(suite_paths[0], cmd.error_code, cmd.error_msg))
        
                # We need to get the suite by ID
                cmd = getTestSuiteByID(suite_id = cmd.response)            
                if self.server_config.sc_server.send_command(cmd) == False:
                    raise ValueError ("Failed to get test suites from suite '{0}' - {1} {2}".format(parent_title, cmd.error_code, cmd.error_msg))
        
                
                search_suite_obj = cmd.response
                
                # Adding to cache
                current_suite_node.setdefault(search_suite_obj.title.lower(), {'__tl_object' : search_suite_obj})
                self.sc_suites_by_id.setdefault(str(search_suite_obj.id),  current_suite_node[search_suite_obj.title.lower()])
    
        else:
            search_suite_obj = self.sc_project.test_specification.get_test_suite(suite_paths[0])
            if search_suite_obj == None:

                if self.dry_run == True:
                    raise ValueError("suite {0} won't be created in dry run mode".format("/".join(suite_paths)))
                
                self.info("creating child suite '{0}'".format(suite_paths[0]))
                if parent_obj == None:
                    search_suite_obj = sc_project.test_specification.create_test_suite(title = suite_paths[0],
                                                                                       summary = "automatically created")
                else:
                    search_suite_obj = parent_obj.create_test_suite(title = suite_paths[0],
                                                                    summary = "automatically created")
                if search_suite_obj == None:
                    raise ValueError("Failed to create base suite '%s'" % suite_paths)
                
        suite_paths.pop(0)
        if len(suite_paths) == 0:
            return search_suite_obj
                
 
        return self._get_ts_leaf_suite(parent_obj = search_suite_obj, suite_paths = suite_paths)                      
        
class CombinedXunitReport(TestLinkReport):
    """
    """
    def __init__(self, file_list, ignore_base = None): 
        super(CombinedXunitReport, self).__init__(name = "CombinedXunitReport")
        self._reports = []       
        for file_path in file_list:
            self._reports.append(XunitReport(file_path = file_path, ignore_base = ignore_base, parent_report = self))
            


    @property
    def report_path(self):
        return [r.report_path for r in self._reports]
    
    @property
    def errors(self):
        """ Number of errors"""
        return sum([r.errors for r in self._reports])
        
    @property
    def failures(self):
        """ Number of failed tests"""
        return sum([r.failures for r in self._reports])
        
    @property
    def skips(self):
        """ Number of skipped tests"""
        return sum([r.skips for r in self._reports])

    @property
    def ok(self):
        """ number of passed test cases""" 
        return sum([r.ok for r in self._reports])     

    @property
    def tests(self):
        """ Number of executed test cases = all_test - skips - errors"""
        return sum([r.tests for r in self._reports])  


    @property
    def all_tests(self):
        """ Number of all test cases"""
        return sum([r.all_tests for r in self._reports]) 
    
    @property
    def _warnings(self):
        warning_list = []
        for r in self._reports:
            warning_list.extend(r._warnings)
        return warning_list         
        
    
    def get_test_cases(self, filter = [], compound = False):
        """ Returns the list of test case based on the outcome.
        
        
            :param filter: a list of outcome. Valid values are 
                           XU_PASS, XU_FAIL, XU_SKIP, XU_ERROR
                           
            :param compound: Boolean - If set to True, returns a list of compounded test cases.
                           
            :rtype: A list of test cases matching the outcome.
            
        """
        tc_list = []
        for r in self._reports:
            tc_list.extend(r.get_test_cases(filter = filter, compound = compound))
        return tc_list 

    @property
    def time(self):
        """ execution time in seconds"""
        return sum([r.time for r in self._reports])
    
    def __next__(self):
        for test_case_obj in self.test_cases:
            yield test_case_obj
            
    def __iter__(self):
        return self.__next__()
    
    def __str__(self):
        header = "%-10s%-10s  %-10s %-10s %-10s %-10s %s\n" % \
                 ("Executed", "Passed", "Failed", "Skipped", "Errors", "Total", "Exec Time")
        data   = "\n%-10d%-10d  %-10d %-10d %-10d %-10d %s\n" % \
                 (self.tests, self.ok, self.failures, self.skips, self.errors, self.all_tests, convert_second_to_hms(self.time))
        adds   = ""
        if len(self._warnings) > 0:
           adds += "Warnings\n" + "\n".join(self._warnings) 
        return header + "-"*len(data) + data + adds       

    def set_testlink_info(self, server_config, project_name, set_name, build_name, base_path, 
                          build_info = None, build_release_date = None, platform_name = None,  dry_run = False, keep_structure = True, compound = False):
        """ Sets the components required to deal with the testlink server.
        
            :param: server_config server configuration object
            :param: project_name testlink project name
            :param: set_name testlink test set name
            :param: build_name testlink build name
            :param: platform_name testlink platform name (optional)
            :param: base_path base path to upload tests
            :param: dry_run if set to True, the upload will run as a dry run which means that no object 
                    will be created on the server.
            :param: keep_structure If set to True, gti-scutils will maintain the module structure in TL
            :param: compound If set to True, class will be considered compunded test cases.
        """
        
        super(CombinedXunitReport, self).set_testlink_info(server_config = server_config, 
                                                 project_name = project_name, 
                                                 set_name = set_name, 
                                                 build_name = build_name, 
                                                 base_path = base_path,
                                                 build_info = build_info, 
                                                 build_release_date = build_release_date, 
                                                 platform_name = platform_name,  
                                                 dry_run = dry_run, 
                                                 keep_structure = keep_structure, 
                                                 compound = compound)

        for sub_rep in self._reports:
            sub_rep.dry_run = dry_run
            sub_rep.keep_structure = keep_structure
            sub_rep.compound = compound
    

class XunitReport(TestLinkReport):
    """ This class handles Xunit reports and provides methods to retrieve 
        information.
        
        :param file_path: path to the xunit report. The path can be on the 
                          file system or a URL. 
                          The file can be compressed or uncompressed. 
                          
        :param ignore_base: If set, ignores the portion of classname matching the string provided
        
        :param parent_report: reserved. If the report is a sub report of CombinedXunitReport, the ref to that report should be passed.
                          
    """
    def __init__(self, file_path, ignore_base = None, parent_report = None):
        
        super(XunitReport, self).__init__(name = os.path.basename(file_path), parent_report = parent_report)
        
        self.info("Loading xml report %s", file_path)
    
        self._report_path = file_path
        
        self._xunit_report = None
        self._specmap_report = None
        
        self._tmp_file = [] # list of temp files that need to be deleted after the object is deleted
        self._ignore_base = ignore_base
        self._warnings = []
        
        if self._ignore_base != None:
            if type(self._ignore_base) != types.StringType:
                raise TypeError("ignore_base must be a string type")
            if self._ignore_base.startswith("./"):
                self._ignore_base = self._ignore_base[2:]
            self._ignore_base = self._ignore_base.replace("/", ".")
            self.info("ignoring classname base starting with `{0}`".format(self._ignore_base))
                
        specmap_file_path = None 
        xunit_file_path = None       
        url_download = None
        
        if re.match("http\:\/\/", file_path, re.IGNORECASE):
            url_download = wget(file_path, tmp_dir=True)
            file_path = url_download
                    
        if zipfile.is_zipfile(file_path):
            self.action("Zipfile Extracting %s", file_path)
            zip = zipfile.ZipFile(file_path)
            self.debug_info("content {0}".format(zip.namelist()))
            
            if len(zip.namelist()) == 0:
                raise IOError("%s constains no file" % (file_path))
            elif len(zip.namelist()) >= 1 and len(zip.namelist()) <= 3:
                tmp_dir = tempfile.mkdtemp()
                self.debug_info("extracting files to tmp dir %s", tmp_dir)
                for f in zip.namelist():
                    if re.match("^(s|S)(p|P)(e|E)(c|C)(m|M)(a|A)(p|P)$", f.split(".")[-1]):
                        zip.extract(f, tmp_dir)
                        specmap_file_path = os.path.join(tmp_dir, f)
                        self._tmp_file.append(specmap_file_path)
                    if re.match("(x|X)(m|M)(l|L)", f.split(".")[-1]):   
                        zip.extract(f, tmp_dir)
                        xunit_file_path = os.path.join(tmp_dir, f)
                        self._tmp_file.append(xunit_file_path)
            else:
                raise IOError("%s has to many files %s" % (file_path, str(zip.namelist())))
        else:
            xunit_file_path = file_path
            fcomp = xunit_file_path.split(".")
            if re.match("(x|X)(m|M)(l|L)", fcomp[-1]):
                fcomp[-1] = "specmap"
            else:
                fcomp.append("specmap")
            tmp = os.path.join(os.path.dirname(file_path), ".".join(fcomp))
            if os.path.exists(tmp) == True:
                specmap_file_path = tmp
        
        try:
            os.remove(url_download)
            self.info("Deleted temp file %s", (url_download))
        except: pass
        
        try:
            self.action("Loading xunit file %s", xunit_file_path)
            self._xunit_report = XUNITReportFile(xunit_file = xunit_file_path)
            self._xunit_report.load()
        except ValueError as ve:
            self._warnings.append(str(ve))
        
        if specmap_file_path != None:
            self.action("Loading specmap file %s", specmap_file_path)
            self._specmap_report = SpecmapReportFile(specmap_file = specmap_file_path) 
            self._specmap_report.load()
        

        self.test_cases = []
        self._test_case_by_outcome = { XU_PASS : [],
                                       XU_FAIL : [],
                                       XU_SKIP : [],
                                       XU_ERROR : [],
                                     }
        
        for xunit_tc in self._xunit_report.suite.test_cases:
            #tc = XunitTestCase(parent_report = self, element = tc_elem, specmap_report = self._specmap_report)
            tc = XunitTestCase(parent_report = self, xunit_tc = xunit_tc, specmap_report = self._specmap_report) 
            self.test_cases.append(tc)
            self._test_case_by_outcome[tc.outcome].append(tc)
            

    def __del__(self):        
        if self._tmp_file:
            self.debug_info("deleting temp file %s" % self._tmp_file)
            try:
                for f in self._tmp_file:
                    os.remove(f)
            except:
                pass

    @property
    def xunit_report(self):
        return self._xunit_report
    
    @property
    def specmap_report(self):
        return self._specmap_report    

    @property
    def report_path(self):
        return self._report_path
    
    @property
    def errors(self):
        """ Number of errors"""
        return self._xunit_report.suite.errors
        
    @property
    def failures(self):
        """ Number of failed tests"""
        return self._xunit_report.suite.failures
        
    @property
    def skips(self):
        """ Number of skipped tests"""
        return self._xunit_report.suite.skips

    @property
    def ok(self):
        """ number of passed test cases"""        
        return self._xunit_report.suite.passed

    @property
    def tests(self):
        """ Number of executed test cases = all_test - skips - errors"""
        return self._xunit_report.suite.tests

    @property
    def all_tests(self):
        """ Number of all test cases"""
        return self._xunit_report.suite.collected
    
    @property
    def time(self):
        """ execution time in seconds"""
        return self._xunit_report.suite.time
    @property
    def name(self):
        """ suite name"""
        return self._xunit_report.suite.name
    
    def get_test_cases(self, filter = [], compound = False):
        """ Returns the list of test case based on the outcome.
        
        
            :param filter: a list of outcome. Valid values are 
                           XU_PASS, XU_FAIL, XU_SKIP, XU_ERROR
                           
            :param compound: Boolean - If set to True, returns a list of compounded test cases.
                           
            :rtype: A list of test cases matching the outcome.
            
        """
        list = []
        
        
        if len(filter) == 0:
            list.extend(self.test_cases)
        else:            
            for o in filter:
                if o not in XU_VALID_OUTOME:
                    raise ValueError("Invalid outcome %s" % str(o))
                list.extend(self._test_case_by_outcome[o])
                
        if compound == True:
            by_name = {}
            for tc_obj in list:
                if by_name.get(tc_obj.test_proc_name) == None:
                    by_name[tc_obj.test_proc_name] = CompoundedTestCase(parent_report = self, specmap_report = self._specmap_report)
                by_name[tc_obj.test_proc_name].add_xunit(tc_obj)
            list = by_name.values()
        return list
    
    def __next__(self):
        for test_case_obj in self.test_cases:
            yield test_case_obj
            
    def __iter__(self):
        return self.__next__()
    
    def __str__(self):
        header = "%-10s%-10s  %-10s %-10s %-10s %-10s %s\n" % \
                 ("Executed", "Passed", "Failed", "Skipped", "Errors", "Total", "Exec Time")
        data   = "\n%-10d%-10d  %-10d %-10d %-10d %-10d %s\n" % \
                 (self.tests, self.ok, self.failures, self.skips, self.errors, self.all_tests, convert_second_to_hms(self.time))
        adds   = ""
        if len(self._warnings) > 0:
           adds += "Warnings\n" + "\n".join(self._warnings) 
        return header + "-"*len(data) + data + adds
        

        

class ServerConfig(GTISCUtilsBase):
    """ This class provides access to the server configuration information 
        stored on the local file system.
        
        This informationis stored in the user's home directory under .gti/gti_scutils.
        
        * The current session is stored in the ``current_config.cfg``
        * For each configuration type, there is a config file which is broken 
          by user::
          
            [lpbrac]
            server_url = http://aus-testlink.dolby.net/
            dev_key = aaaaaaaaaaaaaaaaaaaaaaaaaaa
            user = lpbrac   
            
        :param fast_upload: **Experimental**. If enabled, results will be uploaded directly using 
                            low level testlink commands (bypassing PyTL).
    """
    
    def __init__(self, fast_upload = False):
        
        super(ServerConfig, self).__init__(name = "ServerConfig")
        
        self.config_home_dir = os.path.join(get_user_home_dir(), ".gti", "gti_scutils")
        self.info("user configuration dir `{0}`".format(self.config_home_dir))
        if os.path.exists(self.config_home_dir) == False:
            self.action("user dir `{0}` not found - creating".format(self.config_home_dir))
            os.makedirs(self.config_home_dir)
            self.success("OK!")
        if fast_upload == True:
            self.warning("Running fast mode. If upload fails, use --no-fast-upload")
            
        self._fast_mode = fast_upload
        self._sc_server = None
        self._user = None
        self._dev_key = None
        self._server_url = None
        self._current_config = None
        
        
        self._current_config_file = os.path.join(self.config_home_dir, "current_config.cfg")
        self.info("user configuration %s", self._current_config_file)
        
    @property
    def fast_upload(self):
        return self._fast_mode
        
    @property
    def sc_server(self):
        """ Returns a reference to a soundcheck server object:
        
            :rtype: None if no config is set
            :type: A server instance (for now Pytl).
            
            :raise: Exception if a connection failure occured
        """
        if self._sc_server != None or self.current_config == None:
            return self._sc_server

        self.action("Connecting to '%s' as '%s'", self._server_url, self._user)
        self._sc_server = testlink.TLServer(  
                                    server_url   = self._server_url, 
                                    dev_key      = self._dev_key, 
                                    user_id      = self._user)

        self.success("Connected to %s (%s) as %s" % (self.current_config, self._server_url, self._user))
        
        return self._sc_server

 
    @property
    def user(self):
        return self._user

    @property
    def dev_key(self):
        return self._dev_key


    @property
    def server_url(self):
        return self._server_url
    
 
    @property
    def current_config(self):
        if self._current_config != None or os.path.exists(self._current_config_file) == False:
            return self._current_config
        
        cfg_parser = ConfigParser()
        cfg_parser.read(self._current_config_file)
        self._current_config = cfg_parser.get("config", "current")
        self._user = cfg_parser.get("config", "user")
        self.load_config(self._current_config, self._user)
        return self._current_config
    
    @current_config.setter
    def current_config(self, value):
        if value == None:
            self._current_config = None
            if os.path.exists(self._current_config_file):
                os.remove(self._current_config_file)
        else:
            cfg_parser = ConfigParser()
            cfg_parser.add_section("config")
            cfg_parser.set("config", "current", value)
            cfg_parser.set("config", "user", self._user)
            with open(self._current_config_file, 'wb') as configfile:
                cfg_parser.write(configfile)        
        self._current_config = value
        
        
        
        
    def save_config(self, config_name, server_url, user, dev_key):
        cfg_file = os.path.join(self.config_home_dir, config_name + ".cfg")
        cfg_parser = ConfigParser()
        if os.path.exists(cfg_file) == True:
            cfg_parser.read(cfg_file)
        if cfg_parser.has_section(user) == True:
            cfg_parser.remove_section(user)
        cfg_parser.add_section(user)
        cfg_parser.set(user, "server_url", server_url)
        cfg_parser.set(user, "dev_key", dev_key)
        cfg_parser.set(user, "user", user)
        self._user = user
        self._server_url = server_url
        self._dev_key = dev_key
        with open(cfg_file, 'wb') as configfile:
            cfg_parser.write(configfile)
        self.current_config = config_name
        
    def load_config(self, config_name, user):
        cfg_file = os.path.join(self.config_home_dir, config_name + ".cfg")
        if os.path.exists(cfg_file) == False:
            raise IOError("No login information available")
        cfg_parser = ConfigParser()
        if os.path.exists(cfg_file):
            cfg_parser.read(cfg_file)
        if cfg_parser.has_section(user) == False:
            raise AttributeError("User never logged in to %s" % config_name)
        
        self._sc_server = None
        self._user = cfg_parser.get(user, "user")
        self._dev_key = cfg_parser.get(user, "dev_key")
        self._server_url = cfg_parser.get(user, "server_url")       
        
    def delete_config(self, config_name):
        cfg_file = os.path.join(self.config_home_dir, config_name + ".cfg")
        if os.path.exists(cfg_file) == False:
            return
        cfg_parser = ConfigParser()  
        cfg_parser.read(cfg_file)      
        if cfg_parser.has_section(self._user) == True:
            cfg_parser.remove_section(self._user)
        if len(cfg_parser.sections()) == 0:
            os.remove(cfg_file)
        else:
            with open(cfg_file, 'wb') as configfile:
                cfg_parser.write(configfile)
            
        self._sc_server = None
        self._user = None
        self._dev_key = None
        self._server_url = None

        