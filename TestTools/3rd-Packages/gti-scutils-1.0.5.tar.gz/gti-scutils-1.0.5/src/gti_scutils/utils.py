"""     
    gti-scutils utilities
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""

import re
import os
import sys
import urllib
import types
import stat
import math
import tempfile
from urlparse import urlparse
from posixpath import basename
import traceback

from logging import getLogger
assert __name__ == "gti_scutils.utils"

LDD = None
CYGPATH = None

PYTHON_OS_BUILD = sys.platform

TERMINAL = os.getenv('TERM')

if PYTHON_OS_BUILD == 'win32' and TERMINAL == None:
    TERMINAL = "command"
    
_GLOBAL_DEBUG = False
_GLOBAL_VERBOSE = False

def scutils_debug_enable(v = None):
    global _GLOBAL_DEBUG
    if v == None:
        return _GLOBAL_DEBUG    
    _GLOBAL_DEBUG = v

def scutils_verbose_enable(v = None):
    global _GLOBAL_VERBOSE
    if v == None:
        return _GLOBAL_VERBOSE    
    
    _GLOBAL_VERBOSE = v
    
   
    
    
def _format_string(*msgs):
    msg = ""
    if len(msgs) == 0:
        return msg
    elif len(msgs) == 1:
       msg = msgs[0]
    else: 
        try:
            msg = msgs[0] % msgs[1:]
        except:
            msg = " ".join(map(str, msgs))
            
    return msg
    
    
    
class GTISCUtilsBase(object):
    
    
    def __init__(self, name, debug = False, verbose = False):
        
        self._tw = None 
        self._debug = debug
        self._verbose = verbose
        self._object_name = name
        try:
            import py
            self._tw = py.io.TerminalWriter(file=None)
        except ImportError:
            pass


    @property
    def debug(self):
        return self._debug
    @debug.setter
    def debug(self, value):
        self._debug = value

    @property
    def verbose(self):
        return self._verbose
    @verbose.setter
    def verbose(self, value):
        self._verbose = value


    def line(self, *msgs, **kwargs):
        if self._tw == None:
            sys.stdout.write(_format_string(*msgs) + "\n")
        else:
            self._tw.line(_format_string(*msgs), **kwargs)

    def raw(self, *msgs, **kwargs):
        if self._tw == None:
            sys.stdout.write(_format_string(*msgs) + "\n")
        else:
            self._tw.line(_format_string(*msgs), **kwargs)


    def bold(self, *msgs, **kwargs):
        kwargs['bold'] = True
        self.line(*msgs, **kwargs)

    # semantic logging
    def debug_info(self, *msgs):        
        if self.debug or _GLOBAL_DEBUG:
            msg = "(debug) [{0}]".format(self._object_name) + msgs[0] % msgs[1:]
            self.line(msg)
            
    def debug_dump_backtrace(self):
        if self.debug or _GLOBAL_DEBUG:
            msg = "[debug backtrace %s]" % (str(self._object_name)) + str(traceback.format_exc())
            self.line(msg, yellow = True)
            

    def action(self, *msgs):
        self.line(*msgs, cyan=True)

    def printout(self, *msgs):
        self.raw(*msgs, bold=True)

    def error(self, *msgs):
        msg = "(error) [{0}] {1}".format(self._object_name, _format_string(*msgs))
        self.line(msg, red=True)

    def warning(self, *msgs):
        msg = "(warning) [{0}] {1}".format(self._object_name, _format_string(*msgs))
        self.line(msg, yellow=True)
            
    def success(self, *msgs):
        self.line(*msgs, green=True)

    def fatal(self, *msgs):
        msg = "(fatal) [{0}] {1}".format(self._object_name, _format_string(*msgs))
        self._tw.line(msg, red=True)
        raise SystemExit(1)

    def info(self, *msgs):
        if self.verbose or _GLOBAL_VERBOSE or self._debug or _GLOBAL_DEBUG:
            msg = "(info) [{0}] {1}".format(self._object_name, _format_string(*msgs))
            self.line(msg, bold=True)
    
    
class ProgressBar(object):
    
    def __init__(self, full_range):
        self._current_value = -1
        self._current_percent = -1
        self._full_range = full_range
        
    @property
    def current(self):
        return self._current_value
    
    @current.setter
    def current(self, value):        
        if value > self._current_value:
            self._current_value = value
            percent = int(round((float(value) / float(self._full_range)) * 100))
            if percent > self._current_percent:
                self._current_percent = percent
                sys.stdout.write("\r[%-99s] %02d%%" % ('#'*percent, percent))
                sys.stdout.flush()
    def completed(self):
        sys.stdout.write("\r[%-99s] %02d%%\n" % ('#'*100, 100))
        sys.stdout.flush()
            
    
def convert_second_to_hms(seconds):
    """ Converts seconds (normally elapsed timed to hours:minute and seconds
    """
    (milliseconds, seconds) = math.modf(float(seconds))
    seconds = int(seconds)
    milliseconds = int(math.modf(milliseconds)[0]*1000)
    hours = seconds / 3600
    seconds -= 3600*hours
    minutes = seconds / 60
    seconds -= 60*minutes
    if milliseconds > 0:
        return "%02d:%02d:%02d.%3d" % (hours, minutes, seconds, milliseconds)
    else:
        return "%02d:%02d:%02d" % (hours, minutes, seconds)
    
    
def get_user_home_dir():
    
    home_dir = None
    
    # ...works on at least windows and linux. 
    # In windows it points to the user's folder 
    #  (the one directly under Documents and Settings, not My Documents)
     
     
    # In windows, you can choose to care about local versus roaming profiles.
    # You can fetch the current user's through PyWin32.
    #
    # For example, to ask for the roaming 'Application Data' directory:
    #  (CSIDL_APPDATA asks for the roaming, CSIDL_LOCAL_APPDATA for the local one)
    #  (See microsoft references for further CSIDL constants)
    try:
        from win32com.shell import shellcon, shell            
        home_dir = shell.SHGetFolderPath(0, shellcon.CSIDL_APPDATA, 0, 0)
     
    except ImportError: # quick semi-nasty fallback for non-windows/win32com case
        home_dir = os.path.expanduser("~")
        
    return home_dir            
    
    
def pexec(*args):
    import subprocess
    return subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].rstrip()

        


def _normalize_path(path, mixed = False):
    if mixed == True and (sys.platform == 'cygwin' or sys.platform == 'win32'):
        path = re.sub('\\\\+', '/', path)
    return path

def _remove_file(pathname, force = False):            
    if os.access(pathname, os.W_OK) == False:
        if force == False:
            raise os.error(pathname + "': is read only")
        else:
            # Change the permission to write
            os.chmod(pathname, stat.S_IMODE(os.stat(pathname).st_mode) | stat.S_IWRITE)
    os.remove(pathname)


def wget(url, retries = 1, logger = None, tmp_dir = False):
    """ Python portable and simplified implementation of wget.
        
        :param url: URL of the file to retrieve.
        :param retries: Number of retries in case of failure (default is 1)
        :param logger: The caller logger object (optional)
    """
    
    if logger == None:
       logger = getLogger(__name__ + ".wget" )
    
    down_dir = os.path.curdir
       
    if tmp_dir == True:
        down_dir = tempfile.mkdtemp()

    parse_obj = urlparse(url)
    filename = os.path.join(down_dir, basename(parse_obj.path))
             
    if filename == None or filename == '':
        sz = "Could not identify basename from %s \n" % ( str(url))
        logger.error(sz)
        raise IOError(sz)

    def reporthook(a,b,c): 
        import time
        # ',' at the end of the line is important!
        print "% 3.1f%% of %d bytes\r" % (min(100, float(a * b) / c * 100), c),
        #you can also use sys.stdout.write
        #sys.stdout.write("\r% 3.1f%% of %d bytes" 
        #                 % (min(100, float(a * b) / c * 100), c)
        sys.stdout.flush()
        
    logger.info("Downloading %s from %s", str(filename) , str(url))
    try:
        urllib.urlretrieve(url, filename = filename, reporthook = reporthook)
    except IOError as ioe:
        logger.error(str(ioe))
        raise
    return filename
    
    
def find(base_dir = ".", name = None, delete = False, command = None, object_type = "df", cygwin_mix = False, silent = True, logger = None):
    """
        Python portable and simplified implementation of find.
        
        :param base_dir: (optional) base directory to search default .
        :param name: (optional) regular expression for file pattern matching. 
        :param delete: (optional)If set to True, delete the files it finds (default False) 
        :param command: (optional) 
        :param object_type: (optional) Search for entries matching type - currently only f (default) 
                            and d are supported. 
        :param cygwin_mix: (optional)  Windows only. If set, the path will be normalized into the cygwin mixed 
                                       mode (replace \ by /). For intance `C:\windows\system32` will be returned 
                                       as `C:/windows/system32`
        :param silent: (optional) If set to True, print the files it finds (default False)
        
        :rtype: List of file and directories it foudn
        
    """
    
    if logger == None:
       logger = getLogger(__name__ + ".find" )
    
    
    list = []
    regex = None
    
    if name != None:
        regex = re.sub('\.', '\.', name)
        regex = re.sub("\*", ".*", regex)
    
    def process_files(options, dirname, fname):
        def run_command(fsobject):
            if type(command) == types.StringType:
                _command = command.replace('{}', fsobject)
                #_command = re.sub('{}', fsobject, command)
                os.system(_command)
            
        if re.search('d', object_type):
            _skip = False
            if regex != None:
                if re.match(regex + "$", dirname) == None:
                    _skip = True
            if not _skip:
                dirname = _normalize_path(dirname, cygwin_mix)
                if silent == False:
                    print dirname
                run_command(dirname)
                list.append(dirname)
                
        if re.search('f', object_type):            
            for name in fname:
                filepath = os.path.join(dirname, name)
                if os.path.isfile(filepath) == False:
                    continue
                if regex != None:
                    if re.search(regex + "$", name) == None:
                        continue
                filepath = _normalize_path(filepath, cygwin_mix)
                if silent == False:
                    print filepath
                list.append(filepath)
                run_command(filepath)
                if delete == True:
                    try:
                        sys.stdout.write("\rdeleting %s" % filepath)
                        sys.stdout.flush()
                        _remove_file(filepath, True)
                    except Exception as rme:
                        logger.warning("failed to delete %s : %s\n" % (str(filepath), str(rme))) 
    
    os.path.walk(base_dir, process_files, None)
    return list   
    
    
def which(what, path = [], extension_var = None,silent = True,  all = False, cygwin_mix = False, logger = None):
    """ Python implementation (portable) of the which command.

        which returns the pathnames of the files (or links) which would be executed 
        in the current environment, had its arguments been given as commands in a 
        strictly POSIX-conformant shell.  It does this by searching the PATH for
        executable files matching the names of the arguments. It does not follow 
        symbolic links.
        
        By default, only the first occurrence is printed unless the -a option is 
        specified.
        
        On cygwin, extensions are removed if the path doesn't start with /cygdrive/

        :param what: what we are looking for. 
        :param silent: do not echo any information. 
        :param path: environment variable to use for path or explicit path (must be a list)
                    PATH or [dir, dir]
        :param extension_var: The extension environment variable or a list of possible extension. 
        :param all: returns all the occurences found.
        :param cygwin_mix: Windows only. If set, the path will be normalized into 
                                  the cygwin mixed mode (replace ``\`` by ``/``). For intance 
                                  ``C:\windows\system32\ipconfig`` will be returned 
                                  as `C:/windows/system32/ipconfig` 
                                  
        :rtype: a list of matches
        
        :raise: GTINotFound If "what" is not found
    """
    
    if logger == None:
       logger = getLogger(__name__ + ".which" )
    
    
        
    match = []
    found = False
    star_nix = False
    path_delimiter   = ";"
    path_source = "PATH"        # Where to get the path
    path_ext_source = "PATHEXT"  # Where to get the extension list
    dotfirst = 1            # Should we look in the current directory also?
    all = False
    
    assert type(path) == types.ListType, "path must be a list"
    
    if sys.platform != 'win32':
        star_nix = True
        path_delimiter = ":"
        
    if len(path) > 0:
        path_source += path_delimiter + path_delimiter.join(path)
        dotfirst = 0

    if extension_var != None:
        path_ext_source = extension_var
    
    if path_delimiter in path_source:
        path = path_source
    else:
        path = os.environ[path_source]
        
    path = filter(None, path.split(path_delimiter))
    
    if dotfirst:
        path = ["."]+path
        
    if path_delimiter in path_ext_source:
        path_ext = path_ext_source
    else:
        path_ext = os.environ.get(path_ext_source, '')    
    
    if sys.platform == 'cygwin':
        path_ext = filter(None, path_ext.split(';'))
    else:
        path_ext = filter(None, path_ext.split(path_delimiter))
    
    
    # Is the command name really a file name?
    if '.' in what:
        # Fake it by making path_ext a list of one empty string.
        path_ext.append('')
    if len(path_ext) == 0:
        path_ext = ['']
    
    # Loop over the directories on the path, looking for the file.
    
    for d in path:
        if all == False and len(match) == 1:
            break
        for e in path_ext:
            filePath = os.path.join(d, what + e)
            #print "COMMAND", what, filePath
            #print filePath
            if os.path.exists(filePath):
                found = True
                filePath = _normalize_path(filePath, mixed = cygwin_mix)
                match.append(filePath)
                if not silent:
                    print filePath
            if all == False and len(match) == 1:
                break
                
    if found == False:
        from gti_scutils import GTINotFound
        buff = "%s not found in %s" %(str(what), path_delimiter.join(path))
        if silent == False:
            logger.error(buff)
        raise GTINotFound(buff)
    return match

# We must make the following silent otherwise it will mess up 
#the pywhich command.
if TERMINAL == 'cygwin':
    try:
        LDD = which(['-s', 'ldd'])[0]
        CYGPATH = which(['-s', 'cygpath'])[0]
    except Exception as syse:
        sys.stderr.write("Error when locating cygwin apps %s\n" %( str(syse)))
    LDD = LDD or 'ldd'
    CYGPATH = CYGPATH or 'cygpath'
    
