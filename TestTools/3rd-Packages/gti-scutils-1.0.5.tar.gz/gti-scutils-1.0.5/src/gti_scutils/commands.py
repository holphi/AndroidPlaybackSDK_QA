"""     
    Main entry point of the gti_scutils command.
    

    :author: Laurent Brack
    :contact: lpbrac@dolby.com
    :copyright: Copyright 2013,2014 Dolby Laboratories inc.
    :license: Dolby

"""

import sys
import platform
import os
import argparse
import time
import datetime
import py
from textwrap import dedent
from logging import getLogger, basicConfig

import dolby.gti.testlink as testlink


from gti_scutils import __version__, __p4datetime__, __p4change__, __p4file__
from gti_scutils.utils import GTISCUtilsBase, scutils_debug_enable, scutils_verbose_enable
from gti_scutils.sub_commands.testlink import SCLogin, SCUse, SCLogout
from gti_scutils.sub_commands.xshow import XShow
from gti_scutils.sub_commands.xcomp import XunitComp
from gti_scutils.sub_commands.xunit import XunitUtil
           


SUB_COMMANDS = [SCLogin, SCUse, XunitUtil, XunitComp, SCLogout, XShow]

def scutils(args = None):
    '''\
    gti_scutils is a collection of sub commands to interact with a soundcheck 
    server (a.k.a. testlink). 
    
    for more information on each sub commands, type::
    
        gti_scutils <sub_command> --help '''
    
    common_parser = argparse.ArgumentParser(add_help=False)
    
    group = common_parser.add_argument_group("generic options")

    group.add_argument('--debug', 
                        action='store_true',
                        default=False,
                        help = "turn debug trace to On")

    group.add_argument('--version', 
                        action='store_true',
                        default=False,
                        help = "print version")


    group.add_argument('-v', '--verbose', 
                        action='store_true',
                        default=False,
                        help = "turn on verbosity")

    group.add_argument('--pytl-debug', 
                        action='store_true',
                        default=False,
                        help = "turn PYTL debug trace to On")

    group.add_argument('--pytl-verbose', 
                        action='store_true',
                        default=False,
                        help = "turn on PYTL verbosity")


    group.add_argument('--xmlrpc-debug', 
                        action='store_true',
                        default=False,
                        help = "turns on testlink XML RPC debug")
    
    parser = argparse.ArgumentParser(
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                        description = scutils.__doc__,
                        parents = [common_parser])
    
    subparsers = parser.add_subparsers(title = "sub commands")
    
    if "--version" in sys.argv:
        print __version__
        print "Perforce date {0} chglist {1} location {2}".format(__p4datetime__.replace("$DateTime: ", '').replace(" $", ''), 
                                                                  __p4change__.replace("$Change: ", '').replace(" $", ''), 
                                                                  __p4file__.replace("$File: ", '').replace("__init__.py $", ''))
        sys.exit()
    
    
    sub_commands = []
    for sc in SUB_COMMANDS:
        sub_commands.append(sc(subparsers, common_parser))
    
    args = parser.parse_args(args)
    

    scutils_verbose_enable(args.verbose)
    scutils_debug_enable(args.debug)
    
    if args.pytl_verbose == True:
        import logging
        testlink.pytl_log_level(logging.INFO)

    testlink.pytl_enable_debug(args.pytl_debug)
    testlink.pytl_enable_xml_rpc_debug(args.xmlrpc_debug)

    
    
    _tw = py.io.TerminalWriter(file=None)
    try:
        args.func(args)
    except Exception as rune:        
        if args.debug == True:
            import traceback            
            _tw.write(traceback.format_exc(), yellow=True)
        _tw.write("error - command failed %s\n" % str(rune), red = True, bold = True)    
        parser.exit(1)
    else:
        _tw.write("OK!\n", green = True, bold = True)
        
        

