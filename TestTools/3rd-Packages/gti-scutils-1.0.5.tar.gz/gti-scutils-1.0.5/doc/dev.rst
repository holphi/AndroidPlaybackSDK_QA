.. _label_dev_chapter:

Developers
==========

This chapter contains brief instruction on how to implement an observer or to 
provide the implementation for your own power controller device.


    .. inheritance-diagram:: gti_scutils.utils.ProgressBar
                             gti_scutils.utils.GTISCUtilsBase
                             gti_scutils.model.ServerConfig
                             gti_scutils.model.XunitReport                             
                             gti_scutils.model.TestCaseBase
                             gti_scutils.model.CompoundedTestCase
                             gti_scutils.model.XunitTestCase
                             gti_scutils.sub_commands.xcomp.XunitComp
                             gti_scutils.sub_commands.xshow.XShow
                             gti_scutils.sub_commands.xunit.XunitUtil
                             gti_scutils.sub_commands.testlink.SCLogin
                             gti_scutils.sub_commands.testlink.SCUse
                             gti_scutils.sub_commands.testlink.SCLogout          
       :parts: 1


.. _label_dev_bootstrapping:

Bootstrapping
-------------

To bootstrap this project, do the following:

   - check out the project in your workspace (the ``gti/projects/utils/gti_scutils`` project is self contained)
   - goto ``rel/1.0``
   - call ``python <gti-bootstrap.py> --devpi-index=<your index> <virtualenv root> --pip-install-opts="--pre"``. Example::
   
      $ python ~/venv/gti-bootstrap.py --devpi-index=lpbrac/dev ~/venv/gti-scutils/1.0 --pip-install-opts="--pre"
      
Modules
-------

Access to the code can be done via the documentation (:doc:`modules/modules` or in Perforce.

