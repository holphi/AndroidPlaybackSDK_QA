
.. _gti_scutils_chapter:

gti sc utils
============

This package provides a single entry point script which supports sub-commands
to process xunit reports and to interface with a soundcheck (TestLink) server. 

General Help
------------

To view the list of sub commands, type::

      $gti_scutils --help
      usage: gti_scutils [-h] {login,use,xunit,logout} ...
      
          gti_scutils is a collection of sub commands to interact with a soundcheck 
          server (a.k.a. testlink). 
          
          for more information on each sub commands, type::
          
              gti_scutils <sub_command> --help 
      
      optional arguments:
        -h, --help            show this help message and exit
      
      sub commands:
        {login,use,xunit,logout}
          login               login to the soundcheck server
          use                 use a soundcheck server
          xunit               xunit report utilities
          logout              logout from the soundcheck server


The sub-commands are listed under positional arguments. To find out more 
about a sub command, type the sub-command name followed by ``--help``::

      $/gti_scutils logout --help
      usage: gti_scutils logout [-h]
      
      Logout from the server
      
      optional arguments:
        -h, --help  show this help message and exit

Server Access
-------------
        
.. _login_sub_command:
        
Login to the Server
^^^^^^^^^^^^^^^^^^^

To login to a particular server, use the ``login`` sub-command. You can select 
the server by name using the ``-k`` option, or specify a URL using the ``-s``
option. 



.. note:: when using the ``-s`` option, the session is set to **custom**.

**Usage**::

   gti_scutils login --help
   usage: gti_scutils login [-h] [-u USER] [-d DEV_KEY] [-s SERVER_URL]
                            [-k {nur_sand,aus_prod,us_sand,us_stage,us_prod}]
   
           Logs in to the server. 
   
           When login to the server, it becomes the active session which 
           means that all other sub-commands are using this session. 
   
           see `use` command to learn how to switch sessions
           see `logout` to logout from the server. 
   
      List of Servers
      ===============
      nur_sand             DE  Sanbox
      aus_prod             AUS Production
      us_sand              US  Replicated production environment
      us_stage             US  Next release staging environment
      us_prod              US  Production
   
   optional arguments:
     -h, --help            show this help message and exit
     -u USER, --user USER  user name
     -d DEV_KEY, --dev-key DEV_KEY
                           development key
     -s SERVER_URL, --server-url SERVER_URL
                           sound check server url
     -k {nur_sand,aus_prod,us_sand,us_stage,us_prod}
                           known servers - do --help for details
                           
**Example**::                          

   $gti_scutils login -k us_prod -d '46b98cdfgdfge90fdgb13a55a98a484fef2406f563'
   Logged in


.. _use_sub_command:

Using a  Server
^^^^^^^^^^^^^^^

As mentioned previsously, when logging in to a server, it becomes the current session. 
It is possible to switch between session as shown below::

   # Current session

   $gti_scutils use 
   Current Configuration: us_prod
      user: lpbrac
      url:  http://testlink.dolby.net

   # switching session

   $gti_scutils use -k aus_prod
   Current Configuration: aus_prod
      user: lpbrac
      url:  http://aus-testlink.dolby.net/
      
   $gti_scutils use
   Current Configuration: aus_prod
      user: lpbrac
      url:  http://aus-testlink.dolby.net/
      
   # switching back
   $gti_scutils use -k us_prod
   Current Configuration: us_prod
      user: lpbrac
      url:  http://testlink.dolby.net
      
   # Session with no login
   $gti_scutils use -k nur_sand
   usage: gti_scutils use [-h] [-k {nur_sand,aus_prod,us_sand,us_stage,us_prod}]
                          [-u USER]
   gti_scutils use: error: Failed to set config 'nur_sand'user 'lpbrac' - No login information available
   
   # Session with invalid user
   gti_scutils use -k us_prod -u sober
   usage: gti_scutils use [-h] [-k {nur_sand,aus_prod,us_sand,us_stage,us_prod}]
                          [-u USER]
   gti_scutils use: error: 'sober' - User never logged in to us_prod

.. _logout_sub_command:

Logout from the Server
^^^^^^^^^^^^^^^^^^^^^^

Simply make sure you are using the right session and then logout::

   $gti_scutils use -k us_prod 
   Current Configuration: us_prod
      user: lpbrac
      url:  http://testlink.dolby.net

   $gti_scutils logout
   Logged out us_prod

   $gti_scutils use -k us_prod 
   usage: gti_scutils use [-h] [-k {nur_sand,aus_prod,us_sand,us_stage,us_prod}]
                          [-u USER]
   gti_scutils use: error: Failed to set config 'us_prod'user 'lpbrac' - No login information available
   
Commands
--------

.. _xunit_sub_command:

xunit
^^^^^

The xunit command allows you to "slurp" and entire xunit report and perform certain actions.

**Usage**::

   $gti_scutils xunit --help
   usage: gti_scutils xunit [-h] [--debug] [--version] [-v] [--pytl-debug]
                         [--pytl-verbose] [--xmlrpc-debug] [-p string]
                         [-s string] [--sc-platform-name string] [-b string]
                         [-r string] [-i string] [--base-path string] -x
                         string [-d] [--keep-structure]
                         [-a {sum,upload,group}] [-o {pass,fail,skip,error}]
                         [-c] [-w] [--concise] [--no-fast-upload]

   Processes a xunit report and performs some actions on the content. The xunit
   report (-x --xunit-path) can be in compressed format (zip). (GZIP not supported)
   The report can be accessed via a URL.
   
   Py.Test Specific
   - - - - - - - - 
   
   Compound test cases are defined as test cases which follow the same procedure
   but are executed via different data set.
   
   Compound results are generated using the -c (--compound) option and follow a simple 
   rule. Any test "step" of a compound test case that fails, fails the compound case.
   
   If the -w (--weight) option is specified, weight information, which consist 
   of the pass rate (pass over total), and weight details, is provided.
   
   The xunit command provides the following features:
   
       * Upload of test results from an xunit report:
   
           -a upload
   
           This action should be used to upload an xunit report to the testlink
           project against the specified project (-p), test set (-s), build (-b)
           and an optional platform(-t).
   
           if the dry run (-s) option is specified, data is only processed but not 
           uploaded. 
   
           --keep-structure is specified, the code hierarchy will be maintained, 
           otherwise all test cases will be loaded as a flat structure under the 
           base path (--base-path)
   
       * Summary display "a la Pytest":
   
           -a sum
   
           This action takes the xunit report and dispay a summary on the console
           the way pytest does during execution. 
   
       * Error grouping:
   
           -a group
   
           This action attempt to find common failure from the backtraces and group 
           test cases that are failing under the same conditions together. 
   
   optional arguments:
     -h, --help            show this help message and exit
     -p string, --sc-project-name string
                           soundcheck project name
     -s string, --sc-test-set-name string
                           sound check test set name where results are to be
                           reported.
     --sc-platform-name string
                           platform (target) name used for reporting
     -b string, --sc-build-name string
                           build name name used for reporting
     -r string, --sc-build-release-date string
                           release date to be set of the build is created on the
                           server
     -i string, --sc-build-info string
                           build information which can be added to build on the
                           server when created.
     --base-path string    Base test suite in soundcheck to be used to
                           create/report test case results into.
     -x string, --xunit-path string
                           path or url to a junit xml (can be zipped) file
                           containing the results of a test run.
     -d, --dry-run         Dry run mode
     --keep-structure      If set, keeps the test case hierarchy
     -a {sum,upload,group}, --action {sum,upload,group}
                           action to perform
     -o {pass,fail,skip,error}, --outcome {pass,fail,skip,error}
                           outcome to process
     -c, --compound        Set the outcome to a series of test cases with the
                           same name
     -w, --weighted        If used with the -c option, provide a weighted
                           outcome.
     --concise             If set, the diagnostic associated to the test is not
                           display (action: sum)
     --no-fast-upload      If set, switches back to pytl implementation. See
                           https://jira.dolby.net/jira/browse/GTITA-221 for
                           details

      
For the summary action ``-a sum``, it is not necessary to specify any server information
(project, set, platform, build). 

.. note:: Processing can be done on a subject of the report by specifying the desired outcome.
          By default, ALL outcomes are processed.   

.. _summary_report:
   
Summary Report
..............
          
          
**Example**:
   
   Summary report failed and skipped test cases::
   
      $gti_scutils xunit -o fail -o skip -x test/data/dolby_commander_xunit.xml.zip 
      Loading xml report  test/data/dolby_commander_xunit.xml.zip
      Zipfile Extracting  test/data/dolby_commander_xunit.xml.zip
      ========================================================
      SUMMARY REPORT : test/data/dolby_commander_xunit.xml.zip
      ========================================================
      fail   0.07 test_creation_with_credential_by_name    test failure
      skip   5.92 test_crawl                               xfail-marked test passes unexpectedly
      skip   0.08 test_creation_with_credential_by_ref     expected test failure
      skip   0.17 test_creation_with_resource_by_name      xfail-marked test passes unexpectedly
      skip   0.21 test_creation_with_resource_by_ref       xfail-marked test passes unexpectedly
      skip   0.20 test_creation_with_workspace_by_name     xfail-marked test passes unexpectedly
      skip   0.00 test_project_with_steps                  expected test failure
      skip   0.00 test_creation_with_credential            expected test failure
      skip   0.00 test_creation_with_resource              expected test failure
      skip   0.00 test_creation_with_workspace             expected test failure
      
      Executed  Passed      Failed     Skipped    Errors     Total      Exec Time
      --------------------------------------------------------------------------------
      59        58          1          9          0          68         00:04:59.658

**Example**:

   Using a URL as opposed to a file::
   
      $gti_scutils xunit -o skip -x http://sfo-gti-03.eng.dolby.net/ce_rel_neon-u1110_armca9.xml.zip
      Loading xml report  http://sfo-gti-03.eng.dolby.net/ce_rel_neon-u1110_armca9.xml.zip
      [INFO] gti_scutils.utils.wget: Downloading /tmp/tmp6uwDDQ/ce_rel_neon-u1110_armca9.xml.zip from http://sfo-gti-03.eng.dolby.net/ce_rel_neon-u1110_armca9.xml.zip
      Zipfile Extracting  /tmp/tmp6uwDDQ/ce_rel_neon-u1110_armca9.xml.zip
      Deleted temp file /tmp/tmp6uwDDQ/ce_rel_neon-u1110_armca9.xml.zip
      =================================================================================
      SUMMARY REPORT : http://sfo-gti-03.eng.dolby.net/ce_rel_neon-u1110_armca9.xml.zip
      =================================================================================
      skip   0.00 TestBed                                  collection skipped
      skip   0.00 TestBed                                  collection skipped
      skip   0.00 TestBed                                  collection skipped
      skip   0.00 TestBed                                  collection skipped
      skip   0.00 TestBed                                  collection skipped
      
      Executed  Passed      Failed     Skipped    Errors     Total      Exec Time
      --------------------------------------------------------------------------------
      692       224         468        5          0          697        01:04:12.822


**Example**:

   Compounded test cases::
   
      $gti_scutils xunit -x test/data/junit_panning_results_withoutprefix.xml -c -w
      Loading xml report  test/data/junit_panning_results_withoutprefix.xml
      ==================================================================
      SUMMARY REPORT : test/data/junit_panning_results_withoutprefix.xml
      ==================================================================
      pass   117.74 test_dvb_metadata                          25.00%   47(P)    0(F)  141(S)    0(E)
      pass    34.74 test_sampling_rates                        25.00%   14(P)    0(F)   42(S)    0(E)
      fail    89.68 test_dvb_panning_metadata                  10.42%   40(P)   56(F)  288(S)    0(E)
      
      Executed  Passed      Failed     Skipped    Errors     Total      Exec Time
      --------------------------------------------------------------------------------
      157       101         56         471        0          628        00:04:32.680
      
   In the example above, the percentage represent the number of passed (P) cases over total (**including 
   skipped (S) and error (E)**). 
   
   The example below shows the same type of information for another report::    
      
      $gti_scutils xunit -x test/data/ce_rel-w7_x86.xml.zip -c -w
      Loading xml report  test/data/ce_rel-w7_x86.xml.zip
      Zipfile Extracting  test/data/ce_rel-w7_x86.xml.zip
      ================================================
      SUMMARY REPORT : test/data/ce_rel-w7_x86.xml.zip
      ================================================
      skip     0.00 TestBed                                     0.00%    0(P)    0(F)    5(S)    0(E)
      error    0.00 test_coding_tools                           0.00%    0(P)    0(F)    0(S)   12(E)
      fail  3077.54 test_check_error                           64.33%  285(P)   18(F)    0(S)  140(E)
      fail  2577.82 test_bit_exact                             11.30%   20(P)  157(F)    0(S)    0(E)
      error    0.00 test_parse_ddp_info                         0.00%    0(P)    0(F)    0(S)   60(E)
      
      Executed  Passed      Failed     Skipped    Errors     Total      Exec Time
      --------------------------------------------------------------------------------
      480       305         175        5          212        697        01:54:15.885
      
   The same report is again run, this time use the outcome selector (-o or --outcome). Because the resulting 
   set id now different, the weight is also different (better in this case) **as error (E) and skipped (S) tests
   are not accounted for**::
      
      $gti_scutils xunit -x test/data/ce_rel-w7_x86.xml.zip -c -w -o pass -o fail
      Loading xml report  test/data/ce_rel-w7_x86.xml.zip
      Zipfile Extracting  test/data/ce_rel-w7_x86.xml.zip
      ================================================
      SUMMARY REPORT : test/data/ce_rel-w7_x86.xml.zip
      ================================================
      fail  3077.54 test_check_error                           94.06%  285(P)   18(F)    0(S)    0(E)
      fail  2577.82 test_bit_exact                             11.30%   20(P)  157(F)    0(S)    0(E)
      
      Executed  Passed      Failed     Skipped    Errors     Total      Exec Time
      --------------------------------------------------------------------------------
      480       305         175        5          212        697        01:54:15.885
      

   .. note:: The summary statistics still represent the raw data in the report and doesn't reflect compounded test cases.   
   
.. _testlink_upload_report:   
   
Report Upload
.............

.. warning:: Make sure you understand this section before proceeding.

The xunit report classname generate by pytest depends on where the runner was invoked.

For instance, if you have your tests in ``my_test`` and invoke pytest as shown below::

   py.test my_test/ --junit-xml=report1.xml
   
The xml report would look like this::

   <?xml version="1.0" encoding="utf-8"?>
   <testsuite errors="1" failures="2" name="pytest" skips="1" tests="14" time="0.042">
   <testcase classname="my_test.test_top" name="test_simple_pass"/>
   <testcase classname="my_test.test_top" name="test_simple_fail"/>
   <testcase classname="my_test.test_top" name="test_escape_xml_char[&quot;]"/>
   <testcase classname="my_test.test_top.TestClassTop" name="test_1"/>
   <testcase classname="my_test.test_top.TestClassTop" name="test_2"/>
   <testcase classname="my_test.sub.test_sub.TestClassSub" name="test_1"/>
   <testcase classname="my_test.sub.test_sub.TestClassSub" name="test_2"/>
   </testsuite>

but if you invoke the runner from the parent directory (say ``parent/mytest``, such as::

   py.test parent/ --junit-xml=report1.xml
   
You now endup with a report like this::

   <?xml version="1.0" encoding="utf-8"?>
   <testsuite errors="1" failures="2" name="pytest" skips="1" tests="14" time="0.042">
   <testcase classname="parent.my_test.test_top" name="test_simple_pass"/>
   <testcase classname="parent.my_test.test_top" name="test_simple_fail"/>
   <testcase classname="parent.my_test.test_top" name="test_escape_xml_char[&quot;]"/>
   <testcase classname="parent.my_test.test_top.TestClassTop" name="test_1"/>
   <testcase classname="parent.my_test.test_top.TestClassTop" name="test_2"/>
   <testcase classname="parent.my_test.sub.test_sub.TestClassSub" name="test_1"/>
   <testcase classname="parent.my_test.sub.test_sub.TestClassSub" name="test_2"/>
   </testsuite>
   
If you  keep the original structure via the ``--keep-structure`` switch, you would 
end up with two different structures (duplicated test cases). 

In the first case, you will have a structure in TestLink that looks like this::

   my_test/test_top/
                    test_simple_pass
                    test_simple_fail
                    test_escape_xml_char[&quot;]
                    TestClassTop/
                                  test_1
                                  test_2
                    sub/test_sub/TestClassSub
                                              test_1
                                              test_2
                    
Whereas if you upload the tests from the second report, you will have::

   parent/my_test/test_top/
                          test_simple_pass
                          test_simple_fail
                          test_escape_xml_char[&quot;]
                          TestClassTop/
                                        test_1
                                        test_2
                          sub/test_sub/TestClassSub
                                                    test_1
                                                    test_2

As you can imagine, this becomes a problem. 

**Therefore** you must always specify the switch ``--ignore-base`` with the path using ``/`` or ``.``

**Example**::

   --ignore-base=/parent/my_test
   
   or  
   
   --ignore-base=my_test
   
will load the test according to this structure::

   test_top/
        test_simple_pass
        test_simple_fail
        test_escape_xml_char[&quot;]
        TestClassTop/
                      test_1
                      test_2
        sub/test_sub/TestClassSub
                                  test_1
                                  test_2

.. note:: if the string specified in ``--ignore-base`` does not start with a ``/`` all characters 
          prior the match will be ignored. i.e. ``/parent/my_test`` is equivalent to ``my_test``.
          
.. tip:: always run with ``--action = sum``          

.. note:: to preserve backward compatibility, if ``--ignore-base`` is not specified, 
          all class name staring with ``test.`` or ``src.`` have these prefix stripped.


Upload a report to the SoundCheck (or TestLink) server is done via the **upload** action of the **xunit** sub-command. 
Most of the options are the same (``--outcome``, ``--compound``, ``--weighted``) however, it is required to provide information 
specific to the test management system. **Project**, **test set**, and **build** are required. **Platform** is optional.

.. note:: When using platform (--sc-platform-name), you must:
            * Have the platform created in your project (same name)
            * Assign that platform to the test set you are using. 


By default, all test cases will be created under the base suite (``--base-path``) provided on the command line (you can use a path like 
notation, e.g. /ms21/profiling). If not specifed, the top level suite **default** will be created to contains the 
test cases. 

The underlying structure will be flat, irrespective of the code structure. 

.. note:: The tool will throw an error if it encounters a test case with the same name but a different
          **classname**

If the ``--keep-structure`` is specified, the code structure will be maintained (still under base path). The code structure 
maps to the xunit classname (for instance ``src.ms12.ms12_ga.mixer.test_mixer_dvb_metadata`` will result on the 
``ms12/ms12_ga/mixer/test_mixer_dvb_metadata`` test suite.

The ``--dry-run`` will connect to the server, attempt to ignore any error, and attempt to run through the report 
without creating anything or setting any results.

.. note:: To view a summary, it is preferable to use the `summary_report`_
 
Error Grouping Report
.....................

Not implemented

.. _xcomp_sub_command:

xcomp
^^^^^

The xcomp command allows to compare various xunit reports, normally between runs or accross multiple platform
to determine which tests pass on one platform versus failing on another. 

This command can also be used to show timing information to identify improvements or degradation performance 
wise.

**Usage**::

   usage: gti_scutils xcomp [-h] [-x XUNIT_REPORT] [-l] [-t]
   
   Show a comparative reports between multiple xunit reports. This sub-command can be used 
   to diff the xunit reports between different runs (execution) or platforms.
   
   By default the report, show the test cases which have a different outcome (unless
   the -l option is used). 
   
   If the timing option is used (-t), only test cases which have an outcome of pass in every
   report will be displayed with their respective timing information (in seconds). The shortest 
   run will be between square brackets []
   
   optional arguments:
     -h, --help            show this help message and exit
     -x XUNIT_REPORT, --xunit-report XUNIT_REPORT
                           xunit report files to compare
     -l, --long            long output - show test case with identical results
     -t, --timing          show timing for each pass test case (ignore other
                           outcome)

As many (and at least 2) xunit report can be provided on the command line via the ``-x`` option. 

.. note:: by default, the ``xcomp`` command will not show results that are the same accross all reports. 
          (those will be marked as filtered out). To view the full report, use the ``-l`` option. 

The example below show the outcome of two reports for the same test case running on 2 platforms.

**Example**::

   $ $ gti_scutils xcomp -x pro_rel_neon-u1110_armca9.xml.zip -x pro_rel-w7_x86.xml.zip
   Loading xml report  pro_rel_neon-u1110_armca9.xml.zip
   Zipfile Extracting  pro_rel_neon-u1110_armca9.xml.zip
   Loading xml report  pro_rel-w7_x86.xml.zip
   Zipfile Extracting  pro_rel-w7_x86.xml.zip
   Processing pro_rel_neon-u1110_armca9.xml.zip
   Processing pro_rel-w7_x86.xml.zip
   ==============
   SUMMARY REPORT
   ==============
   ----------------------------------------------------------------------+---------+---------+
   [0] - pro_rel_neon-u1110_armca9
   [1] - pro_rel-w7_x86
   
   ----------------------------------------------------------------------+---------+---------+
   TEST CASE                                                             | [0]     | [1]     |
   ----------------------------------------------------------------------+---------+---------+
   src.dolby_zeus_tests.test_check_error:test_check_error[50384]         | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[100182]        | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50333]         | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[100104]        | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50344]         | pass    | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50041]   | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[100006]        | pass    | error   |
   ...
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50145]   | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50089]         | pass    | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[50201]             | fail    | pass    |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[140001]  | pass    | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50545]         | pass    | error   |
   src.dolby_zeus_tests.test_coding_tools:test_coding_tools[70034]       | pass    | error   |
   src.dolby_zeus_tests.test_coding_tools:test_coding_tools[70029]       | pass    | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50067]   | pass    | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50007]   | pass    | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50027]   | pass    | error   |
   ----------------------------------------------------------------------+---------+---------+
   
   Test cases displayed               : 946
   Test cases collected (unique names): 1498
   Test cases filtered out            : 552
   Total cases processed 2996
   EXECUTION TIME                                                          8262.67   9550.15  



.. _timing_information:        

Showing Timing information
..........................
             
By using the ``-t`` option, you can see runtime information as illustrated below. On a console,
best time are highlighted in **green** while worst execurtion time is displayed in **red**. 

**Example**::

   $ $ gti_scutils xcomp -x pro_rel_neon-u1110_armca9.xml.zip -x pro_rel-w7_x86.xml.zip -t
   Loading xml report  pro_rel_neon-u1110_armca9.xml.zip
   Zipfile Extracting  pro_rel_neon-u1110_armca9.xml.zip
   Loading xml report  pro_rel-w7_x86.xml.zip
   Zipfile Extracting  pro_rel-w7_x86.xml.zip
   Processing pro_rel_neon-u1110_armca9.xml.zip
   Processing pro_rel-w7_x86.xml.zip
   ==============
   SUMMARY REPORT
   ==============
   ----------------------------------------------------------------------+---------+---------+
   [0] - pro_rel_neon-u1110_armca9
   [1] - pro_rel-w7_x86
   
   ----------------------------------------------------------------------+---------+---------+
   TEST CASE                                                             | [0]     | [1]     |
   ----------------------------------------------------------------------+---------+---------+
   src.dolby_zeus_tests.test_check_error:test_check_error[50384]         | 0.8617  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[120027]            | 2.6724  | 3.9176  |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100316]            | 3.4195  | 4.7632  |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100121]            | 2.9221  | 8.2006  |
   src.dolby_zeus_tests.test_check_error:test_check_error[100182]        | 0.8080  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100376]            | 2.5782  | 4.6507  |
   src.dolby_zeus_tests.test_check_error:test_check_error[50333]         | 3.3944  | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[100104]        | 0.8429  | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50344]         | 0.8027  | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50041]   | 3.5567  | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[100006]        | 1.0866  | error   |
   ...
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50145]   | 2.2523  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[130022]            | 14.0376 | 17.6595 |
   src.dolby_zeus_tests.test_check_error:test_check_error[50089]         | 0.7804  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[140047]            | 4.0237  | 8.1117  |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100052]            | 2.9255  | 4.2285  |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[50201]             | 1.1613  | 3.6860  |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[140001]  | 3.8129  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100274]            | 2.6359  | 4.7661  |
   src.dolby_zeus_tests.test_check_error:test_check_error[50545]         | 4.7217  | error   |
   src.dolby_zeus_tests.test_check_error:test_check_error[50043]         | 0.8406  | 2.6878  |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[11034]             | 10.8873 | 15.5748 |
   src.dolby_zeus_tests.test_coding_tools:test_coding_tools[70034]       | 2.7679  | error   |
   src.dolby_zeus_tests.test_coding_tools:test_coding_tools[70029]       | 4.3724  | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50067]   | 2.3544  | error   |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50007]   | 2.6695  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[90044]             | 14.2000 | 14.2589 |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[100229]            | 28.2989 | 58.9534 |
   src.dolby_zeus_tests.test_check_error:test_check_error[50078]         | 0.5218  | 2.6245  |
   src.dolby_zeus_tests.test_parse_ddp_info:test_parse_ddp_info[50027]   | 2.4636  | error   |
   src.dolby_zeus_tests.test_bit_exact:test_bit_exact[11020]             | 9.5712  | 16.4351 |
   ----------------------------------------------------------------------+---------+---------+
   
   Test cases displayed               : 1498
   Test cases collected (unique names): 1498
   Test cases filtered out            : 0
   Total cases processed 2996
   EXECUTION TIME                                                          8   

.. _label-overview-func-arg_filter:
   
Ignoring Functional Arguments
.............................
   
It some cases, users want to ignore portions of the test signature (functional arguments). For instance, 
an functional argument can be the backend used for testing. By default, test cases are compared using 
both the path as well as the signature of the test case. 

Functional arguments can be ignored by specifying a pattern using the ``-i`` option. This option can be 
set to a standard regular expression. Multiple patterns can be specified by using the ``-i`` repetively.
All functional argument matching a pattern are removed from the signature before the reports are compared.

This is illustrated below::

   $ gti_scutils xcomp -x junit-pcm_renderer-SRC_v1_0_rc3-model_q31accu-244595.xml -x junit-pcm_renderer-SRC_v1_0_rc3-cortex_a8-249298.xml -x junit-pcm_renderer-SRC_v1_0_rc3-generic_float32-244593.xml -i "test_pcmr_.*" -s
   Loading xml report  junit-pcm_renderer-SRC_v1_0_rc3-model_q31accu-244595.xml
   Loading xml report  junit-pcm_renderer-SRC_v1_0_rc3-cortex_a8-249298.xml
   Loading xml report  junit-pcm_renderer-SRC_v1_0_rc3-generic_float32-244593.xml
   Processing junit-pcm_renderer-SRC_v1_0_rc3-model_q31accu-244595.xml
   Processing junit-pcm_renderer-SRC_v1_0_rc3-cortex_a8-249298.xml
   Processing junit-pcm_renderer-SRC_v1_0_rc3-generic_float32-244593.xml
   ==============
   SUMMARY REPORT
   ==============
   ----------------------------------------------------------------------------------------------------------------------------+---------+---------+---------+
   [0] - junit-pcm_renderer-SRC_v1_0_rc3-model_q31accu-244595
   [1] - junit-pcm_renderer-SRC_v1_0_rc3-cortex_a8-249298
   [2] - junit-pcm_renderer-SRC_v1_0_rc3-generic_float32-244593
   
   ----------------------------------------------------------------------------------------------------------------------------+---------+---------+---------+
   TEST CASE                                                                                                                   | [0]     | [1]     | [2]     |
   ----------------------------------------------------------------------------------------------------------------------------+---------+---------+---------+
   test_renderer_ddp_clipping:test_renderer_ddp_drc_clipping_6ch_raw[0]                                                        | pass    | None    | pass    |
   test_renderer_aac_LtRtdmx_coeffs:test_aac_ltrt_lfe[2-1]                                                                     | fail    | None    | fail    |
   test_renderer_aac_cut_boost:test_renderer_aac_no_cut_boost_rf_2ch_dmx[param_drcpm_acmod_dmx_rf2-0-param_cut_boost10]        | pass    | None    | pass    |
   test_renderer_ddp_drc:test_renderer_ddp_drc_dual_mono_range2[1--128]                                                        | pass    | None    | pass    |
   test_renderer_aac_LoRodmx_params:test_coeff_MPEG[2-2]                                                                       | pass    | None    | pass    |
   test_renderer_aac_dialnorm:test_renderer_aac_dialnorm_forbidden[0-2-1-0.25]                                                 | pass    | None    | pass    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_8ch_mc2[64-param_cut_boost_23]                                      | fail    | None    | fail    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_6ch_mc_raw[127-param_cut_boost26]                                   | pass    | None    | pass    |
   test_renderer_aac_LtRtdmx_equation:test_aac_LtRtdmx_formula_acmod7_21[in_pcm11]                                             | pass    | None    | pass    |
   test_renderer_aac_compr:test_renderer_aac_compr_no_line_2ch_dmx[180]                                                        | pass    | None    | pass    |
   test_renderer_aac_cut_boost:test_renderer_aac_cut_boost_6ch_mc_raw[param_drcpm_acmod_multi4-0-param_cut_boost10]            | pass    | None    | pass    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_2ch_dmx[0-0-param_cut_boost21]                                      | pass    | None    | pass    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_2ch_dmx[1--4-param_cut_boost29]                                     | pass    | None    | pass    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_2ch_dmx[0--64-param_cut_boost16]                                    | pass    | None    | pass    |
   test_renderer_aac_dialnorm:test_renderer_aac_dialnorm_forbidden[0-0-1--32]                                                  | pass    | None    | pass    |
   ...
   test_renderer_ddp_drc:test_renderer_ddp_drc_non_dual_mono[2-0--64]                                                          | pass    | None    | pass    |
   test_renderer_ddp_cut_boost:test_renderer_ddp_cut_boost_2ch_dmx[0-4-param_cut_boost13]                                      | pass    | None    | pass    |
   test_renderer_aac_dialnorm:test_renderer_aac_dialnorm_2ch_dmx[0--20]                                                        | skip    | None    | skip    |
   test_renderer_aac_cut_boost:test_renderer_aac_cut_boost_2ch_dmx[param_drcpm_acmod_dmx0-0-param_cut_boost2]                  | pass    | None    | pass    |
   ----------------------------------------------------------------------------------------------------------------------------+---------+---------+---------+
   
   Test cases displayed               : 3504
   Test cases collected (unique names): 4792
   Test cases filtered out            : 1288
   Total cases processed 10996
   EXECUTION TIME                                                                                                                10535.00   24993.56   10505.76  
   
.. note:: The ``-s`` provices a short display name of the test by stripping the test function path 
          all the way to the parent suite (assumes that combination of suite + test function is unique). 
          without the -i option which filters the test case backend, 10996 unique test cases would be 
          displayed. 
          
.. _xshow_sub_command:

xshow
^^^^^

The ``xshow`` allows user to inspect the content of an xunit report. After viewing the summary of an xunit report
with the :ref:`xunit_sub_command`, it is possible to inspect individual test cases, print the back trace information,
see the standard error and standard output captured by the test runner.

**Usage**::

      usage: gti_scutils xshow [-h] [--debug] [--version] [-v] [--pytl-debug]
                               [--pytl-verbose] [--xmlrpc-debug] -x string
                               [-n <test name>] [-p <test procedure name>]
                               [--outcome {pass,fail,skip,error}] [-b] [-e] [-o]
      
      This sub-command shows the details of an xunit report.
      
      It is possible to filter the output according to:
      
          - the outcome (option --outcome)
          - the test case name(s) (option --test-case-name)
          - the test procedure name(s) (option --test-procedure-name)
      
       To see the backtrace in case of failure, use the --back-trace option
       To see the standard error captured use the --stderr option
       To see the standard output captured use the --stderr option
      
      optional arguments:
        -h, --help            show this help message and exit
        -x string, --xunit-path string
                              path or url to a junit xml (can be zipped) file
                              containing the results of a test run.
        -n <test name>, --test-case-name <test name>
                              test case name to be matched - can be repeated
        -p <test procedure name>, --test-procedure-name <test procedure name>
                              test procedure name to be matched - can be repeated
        --outcome {pass,fail,skip,error}
                              outcome to process
        -b, --back-trace      shows the backtrace information
        -e, --stderr          shows standard error
        -o, --stdout          shows standard output

Below is an example of output:

.. fancybox:: ./images/xshow-output.png
    :width: 650px
    :height: 560px
    
    XShow output
    
                  * *click to enlarge*
                  

.. _report_manip:

Report Manipulation
===================

.. _xunit_report:

Xunit Report
------------

With version :ref:`version_1.0.4`, it is now possible to load xunit reports or generate xunit reports 
via this package.

The main point of entry is the :py:class:`gti_scutils.reports.xunit.XUNITReportFile`.

To load a xunit report::

   >>> from gti_scutils.reports.xunit import XUNITReportFile
   >>> x = XUNITReportFile("rce_rel-w7_x86.xml")
   >>> x.load()
   
The xunit report file has a suite which can be accessed via the 
 :py:attr:`XUNITReportFile.suite <gti_scutils.reports.xunit.XUNITReportFile.suite>` 
 property::
 
   >>> x.suite.time
   6433.453
   >>> x.suite.tests
   566
   >>> x.suite.failures
   38
   >>> x.suite.test_cases[3].outcome
   'skipped'
   >>> x.suite.test_cases[7].outcome
   'failure'
   >>> x.suite.test_cases[7].time
   28.651624918
   >>> x.suite.test_cases[7].classname
   'src.dolby_zeus_tests.test_bit_exact'
 
Most of the properties match the attribute name in the xunit report as shown below.

.. fancybox:: ./images/xunit_struct.png
    :width: 600px
    :height: 450px
    
    Xunit Structure
    
                  * *click to enlarge*
  
To create an xunit report, first create an empty :py:class:`~gti_scutils.reports.xunit.XUNITReportFile` 
object::

   >>> from gti_scutils.reports.xunit import XUNITReportFile
   >>> x = XUNITReportFile(xunit_file="./xunit.xml",suite_name="my name")
   
The ``suite_name`` is the suite name of the xunit report. At the suite level, the only property
that needs to be set is :py:attr:`XUNITReportFile.suite <gti_scutils.reports.xunit.XUNITTestSuite.time>` 
as this represents the test session time which may be more than the sum of all the test case execution.

All the other properties are computed automatically as you add test cases as illustrated below::

   >>> x.suite.collected  # Number of tests in the report
   0
   >>> tc = x.suite.add_test_case(name = "foo")
   >>> x.suite.collected 
   1
   >>> x.suite.tests # Number of tests that passed or failed
   1
   >>> x.suite.passed
   1
   
If we set the test as a failure, the stats of the suite change:: 

   >>> tc.failure(message="test")
   >>> x.suite.passed
   0
   >>> x.suite.failures
   1
   
Finally to save the xunit report::

   >>> x.save()
   >>> x.file_path
   '/Users/lpbrac/dolby/qa/gti/projects/utils/gti_scutils/rel/1.0/xunit.xml'
   
.. _specmap_report:

Specmap Reports
---------------

With version :ref:`version_1.0.4`, it is now possible to load or generate ``specmap`` files 
via this package.   

.. note:: A specmap file supports a subset of a testlink test specification export (xml) but 
          is fully compatible with the import feature provided by testlink.
          
To load an ``specmap`` file, use the :py:class:`~gti_scutils.reports.specmap.SpecmapReportFile` 
class as illustrated below::

   >>> from gti_scutils.reports.specmap import SpecmapReportFile
   >>> s = SpecmapReportFile(specmap_file = "./testlink-id.specmap")
   >>> s.load()
   >>> s.num_cases
   313
  
You can add test suites and test cases to a new or existing specmap object::

   >>> s.num_suites
   8
   >>> s.add_test_suite("/sphinx/documentation")
   >>> s.num_suites
   10
   >>> suite = s.find("/sphinx/documentation")
   >>> print suite
   Title   : documentation
   Author  : None None
   Path  : /sphinx/documentation
   None
   >>> case = s.add_test_case(base=suite.path, title="demo")   
   >>> print case
   Title : demo
   version: None
   Summary:
      None
   >>>  case.id = 777
   >>>  s.num_cases
   >>>  314
   >>> s.save("./new_file.specmap")
   
Which can then be reloaded::

   >>> s2 = SpecmapReportFile(specmap_file = "./new_file.specmap")
   >>> s2.load()
   >>> s2.num_cases
   314
   >>> print s2.find("/sphinx/documentation/demo").id
   777
   

   
   
   

 
   
      
   
   
   
