.. _label_commands_chapter:

********
commands
********

.. automodule:: gti_scutils.commands


XShow
-----

.. automodule:: gti_scutils.sub_commands.xshow

.. autoclass:: gti_scutils.sub_commands.xshow.XShow 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

XComp
-----

.. automodule:: gti_scutils.sub_commands.xcomp

.. autoclass:: gti_scutils.sub_commands.xcomp.XunitComp 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

XUnit
-----


.. automodule:: gti_scutils.sub_commands.xunit

.. autoclass:: gti_scutils.sub_commands.xunit.XunitUtil 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

TestLink
--------

.. automodule:: gti_scutils.sub_commands.testlink
    
.. autoclass:: gti_scutils.sub_commands.testlink.SCLogin 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    
.. autoclass:: gti_scutils.sub_commands.testlink.SCUse 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    
.. autoclass:: gti_scutils.sub_commands.testlink.SCLogout 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
