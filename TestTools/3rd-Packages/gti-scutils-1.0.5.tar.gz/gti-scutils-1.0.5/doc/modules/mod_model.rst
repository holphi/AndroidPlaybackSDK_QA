.. _label_model_chapter:

*****
model
*****

.. automodule:: gti_scutils.model

.. autoclass:: gti_scutils.model.ServerConfig 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

.. autoclass:: gti_scutils.model.XunitReport 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    
.. autoclass:: gti_scutils.model.TestCaseBase 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    
.. autoclass:: gti_scutils.model.CompoundedTestCase 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    
.. autoclass:: gti_scutils.model.XunitTestCase 
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
