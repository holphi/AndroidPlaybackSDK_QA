.. _label_reports_chapter:



*******
Reports
*******

Xunit
=====

.. automodule:: gti_scutils.reports.xunit

.. autoclass:: gti_scutils.reports.xunit.XUNITReportFile 
    :members:
    :show-inheritance:


.. autoclass:: gti_scutils.reports.xunit.XUNITTestSuite 
    :members:
    :show-inheritance:
    
.. autoclass:: gti_scutils.reports.xunit.XUNITTestCase 
    :members:
    :show-inheritance:

    

Specmap
=======

.. automodule:: gti_scutils.reports.specmap

.. autoclass:: gti_scutils.reports.specmap.SpecmapReportFile 
    :members:
    :show-inheritance:

