#! /usr/bin/env python
import os, sys
import shutil
from setuptools import setup, find_packages

_source_code_dir='src'
sys.path.insert(0, _source_code_dir)

def _p4datetime(val):
    '''Converts p4 datetime to human readable format and formats classifier'''
    from datetime import datetime, date, time
    thedate = val.split()[1].split('/')
    thedate = [int(x) for x in thedate]
    thetime = val.split()[2].split(':')
    thetime = [int(x) for x in thetime]
    d = date(thedate[0], thedate[1], thedate[2])
    t = time(thetime[0], thetime[1], thetime[2])
    return  'Perforce :: DateTime :: {0}'.format(datetime.combine(d, t).isoformat())

def _p4change(val):
    '''Formats classifier for changelist #'''
    return  'Perforce :: Change :: {0}'.format(val.split()[1])

def _p4project(val):
    return 'Perforce :: Project :: {0}'.format(val.split()[1].rpartition(_source_code_dir)[0].rstrip('/'))

if __name__ == "__main__":

    from gti_scutils import __version__
    from gti_scutils import __p4datetime__
    from gti_scutils import __p4change__
    from gti_scutils import __p4file__

    install_requires = ['pytl', 'py', 'python-dateutil']
    if sys.version_info < (2,7):
        install_requires.append("argparse")


    here = os.path.abspath(".")
    README = open(os.path.join(here, 'doc', 'overview.rst')).read()
    CHANGES = open(os.path.join(here, 'doc', 'changelog.rst')).read()
    setup(

            # Package name
            name              = "gti-scutils",
            version           = __version__,

            # Information about what needs to be packaged
            package_dir       = {'':'src', 'test':'test'},
            packages          = find_packages('src'),
            package_data      = {'test': ['data/*.zip']},
            include_package_data=True,
            scripts           = [],
            zip_safe          = False,
            install_requires  = install_requires,

            entry_points={
                         'console_scripts' : [
                                               'gti_scutils=gti_scutils.commands:scutils',
                                               'version_gti_scutils=gti_scutils:get_package_version',
                                             ]
                        },


            description="gti_scutils: a set of utilities for soundcheck",
            long_description=CHANGES + '\n\n' + README,

            # Metadata for the package

            maintainer="Laurent Brack",
            maintainer_email="lpbrac@dolby.com",
            keywords="soundcheck web",

            license="Dolby Proprierary",
            classifiers=[
                        'Development Status :: Beta',
                        'Environment :: Console',
                        'Intended Audience :: Test Engineers, Developers',
                        'Operating System :: OS Independent',
                        'Programming Language :: Python',
                        'Topic :: Software Development :: Testing',
                        "License :: Proprietary",
                        'devpi :: project :: gti',
                        'Dependencies :: {0}'.format(install_requires),
                        _p4datetime(__p4datetime__),
                        _p4change(__p4change__),
                        _p4project(__p4file__),
              ],
        )

