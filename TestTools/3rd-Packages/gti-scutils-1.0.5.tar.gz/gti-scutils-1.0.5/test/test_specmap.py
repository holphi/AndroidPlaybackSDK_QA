import pytest
import tempfile
import types
import os
import xml.etree.ElementTree as ET

from gti_scutils.reports.specmap import SpecmapReportFile
from dolby.gti.testlink.structures import Suite as PYTLSuite

@pytest.fixture()
def new_report():
    return SpecmapReportFile(specmap_file = tempfile.mktemp(suffix = ".xml"))

@pytest.fixture()
def testlink_export(data_dir):
    f = os.path.abspath(os.path.join(data_dir, "..", "specmap", 'testlink_export.xml'))
    
    assert os.path.isfile(f)
    s = SpecmapReportFile(specmap_file = f)
    s.load()
    etree = ET.ElementTree(file = f)
    assert len(etree.getroot().findall(".//testsuite")) == s.num_suites
    assert len(etree.getroot().findall(".//testcase")) == s.num_cases
    return s

class TestSpecmapReportFileWrite():
    
    def test_load_specmap(self, data_dir):
        """ Verifies that we can load the specmap file using the fixture"""
        testlink_export(data_dir)
        
    def test_save_specmap(self, testlink_export, new_report):
        
        for src_test_case in testlink_export.get_all_test_cases():
            parent_suites = src_test_case.parent_path.strip("/").split("/")
            
            current_path = []
            
            parent_suite_obj = None
            for parent_suite in parent_suites:
                current_path.append(parent_suite)
                spath = "/" + "/".join(current_path)
                parent_suite_obj = testlink_export.find(spath)
                new_parent_suite_obj = new_report.add_test_suite(base=parent_suite_obj.parent_path, suite_name = parent_suite_obj.title)
                new_parent_suite_obj.summary = parent_suite_obj.summary
                new_parent_suite_obj.title = parent_suite_obj.title
                
            assert parent_suite_obj.path == src_test_case.parent_path
            
            new_test_case = new_report.add_test_case(base = src_test_case.parent_path, title = src_test_case.title)
            new_test_case.summary = src_test_case.summary
            new_test_case.id = src_test_case.id
            new_test_case.uid = src_test_case.uid 
            
        new_report.save()
        
        reload_report = SpecmapReportFile(specmap_file = new_report.file_path)
        reload_report.load()
        
        for src_test_case in testlink_export.get_all_test_cases():
            suite_obj = reload_report.find(src_test_case.parent_path)
            
            assert suite_obj != None
            assert suite_obj.path == src_test_case.parent_path
            
            test_case_obj = reload_report.find(src_test_case.parent_path + "/" + src_test_case.title)
            assert test_case_obj != None
            assert test_case_obj.title == src_test_case.title
            assert test_case_obj.parent_path == src_test_case.parent_path
            def clean(text):
                if text != None:
                    return text.replace("<br>", "\n").replace("\n", '').replace(" ", '')
            assert clean(test_case_obj.summary) == clean(src_test_case.summary)
    
    @pytest.mark.parametrize("base,title,exception", [(123, 'foo', TypeError),
                                                      ("/foo", 123, TypeError),
                                                      ("/", 'foo', ValueError)
                                                      ])
    def test_add_test_case_error(self, new_report, base, title, exception):
        """ Checks proper exception handling for add_test_case to the specmap
            report.
        """
        with pytest.raises(exception):
            new_report.add_test_case(base = base, title = title)
        assert new_report.num_cases == 0
        assert new_report.num_suites == 0
        
    @pytest.mark.parametrize("base,suite_name,exception", 
                                    [
                                      ("/foo",  123, TypeError),
                                      ("/",  "", ValueError),
                                      ("/",  None, ValueError),
                                      (123,  "foo", TypeError),
                                      
                                      (PYTLSuite(), None, ValueError),
                                      (PYTLSuite(), "foo", TypeError),
                                      ("/",  "", ValueError)
                                    ])
    def test_add_test_suite_error(self, new_report, base, suite_name, exception):
        """ Checks proper exception handling for add_test_suite to the specmap
            report.
        """
        with pytest.raises(exception):
            new_report.add_test_suite(base=base, suite_name = suite_name)
        assert new_report.num_cases == 0
        assert new_report.num_suites == 0
          

    @pytest.mark.parametrize("base,suite_name", 
                                    [
                                      ("/foo",  None),
                                      ("/foo",  "boo"),
                                      ("/foo/boo/zoo",  None),
                                      ("/foo/boo/zoo/",  "loo"),

                                    ])          
    def test_add_test_suite_by_name(self, new_report, base, suite_name):
        """ checks that suite can be added by name
        """
        
        bases = base.strip("/").split("/")
        if type(suite_name) == types.StringType:
            bases.append(suite_name)
        
        s = new_report.add_test_suite(base=base, suite_name = suite_name)
        assert s != None
        print "parent path", s.parent_path
        assert s.parent_path == "/" + "/".join(bases[:-1]) 
        assert id(s) == id(new_report.find("/".join(bases)))
        assert new_report.num_suites == len(bases)
        assert new_report.num_cases == 0
        
    def test_add_same_suite(self, new_report):
        suite = new_report.add_test_suite(base = "/foo/boo/zoo")
        assert suite.parent_path == "/foo/boo"
        assert suite == new_report.add_test_suite(base = "/foo/boo/zoo")

    @pytest.mark.parametrize("base,suite_name", 
                                    [
                                      ("/foo",  "boo"),
                                      ("/foo/boo/zoo/",  "loo"),

                                    ])  
    def test_add_test_suite_by_obj(self, new_report, base, suite_name):
        """ checks that suite can be added by name
        """
        
        bases = base.strip("/").split("/")
        if type(suite_name) == types.StringType:
            bases.append(suite_name)
        
        parent_suite = new_report.add_test_suite(base = base)
        assert parent_suite != None
        
        s = new_report.add_test_suite(base=parent_suite, suite_name = suite_name)
        assert s != None
        print "parent path", s.parent_path
        assert s.parent_path == parent_suite.path
        assert id(s) == id(new_report.find("/".join(bases)))
        assert new_report.num_suites == len(bases)
        assert new_report.num_cases == 0
        
    def test_add_test_case_by_name(self, new_report):
        """ Verifies that test cases can be added by name properly
        """
        
        tc = new_report.add_test_case(base = "/foo/boo/zoo", title = "tc_1")
        assert tc.title == "tc_1"
        assert tc.parent_path == "/foo/boo/zoo"
        tc = new_report.add_test_case(base = "/foo/boo/zoo", title = "tc_2")
        assert tc.title == "tc_2"
        assert tc.parent_path == "/foo/boo/zoo"
        tc = new_report.add_test_case(base = "/foo/boo/zoo", title = "tc_3")
        assert tc.title == "tc_3"
        assert tc.parent_path == "/foo/boo/zoo"

    def test_add_test_case_with_id(self, new_report):
        """ Verifies that ID are serialized properly
        """
        
        tc = new_report.add_test_case(base = "/foo/boo/zoo", title = "tc_with_data")
        tc.uid = 99
        tc.id = 77
        tc.summary = "deadbeef\nlivechecken"
        tc = new_report.add_test_case(base = "/foo/boo/zoo", title = "tc_without_data")
        new_report.save()
        
        check_report = SpecmapReportFile(specmap_file = new_report.file_path)
        check_report.load()
        tc = check_report.find("/foo/boo/zoo/tc_with_data")
        assert tc.uid == 99
        assert tc.id == 77
        def clean(text):
            if text != None:
                return text.replace("<br>", "\n").replace("\n", '').replace(" ", '')
        assert clean(tc.summary) == clean("deadbeef\nlivechecken")
        
        tc = check_report.find("/foo/boo/zoo/tc_without_data")
        assert tc.uid == None
        assert tc.id == None
        assert tc.summary == None

        
        
        