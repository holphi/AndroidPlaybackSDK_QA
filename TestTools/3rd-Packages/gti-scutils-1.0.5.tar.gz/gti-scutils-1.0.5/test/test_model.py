import pytest
import os



from gti_scutils.model import XunitReport, CombinedXunitReport

@pytest.fixture()
def tb_short_zxml_report(data_dir):
    return XunitReport(file_path = os.path.join(data_dir, "tbshort.zxml"), ignore_base = "/tmp/my_project/src/")
    

@pytest.fixture()
def all_data_reports(data_dir):
    from os import listdir
    from os.path import isfile, join
    return [ XunitReport(file_path = os.path.join(data_dir, f)) for f in listdir(data_dir) if isfile(join(data_dir,f)) ]

class TestXunitReport():
    """ Test Suite Verification of the XunitReport.
    """    
    
    
    def test_zxml_with_ids(self, tb_short_zxml_report):
        """ Verifies that the IDs and the summary can be found. 
        
            This file was manually crafted from the data provided in GTITA-563
        """
        assert tb_short_zxml_report.all_tests == len(tb_short_zxml_report.get_test_cases())
        
        for i in range(tb_short_zxml_report.all_tests ):
            tc = tb_short_zxml_report.get_test_cases()[i]
            assert tc.external_id * 100 == tc.uid    
            assert tc.summary == "test case is {0}".format(tc.name)  
        
class TestCombinedXunitReport():
    """ Test Suite Verification of the combined report - CombinedXunitReport
    """
    
    def test_check_consistency(self, all_data_reports):
        """ This test cases verifies that a combined report is consisten with all the sub reports.
        
            It creates a combined report with all reports found under the data folder
            and then verifies that all the stats are tallied property
        
        """
        reports = [p.report_path for p in all_data_reports]
        cr = CombinedXunitReport(reports)
        
        assert sum([p.errors for p in all_data_reports]) == cr.errors
        assert sum([p.failures for p in all_data_reports]) == cr.failures
        assert sum([p.skips for p in all_data_reports]) == cr.skips
        assert sum([p.ok for p in all_data_reports]) == cr.ok
        assert sum([p.tests for p in all_data_reports]) == cr.tests
        assert sum([p.all_tests for p in all_data_reports]) == cr.all_tests
        assert sum([p.time for p in all_data_reports]) == cr.time
        assert set([p.report_path for p in all_data_reports]) == set(cr.report_path)

        
        