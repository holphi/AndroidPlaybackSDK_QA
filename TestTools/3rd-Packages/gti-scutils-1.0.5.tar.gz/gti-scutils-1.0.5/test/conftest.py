import os
import random
import textwrap
import py
import sys
import time
import signal
import re
import pytest

from _pytest.pytester import RunResult, LineMatcher
import subprocess

from gti_utils.commands import which, find
from gti_scutils import __version__

_GLOBAL_DEBUG = False
_GLOBAL_VERBOSE = False


def _format_string(*msgs):
    msg = ""
    if len(msgs) == 0:
        return msg
    elif len(msgs) == 1:
       msg = msgs[0]
    else: 
        try:
            msg = msgs[0] % msgs[1:]
        except:
            msg = " ".join(map(str, msgs))
            
    return msg


class Base(object):
    
    
    def __init__(self, name = "shell", debug = False, verbose = False):
        
        self._tw = None 
        self._debug = debug
        self._verbose = verbose
        self._name = name
        try:
            import py
            self._tw = py.io.TerminalWriter(file=None)
        except ImportError:
            pass

    @property
    def debug(self):
        return self._debug
    @debug.setter
    def debug(self, value):
        self._debug = value

    @property
    def verbose(self):
        return self._verbose
    @verbose.setter
    def verbose(self, value):
        self._verbose = value


    def line(self, *msgs, **kwargs):
        if self._tw == None:
            sys.stdout.write(_format_string(*msgs) + "\n")
        else:
            self._tw.line(_format_string(*msgs), **kwargs)

    def raw(self, *msgs, **kwargs):
        if self._tw == None:
            sys.stdout.write(_format_string(*msgs) + "\n")
        else:
            self._tw.line(_format_string(*msgs), **kwargs)


    def bold(self, *msgs, **kwargs):
        kwargs['bold'] = True
        self.line(*msgs, **kwargs)

    # semantic logging
    def debug_info(self, *msgs):        
        if self.debug or _GLOBAL_DEBUG:
            msg = "(debug)" + msgs[0] % msgs[1:]
            self.line(msg)
            
    def debug_dump_backtrace(self):
        if self.debug or _GLOBAL_DEBUG:
            msg = "[debug backtrace %s]" % (str(self._object_name)) + str(traceback.format_exc())
            self.line(msg, yellow = True)
            

    def action(self, *msgs):
        self.line(*msgs, green=True)

    def printout(self, *msgs):
        self.raw(*msgs, bold=True)

    def error(self, *msgs):
        msg = "(error) %s" % _format_string(*msgs)
        self.line(msg, red=True)

    def warning(self, *msgs):
        msg = "(warning) %s" % _format_string(*msgs)
        self.line(msg, yellow=True)
            
    def success(self, *msgs):
        self.line(*msgs, green=True)

    def fatal(self, *msgs):
        msg = "(fatal) %s" % _format_string(*msgs)
        self._tw.line(msg, red=True)
        raise SystemExit(1)

    def info(self, *msgs):
        if self.verbose or _GLOBAL_VERBOSE:
            self.line(*msgs, bold=True)
            
    
class TestProcess(Base):
    
    def __init__(self, binary):
        super(TestProcess, self).__init__()
        self.binary = binary
        self.exit_code = -1
        self.output = []
        self._sub_process = None
                   
    def exec_command(self, *args, **kawrgs):
        """ runs the specified command.
        
            This function executes the specified command and checks 
            for the return code. 
        
            :param \*args: Command line arguments
            :param exit_code: **optional** expected return code (default 0)
            :param quiet: **optional** default False. If False, output on the console.
            
            :rtype: a list of line, consisting of the combined output of stdout 
                    and stderr
                     
            :raise: OSError on error
            
            **Examples**::
            
                >>> from gti_build import GTIShell
                >>> s = GTIShell()
                >>> o = s.exec_command("ls", "-a")
                >>> print o[3]
                buildout.cfg                
                >>> # echo output on console
                >>> s.exec_command("ls", "-a", quiet = False)
                .
                ..
                bin
                buildout.cfg
                doc
                ...
                test                
                >>> s.exec_command("ls", "-a", exit_code = 3)
                Traceback (most recent call last):
                  File "<stdin>", line 1, in <module>
                  File "./gti_build/__init__.py", line 509, in exec_command
                OSError: Command 'ls -a' returned 0 insread of 3
                >>> 
            
        """
        exit_code = kawrgs.get('exit_code', 0)
        quiet = kawrgs.get('quiet', False)
        progress = kawrgs.get('progress', False)
        self.output = []
        self.exit_code = None

        
        if progress == True:
            quiet = True

        if quiet == False or self.debug == True or self.verbose == True:
            self.line("executing %s", " ".join(map(str, args)), purple=True, bold = True) 
        
        
                   
        if progress == True:
            sys.stdout.write("Processing")
            sys.stdout.flush()
        import subprocess
        
        args = (self.binary,) + args
        
        
        self._sub_process = subprocess.Popen(args,
                                             stdout=subprocess.PIPE,
                                             stderr=subprocess.STDOUT)
        
        # Poll process for new output until finished
        while True:
            try:
                nextline = self._sub_process.stdout.readline()
                if nextline == '' and self._sub_process.poll() != None:
                    break
                if not quiet:
                    self.raw(nextline.rstrip(), purple=True)
                if progress == True:
                    sys.stdout.write(".")
                    sys.stdout.flush()
                self.output.append(nextline)
            except:
                raise
            
        self.exit_code = self._sub_process.returncode
    
        if quiet == False or self.debug == True:
            self.line("Done\n", purple=True, bold = True) 
        if self.exit_code != exit_code:
            raise OSError("Command '" + " ".join(args) + "' returned %d insread of %d" %(self.exit_code, exit_code))
        
        self._sub_process = None
        
        return self.output  
    
    def terminate(self):
        """ Terminates the process
        """
        if self._sub_process != None:
            try:
                self._sub_process.terminate()
                self.info("Waiting for process")
                self._sub_process.wait()
                self.info("Process terminated")
            except Exception as pe:
                if self.exit_code == None:
                    self.error("Error - Failed to kill sub process %s", str(pe))
      


trace = Base()
trace.action("Checking version %s", __version__)

GTI_SCUTILS_BIN = which(['gti_scutils'])
assert GTI_SCUTILS_BIN != None or len(GTI_SCUTILS_BIN) == 1, "No or too many gti_scutils instances found" + str(GTI_SCUTILS_BIN)
GTI_SCUTILS_BIN = GTI_SCUTILS_BIN[0]
trace.info("gti_scutils executable %s", GTI_SCUTILS_BIN)

version_gti_scutils_bin = which(['version_gti_scutils'])
assert version_gti_scutils_bin != None or len(version_gti_scutils_bin) == 1, "No or too many version_gti_scutils instances found" + str(version_gti_scutils_bin)
version_gti_scutils_bin = version_gti_scutils_bin[0]
trace.info("version_gti_scutils %s", version_gti_scutils_bin)


bin_version = subprocess.Popen([version_gti_scutils_bin],stdout=subprocess.PIPE, 
                               stderr=subprocess.STDOUT).communicate()[0].rstrip()
assert __version__ == bin_version, "version mismatch - module %s - exec %s" % (str(__version__), str(bin_version))
trace.success("version OK!")

@pytest.fixture
def gti_scutils_proc(request):
    tp = TestProcess(GTI_SCUTILS_BIN)
    request.addfinalizer(tp.terminate)
    return tp

@pytest.fixture
def data_dir(request):
    test_data_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data'))
    assert os.path.isdir(test_data_folder), "data folder not found " + test_data_folder
    return test_data_folder
