""" Tests the xunit report support implememtation
"""

import tempfile
import types
import os
import zipfile
import warnings
import xml.etree.ElementTree as ET
import re 
import pytest   
    
from gti_utils.commands import which, find
from gti_scutils.reports.xunit import XUNITReportFile

def pytest_generate_tests(metafunc):
    """ 
    """
    
    
    tmp_dir = tempfile.mkdtemp()
    test_data_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data'))
    if 'xunit_file_path' in metafunc.fixturenames:
        xunit_list = []
        xunit_ids = []
        for xunit_file in find(['-t', 'f', test_data_folder]):

            print xunit_file, zipfile.is_zipfile(xunit_file)
            if zipfile.is_zipfile(xunit_file) == True:
                zip = zipfile.ZipFile(xunit_file)
                if len(zip.namelist()) == 0:
                    warnings.warn("{0} constains no file".format(xunit_file))
                elif len(zip.namelist()) == 1 or len(zip.namelist()) == 2:
                    pass # A single xml file
                else:
                    warnings.warn("{0} zxml file not support yet".format(xunit_file))
                for f in zip.namelist():
                    print "extracting {0}".format(xunit_file)
                    zip.extract(f, tmp_dir)
                    if re.match("(x|X)(m|M)(l|L)", f.split(".")[-1]):                                        
                        xunit_list.append(os.path.join(tmp_dir, f))
                        xunit_ids.append(os.path.basename(xunit_list[-1])) 
            else:
                xunit_list.append(xunit_file)
                xunit_ids.append(os.path.basename(xunit_list[-1])) 
           
        metafunc.parametrize(argnames = "xunit_file_path", argvalues = xunit_list, ids = xunit_ids) 
        
@pytest.fixture
def xunit_report():
    x = XUNITReportFile(xunit_file=tempfile.mktemp(suffix=".xml"),suite_name="xunit_report")
    x.suite.time = 100

    for i in range(100):
        tc = x.suite.add_test_case(name = "test_case_{0}".format(i))
        tc.time = i * 30
        tc.classname = "test.something"
        if i % 7 == 0:
            tc.skip(message="test case {0} is skipped".format(i), text = "additional information {0}".format(i))
        elif i % 5 == 0:
            tc.error(message="test case {0} is skipped".format(i), text = "additional information {0}".format(i))
        elif i % 2 == 0:
            tc.failure(message="test case {0} is skipped".format(i), text = "additional information {0}".format(i),
                       stdout = "This is stdout {0}".format(tc.name), stderr = "This is stderr {0}".format(tc.name))
    return x

class TestXUNITReportFile():
    
    def test_xunit_load(self, xunit_file_path):
        """ Test Loading of xunit files
        """
        xunit = XUNITReportFile(xunit_file = xunit_file_path)
        xunit.load()
        
    def test_xunit_save(self, xunit_report):
        """ Verifies that a xunit report can be save and then reloaded with consistent information.
        """
        xunit_report.save()
        x = XUNITReportFile(xunit_file=xunit_report.file_path)
        x.load()
        
        assert xunit_report.file_path == x.file_path
        assert xunit_report.suite.name == x.suite.name
        assert xunit_report.suite.test_time == x.suite.test_time
        assert xunit_report.suite.time == x.suite.time
        assert xunit_report.suite.failures == x.suite.failures
        assert xunit_report.suite.errors == x.suite.errors
        assert xunit_report.suite.skips == x.suite.skips
        assert xunit_report.suite.tests == x.suite.tests
        assert xunit_report.suite.collected == x.suite.collected
        assert len(xunit_report.suite.test_cases) ==  x.suite.collected

    def test_xunit_save_with_filename(self, xunit_report):
        """ Checks that the file can be overriden when saving.
        """
        tmp = tempfile.mktemp(suffix=".xml")
        xunit_report.save(tmp)
        assert xunit_report.file_path == tmp
        x = XUNITReportFile(xunit_file=xunit_report.file_path)
        x.load()
        
        assert xunit_report.file_path == x.file_path
        

