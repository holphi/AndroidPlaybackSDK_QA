import pytest
import os
from gti_utils.commands import which, find
import re


def pytest_generate_tests(metafunc):
    """ Main test generator which is responsible (mostly) to feed all the test files 
        found in the data folder. It provides support for the following functinal 
        arguments:
        
            * xunit_report : List of all files found under test/data
            * outcome : possible outcome filtering with some combinations. 
            * xcomp_reports : tuples of reports which need to be compared together
                              Test functions invoking this funcarg get a dictionary
                              which contains a list of file (key 'files'), as well as 
                              optional arguments to be sent to the xcomp command (key 'args') 
    """
    
    test_data_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data'))
    if 'xunit_report' in metafunc.fixturenames:
        print "pytest_generate_tests(xunit_report) - Looking for reports in ", test_data_folder
        assert os.path.isdir(test_data_folder), "data folder not found " + test_data_folder
        
        metafunc.parametrize("xunit_report", map(os.path.basename, find(['-t', 'f', test_data_folder])))    
    if 'outcome' in metafunc.fixturenames:
        metafunc.parametrize("outcome", [[], 
                                         ['-o', 'pass'],
                                         ['-o', 'fail'],
                                         ['-o', 'skip'],
                                         ['-o', 'error'],
                                         ['-o', 'pass', '-o', 'skip']])
    if 'xcomp_reports' in metafunc.fixturenames:
        list = []
        list.append({"files" : ['ce_rel_neon-u1110_armca9.xml.zip', 
                                'ce_rel-w7_x86.xml.zip'], 
                     "args" : []})
        
        list.append({"files" : ['pro_rel_neon-u1110_armca9.xml.zip', 
                                'pro_rel-w7_x86.xml.zip'], 
                     "args" : []})
        
        list.append({"files" : ['pcm_render-v1_0_rc3-cortex_a8.xml.zip', 
                                'pcm_render-v1_0_rc3-generic_float32.xml.zip',
                                'pcm_render-v1_0_rc3-model_q31accu.xml.zip'], 
                     "args" : ['-i', '"test_pcmr_.*"']})
        
        metafunc.parametrize("xcomp_reports", list)
  
@pytest.fixture
def xml_list():      
    test_data_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data'))
    _list = []
    for f in os.listdir(test_data_folder):
        _list.extend(['-x', os.path.join(test_data_folder, f)])
    return _list
     
def test_feature_584(gti_scutils_proc, xml_list):
    """ Verifies that multiple xml can be specified.
    """
    options = ['xunit', '-a', 'sum']
    options.extend(xml_list)
    gti_scutils_proc.exec_command(*options)

@pytest.mark.parametrize( 'sub_command', ['login', 'use', 'logout', 'xunit', 'xcomp'])
def test_help(gti_scutils_proc, sub_command):
    """ Make sure helps work for every sub command"""
    gti_scutils_proc.exec_command(sub_command, '--help')

def test_xunit_summary(gti_scutils_proc, outcome, data_dir, xunit_report):
    """ Simply run a summry on each file. This should never fail """
    # Add code to find the number of test cases in the document 
    # as well as the outcome matches.
    
    options = ['xunit', '-a', 'sum']
    options.extend(outcome)
    options.extend(['-x', os.path.join(data_dir, xunit_report)])
    gti_scutils_proc.exec_command(*options)

    
@pytest.mark.parametrize( 'mode', [[], 
                                   ['-w']])    
def test_xunit_summary_compounded(gti_scutils_proc, outcome, mode, data_dir, xunit_report):
    """ Run a summary with compounded option turned on. Some instance may fail as they 
        have multiple test cases with the same names and this is trapped in the except 
        statement. Any other error should be considered a failure """
    options = ['xunit', '-a', 'sum', '-c']
    options.extend(mode)
    options.extend(outcome)
    options.extend(['-x', os.path.join(data_dir, xunit_report)])
    try:
        gti_scutils_proc.exec_command(*options)
    except OSError:
        while gti_scutils_proc.output: 
            line = gti_scutils_proc.output.pop(0)           
            if re.match(".*Test\s+name\s+\w+\s+found in different class.*", line, re.IGNORECASE):
                break
        else:
            pytest.fail("Unexpected error")
            
@pytest.mark.parametrize( 'output_mode', [[], 
                                   ['-t'],
                                   ['-l'],
                                   ['-l', '-t'],
                                   ['-s', '-l', '-t']])    
def test_xunit_xcomp(gti_scutils_proc, output_mode, data_dir, xcomp_reports):
    """ Runs the xcomp command with various reports and options """
    options = ['xcomp']
    options.extend(output_mode)
    options.extend(xcomp_reports['args'])
    for filename in xcomp_reports['files']:
        options.extend(['-x', os.path.join(data_dir, filename)])
    gti_scutils_proc.exec_command(*options)
  
@pytest.fixture
def soundcheck_list():
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data2', 'soundcheck'))
    sc_list = find(['-t', 'f', base])
    assert len(sc_list) > 1
    return sc_list
    
    
def test_gtita_158(gti_scutils_proc, soundcheck_list):  
    """ This test ensures that there is not duplicate
    """ 
    options = ['xcomp']
    for f in soundcheck_list:
        options.extend(['-x', f]) 

    gti_scutils_proc.exec_command(*options)
    while gti_scutils_proc.output: 
        line = gti_scutils_proc.output.pop(0).strip()
        if line.startswith('test') == True:
            line = map(lambda(f) : f.strip(), line.split('|'))[1:-1]  # the last element is empty
            assert line.pop(0) not in line
         
